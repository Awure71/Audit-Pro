import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, FileText, Video, Download, ExternalLink } from "lucide-react";
import { Link } from "wouter";

export default function Resources() {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold text-foreground" data-testid="text-resources-title">
          Financial Resources & Learning Center
        </h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Educational materials, templates, and guides to enhance your financial analysis skills
        </p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <BookOpen className="w-12 h-12 text-primary mb-4" />
            <CardTitle className="text-2xl">Educational Articles</CardTitle>
            <CardDescription>
              In-depth guides covering essential accounting and financial analysis topics
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Link href="/blog">
                <Button variant="outline" className="w-full justify-between h-auto py-4" data-testid="button-visit-blog">
                  <div className="text-left">
                    <div className="font-semibold mb-1">Financial Accounting Blog</div>
                    <div className="text-sm text-muted-foreground">Expert insights and best practices</div>
                  </div>
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              
              <Link href="/help">
                <Button variant="outline" className="w-full justify-between h-auto py-4" data-testid="button-visit-help">
                  <div className="text-left">
                    <div className="font-semibold mb-1">Help Documentation</div>
                    <div className="text-sm text-muted-foreground">Complete user guides and tutorials</div>
                  </div>
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <FileText className="w-12 h-12 text-primary mb-4" />
            <CardTitle className="text-2xl">Accounting Standards & Guidelines</CardTitle>
            <CardDescription>
              Essential resources for maintaining compliance with accounting standards
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="prose prose-slate max-w-none dark:prose-invert">
              <h3>Generally Accepted Accounting Principles (GAAP)</h3>
              <p className="text-muted-foreground">
                FinanceAudit Pro follows GAAP standards for financial statement preparation. Understanding these principles is essential for accurate financial reporting:
              </p>
              <ul className="text-muted-foreground">
                <li><strong>Accrual Basis:</strong> Record revenues when earned and expenses when incurred, regardless of cash flow</li>
                <li><strong>Consistency:</strong> Use the same accounting methods from period to period</li>
                <li><strong>Going Concern:</strong> Assume the business will continue operating indefinitely</li>
                <li><strong>Matching Principle:</strong> Match expenses with the revenues they help generate</li>
                <li><strong>Materiality:</strong> Report all information that could influence decisions</li>
                <li><strong>Full Disclosure:</strong> Include all relevant information in financial statements</li>
              </ul>

              <h3>Key Financial Reporting Standards</h3>
              <ul className="text-muted-foreground">
                <li><strong>ASC 205:</strong> Presentation of Financial Statements</li>
                <li><strong>ASC 230:</strong> Statement of Cash Flows</li>
                <li><strong>ASC 505:</strong> Equity</li>
                <li><strong>ASC 606:</strong> Revenue from Contracts with Customers</li>
                <li><strong>ASC 842:</strong> Leases</li>
              </ul>

              <h3>International Standards (IFRS)</h3>
              <p className="text-muted-foreground">
                While FinanceAudit Pro is designed primarily for GAAP compliance, many principles align with International Financial Reporting Standards (IFRS). Key differences to be aware of:
              </p>
              <ul className="text-muted-foreground">
                <li>LIFO inventory method not permitted under IFRS</li>
                <li>Different presentation formats for financial statements</li>
                <li>Varying criteria for revenue recognition</li>
                <li>Different approaches to fair value measurement</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Download className="w-12 h-12 text-primary mb-4" />
            <CardTitle className="text-2xl">Templates & Checklists</CardTitle>
            <CardDescription>
              Practical tools to streamline your financial reporting workflow
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg" data-testid="resource-trial-balance">
                <h4 className="font-semibold mb-2">Trial Balance CSV Template</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Properly formatted CSV template for importing trial balance data
                </p>
                <div className="text-xs text-muted-foreground">
                  <strong>Columns:</strong> Account Code, Account Name, Account Type, Debit, Credit
                </div>
              </div>

              <div className="p-4 border rounded-lg" data-testid="resource-audit-checklist">
                <h4 className="font-semibold mb-2">Financial Audit Checklist</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Comprehensive checklist for preparing for financial audits
                </p>
                <div className="text-xs text-muted-foreground">
                  <strong>Includes:</strong> Document requirements, reconciliation tasks, control reviews
                </div>
              </div>

              <div className="p-4 border rounded-lg" data-testid="resource-ratio-guide">
                <h4 className="font-semibold mb-2">Financial Ratio Quick Reference</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  One-page guide to all major financial ratios and their interpretations
                </p>
                <div className="text-xs text-muted-foreground">
                  <strong>Categories:</strong> Liquidity, Profitability, Efficiency, Leverage
                </div>
              </div>

              <div className="p-4 border rounded-lg" data-testid="resource-account-mapping">
                <h4 className="font-semibold mb-2">Chart of Accounts Template</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Standard chart of accounts for various business types
                </p>
                <div className="text-xs text-muted-foreground">
                  <strong>Formats:</strong> Service businesses, retail, manufacturing
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Video className="w-12 h-12 text-primary mb-4" />
            <CardTitle className="text-2xl">Video Tutorials</CardTitle>
            <CardDescription>
              Step-by-step video guides for using FinanceAudit Pro effectively
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg" data-testid="video-quick-start">
                <div className="aspect-video bg-muted rounded mb-3 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h4 className="font-semibold mb-1">Quick Start Guide</h4>
                <p className="text-sm text-muted-foreground">5:30</p>
              </div>

              <div className="p-4 border rounded-lg" data-testid="video-csv-import">
                <div className="aspect-video bg-muted rounded mb-3 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h4 className="font-semibold mb-1">CSV Import Tutorial</h4>
                <p className="text-sm text-muted-foreground">3:45</p>
              </div>

              <div className="p-4 border rounded-lg" data-testid="video-statements">
                <div className="aspect-video bg-muted rounded mb-3 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h4 className="font-semibold mb-1">Generating Statements</h4>
                <p className="text-sm text-muted-foreground">7:20</p>
              </div>

              <div className="p-4 border rounded-lg" data-testid="video-ratio-analysis">
                <div className="aspect-video bg-muted rounded mb-3 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h4 className="font-semibold mb-1">Understanding Ratios</h4>
                <p className="text-sm text-muted-foreground">10:15</p>
              </div>

              <div className="p-4 border rounded-lg" data-testid="video-comparison">
                <div className="aspect-video bg-muted rounded mb-3 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h4 className="font-semibold mb-1">Period Comparison</h4>
                <p className="text-sm text-muted-foreground">6:50</p>
              </div>

              <div className="p-4 border rounded-lg" data-testid="video-export">
                <div className="aspect-video bg-muted rounded mb-3 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h4 className="font-semibold mb-1">Exporting Reports</h4>
                <p className="text-sm text-muted-foreground">4:30</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Industry Benchmarks</CardTitle>
            <CardDescription>
              Reference data for comparing financial performance across industries
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="prose prose-slate max-w-none dark:prose-invert">
              <p className="text-muted-foreground">
                Understanding industry benchmarks helps you evaluate whether your financial ratios are healthy. Here are typical ranges for key industries:
              </p>

              <h4>Retail & E-Commerce</h4>
              <ul className="text-muted-foreground text-sm">
                <li>Current Ratio: 1.2 - 2.0</li>
                <li>Gross Profit Margin: 25% - 40%</li>
                <li>Net Profit Margin: 2% - 5%</li>
                <li>Inventory Turnover: 4 - 8 times/year</li>
                <li>ROA: 5% - 10%</li>
              </ul>

              <h4>Professional Services</h4>
              <ul className="text-muted-foreground text-sm">
                <li>Current Ratio: 1.5 - 2.5</li>
                <li>Gross Profit Margin: 50% - 70%</li>
                <li>Net Profit Margin: 10% - 20%</li>
                <li>Asset Turnover: 1.5 - 3.0</li>
                <li>ROE: 15% - 30%</li>
              </ul>

              <h4>Manufacturing</h4>
              <ul className="text-muted-foreground text-sm">
                <li>Current Ratio: 1.5 - 2.0</li>
                <li>Gross Profit Margin: 20% - 35%</li>
                <li>Net Profit Margin: 5% - 10%</li>
                <li>Inventory Turnover: 5 - 10 times/year</li>
                <li>Debt-to-Equity: 0.5 - 1.5</li>
              </ul>

              <h4>Technology & Software</h4>
              <ul className="text-muted-foreground text-sm">
                <li>Current Ratio: 2.0 - 4.0</li>
                <li>Gross Profit Margin: 60% - 85%</li>
                <li>Net Profit Margin: 15% - 30%</li>
                <li>ROA: 10% - 20%</li>
                <li>ROE: 20% - 40%</li>
              </ul>

              <p className="text-muted-foreground text-sm mt-4">
                <strong>Note:</strong> These are general guidelines. Actual benchmarks vary based on company size, maturity stage, geographic location, and specific business model. Use these as starting points for your analysis, not absolute standards.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Additional Learning Resources</h3>
            <p className="text-muted-foreground mb-6">
              Explore our comprehensive blog for detailed articles on accounting topics, visit our FAQ section for common questions, or check out our Help documentation for step-by-step guides.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/blog">
                <Button data-testid="button-blog">Read Our Blog</Button>
              </Link>
              <Link href="/faq">
                <Button variant="outline" data-testid="button-faq">View FAQ</Button>
              </Link>
              <Link href="/help">
                <Button variant="outline" data-testid="button-help-docs">Help Documentation</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
