import { jsPDF } from 'jspdf';
import { IncomeStatement, BalanceSheet, FinancialRatios, CashFlowStatement, EquityStatement } from '@shared/schema';

interface ExportData {
  incomeStatement?: IncomeStatement;
  balanceSheet?: BalanceSheet;
  cashFlowStatement?: CashFlowStatement;
  equityStatement?: EquityStatement;
  ratios?: FinancialRatios;
}

export async function exportToPDF(data: ExportData, selectedReports: string[]) {
  const pdf = new jsPDF();
  let currentPage = 1;
  const pageHeight = pdf.internal.pageSize.height;
  const margin = 20;
  let yPosition = margin;

  // Helper functions
  const addTitle = (text: string, fontSize: number = 16) => {
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', 'bold');
    pdf.text(text, margin, yPosition);
    yPosition += fontSize + 5;
  };

  const addSubtitle = (text: string) => {
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text(text, margin, yPosition);
    yPosition += 15;
  };

  const addText = (text: string, x: number = margin, rightAlign: boolean = false) => {
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    if (rightAlign) {
      const textWidth = pdf.getTextWidth(text);
      pdf.text(text, pdf.internal.pageSize.width - margin - textWidth, yPosition);
    } else {
      pdf.text(text, x, yPosition);
    }
    yPosition += 12;
  };

  const addLine = (y?: number) => {
    const lineY = y || yPosition - 6;
    pdf.line(margin, lineY, pdf.internal.pageSize.width - margin, lineY);
    if (!y) yPosition += 6;
  };

  const checkPageBreak = (requiredSpace: number = 40) => {
    if (yPosition + requiredSpace > pageHeight - margin) {
      pdf.addPage();
      currentPage++;
      yPosition = margin;
      return true;
    }
    return false;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const addTableRow = (leftText: string, rightText: string, indent: number = 0, bold: boolean = false) => {
    pdf.setFont('helvetica', bold ? 'bold' : 'normal');
    pdf.text(leftText, margin + indent, yPosition);
    const textWidth = pdf.getTextWidth(rightText);
    pdf.text(rightText, pdf.internal.pageSize.width - margin - textWidth, yPosition);
    yPosition += 12;
  };

  // Cover page
  addTitle('Financial Audit Report', 20);
  yPosition += 20;
  addText(`Generated on: ${new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })} at ${new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  })}`);
  addText('FinanceAudit Pro - Latest Financial Data');
  addText('This report contains the most current financial information available');
  yPosition += 40;

  if (selectedReports.length > 0) {
    addSubtitle('Contents:');
    selectedReports.forEach((report, index) => {
      const reportName = report.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
      addText(`${index + 1}. ${reportName}`);
    });
  }

  // Income Statement
  if (selectedReports.includes('income-statement') && data.incomeStatement) {
    checkPageBreak(100);
    addTitle('Income Statement');
    addLine();
    yPosition += 10;

    // Revenue section
    if (data.incomeStatement.revenue.length > 0) {
      addSubtitle('Revenue');
      data.incomeStatement.revenue.forEach(item => {
        addTableRow(item.name, formatCurrency(item.amount), 10);
      });
      addLine();
      addTableRow('Total Revenue', formatCurrency(data.incomeStatement.totalRevenue), 0, true);
      yPosition += 10;
    }

    // COGS section
    if (data.incomeStatement.costOfGoodsSold.length > 0) {
      checkPageBreak(60);
      addSubtitle('Cost of Goods Sold');
      data.incomeStatement.costOfGoodsSold.forEach(item => {
        addTableRow(item.name, `(${formatCurrency(item.amount)})`, 10);
      });
      addLine();
      addTableRow('Total Cost of Goods Sold', `(${formatCurrency(data.incomeStatement.totalCOGS)})`, 0, true);
      yPosition += 10;
    }

    // Gross Profit
    checkPageBreak(30);
    addLine();
    addTableRow('Gross Profit', formatCurrency(data.incomeStatement.grossProfit), 0, true);
    yPosition += 10;

    // Operating Expenses
    if (data.incomeStatement.operatingExpenses.length > 0) {
      checkPageBreak(60);
      addSubtitle('Operating Expenses');
      data.incomeStatement.operatingExpenses.forEach(item => {
        addTableRow(item.name, `(${formatCurrency(item.amount)})`, 10);
      });
      addLine();
      addTableRow('Total Operating Expenses', `(${formatCurrency(data.incomeStatement.totalOperatingExpenses)})`, 0, true);
      yPosition += 10;
    }

    // Operating Income
    checkPageBreak(30);
    addLine();
    addTableRow('Operating Income', formatCurrency(data.incomeStatement.operatingIncome), 0, true);
    yPosition += 10;

    // Other Income/Expenses
    if (data.incomeStatement.otherIncome.length > 0 || data.incomeStatement.otherExpenses.length > 0) {
      if (data.incomeStatement.otherIncome.length > 0) {
        checkPageBreak(50);
        addSubtitle('Other Income');
        data.incomeStatement.otherIncome.forEach(item => {
          addTableRow(item.name, formatCurrency(item.amount), 10);
        });
        addTableRow('Total Other Income', formatCurrency(data.incomeStatement.totalOtherIncome), 0, true);
        yPosition += 5;
      }

      if (data.incomeStatement.otherExpenses.length > 0) {
        checkPageBreak(50);
        addSubtitle('Other Expenses');
        data.incomeStatement.otherExpenses.forEach(item => {
          addTableRow(item.name, `(${formatCurrency(item.amount)})`, 10);
        });
        addTableRow('Total Other Expenses', `(${formatCurrency(data.incomeStatement.totalOtherExpenses)})`, 0, true);
        yPosition += 5;
      }
    }

    // Net Income
    checkPageBreak(30);
    addLine();
    addLine();
    addTableRow('NET INCOME', formatCurrency(data.incomeStatement.netIncome), 0, true);
  }

  // Balance Sheet
  if (selectedReports.includes('balance-sheet') && data.balanceSheet) {
    checkPageBreak(100);
    if (yPosition > margin + 50) {
      pdf.addPage();
      yPosition = margin;
    }

    addTitle('Balance Sheet');
    addLine();
    yPosition += 10;

    // Assets section
    addSubtitle('ASSETS');
    
    // Current Assets
    if (data.balanceSheet.currentAssets.length > 0) {
      addText('Current Assets:', margin, false);
      data.balanceSheet.currentAssets.forEach(item => {
        addTableRow(item.name, formatCurrency(item.amount), 20);
      });
      addLine(yPosition - 6);
      addTableRow('Total Current Assets', formatCurrency(data.balanceSheet.totalCurrentAssets), 10, true);
      yPosition += 5;
    }

    // Non-Current Assets
    if (data.balanceSheet.nonCurrentAssets.length > 0) {
      checkPageBreak(50);
      addText('Non-Current Assets:', margin, false);
      data.balanceSheet.nonCurrentAssets.forEach(item => {
        addTableRow(item.name, formatCurrency(item.amount), 20);
      });
      addLine(yPosition - 6);
      addTableRow('Total Non-Current Assets', formatCurrency(data.balanceSheet.totalNonCurrentAssets), 10, true);
      yPosition += 5;
    }

    // Total Assets
    checkPageBreak(30);
    addLine();
    addTableRow('TOTAL ASSETS', formatCurrency(data.balanceSheet.totalAssets), 0, true);
    yPosition += 20;

    // Liabilities and Equity
    checkPageBreak(60);
    addSubtitle('LIABILITIES AND EQUITY');

    // Current Liabilities
    if (data.balanceSheet.currentLiabilities.length > 0) {
      addText('Current Liabilities:', margin, false);
      data.balanceSheet.currentLiabilities.forEach(item => {
        addTableRow(item.name, formatCurrency(item.amount), 20);
      });
      addLine(yPosition - 6);
      addTableRow('Total Current Liabilities', formatCurrency(data.balanceSheet.totalCurrentLiabilities), 10, true);
      yPosition += 5;
    }

    // Non-Current Liabilities
    if (data.balanceSheet.nonCurrentLiabilities.length > 0) {
      checkPageBreak(50);
      addText('Non-Current Liabilities:', margin, false);
      data.balanceSheet.nonCurrentLiabilities.forEach(item => {
        addTableRow(item.name, formatCurrency(item.amount), 20);
      });
      addLine(yPosition - 6);
      addTableRow('Total Non-Current Liabilities', formatCurrency(data.balanceSheet.totalNonCurrentLiabilities), 10, true);
      yPosition += 5;
    }

    // Total Liabilities
    checkPageBreak(30);
    addLine(yPosition - 6);
    addTableRow('Total Liabilities', formatCurrency(data.balanceSheet.totalLiabilities), 0, true);
    yPosition += 10;

    // Equity
    if (data.balanceSheet.equity.length > 0) {
      checkPageBreak(50);
      addText('Equity:', margin, false);
      data.balanceSheet.equity.forEach(item => {
        addTableRow(item.name, formatCurrency(item.amount), 20);
      });
      addLine(yPosition - 6);
      addTableRow('Total Equity', formatCurrency(data.balanceSheet.totalEquity), 10, true);
      yPosition += 5;
    }

    // Total Liabilities and Equity
    checkPageBreak(30);
    addLine();
    addTableRow('TOTAL LIABILITIES AND EQUITY', formatCurrency(data.balanceSheet.totalLiabilitiesAndEquity), 0, true);
  }

  // Cash Flow Statement
  if (selectedReports.includes('cash-flow-statement') && data.cashFlowStatement) {
    checkPageBreak(100);
    if (yPosition > margin + 50) {
      pdf.addPage();
      yPosition = margin;
    }

    addTitle('Statement of Cash Flows');
    addLine();
    yPosition += 10;

    // Operating Activities
    addSubtitle('Operating Activities');
    addTableRow('Net Income', formatCurrency(data.cashFlowStatement.operatingActivities.netIncome));
    
    if (data.cashFlowStatement.operatingActivities.adjustments.length > 0) {
      yPosition += 5;
      addText('Adjustments for Non-Cash Items:', margin, false);
      data.cashFlowStatement.operatingActivities.adjustments.forEach(adj => {
        addTableRow(adj.name, formatCurrency(adj.amount), 20);
      });
    }

    if (data.cashFlowStatement.operatingActivities.workingCapitalChanges.length > 0) {
      checkPageBreak(40);
      yPosition += 5;
      addText('Changes in Working Capital:', margin, false);
      data.cashFlowStatement.operatingActivities.workingCapitalChanges.forEach(change => {
        addTableRow(change.name, formatCurrency(change.amount), 20);
      });
    }

    checkPageBreak(30);
    addLine();
    addTableRow('Net Cash from Operating Activities', 
      formatCurrency(data.cashFlowStatement.operatingActivities.totalOperatingCashFlow), 0, true);
    yPosition += 10;

    // Investing Activities
    checkPageBreak(50);
    addSubtitle('Investing Activities');
    data.cashFlowStatement.investingActivities.activities.forEach(activity => {
      addTableRow(activity.name, formatCurrency(activity.amount), 10);
    });
    addLine();
    addTableRow('Net Cash from Investing Activities', 
      formatCurrency(data.cashFlowStatement.investingActivities.totalInvestingCashFlow), 0, true);
    yPosition += 10;

    // Financing Activities
    checkPageBreak(50);
    addSubtitle('Financing Activities');
    data.cashFlowStatement.financingActivities.activities.forEach(activity => {
      addTableRow(activity.name, formatCurrency(activity.amount), 10);
    });
    addLine();
    addTableRow('Net Cash from Financing Activities', 
      formatCurrency(data.cashFlowStatement.financingActivities.totalFinancingCashFlow), 0, true);
    yPosition += 15;

    // Net Cash Flow Summary
    checkPageBreak(60);
    addLine();
    addTableRow('Beginning Cash', formatCurrency(data.cashFlowStatement.beginningCash), 0, true);
    addTableRow('Net Cash Flow', formatCurrency(data.cashFlowStatement.netCashFlow), 0, true);
    addLine();
    addTableRow('ENDING CASH', formatCurrency(data.cashFlowStatement.endingCash), 0, true);
  }

  // Statement of Equity
  if (selectedReports.includes('equity-statement') && data.equityStatement) {
    checkPageBreak(100);
    if (yPosition > margin + 50) {
      pdf.addPage();
      yPosition = margin;
    }

    addTitle('Statement of Changes in Equity');
    addLine();
    yPosition += 10;

    addTableRow('Beginning Equity', formatCurrency(data.equityStatement.totalBeginningEquity), 0, true);
    yPosition += 5;

    // Equity Components
    addSubtitle('Changes in Equity Components');
    data.equityStatement.equityComponents.forEach(component => {
      checkPageBreak(20);
      addText(`${component.name}:`, margin, false);
      addTableRow('Beginning Balance', formatCurrency(component.beginningBalance), 20);
      if (component.additions !== 0) {
        addTableRow('Additions', formatCurrency(component.additions), 20);
      }
      if (component.reductions !== 0) {
        addTableRow('Reductions', formatCurrency(-Math.abs(component.reductions)), 20);
      }
      addLine(yPosition - 6);
      addTableRow('Ending Balance', formatCurrency(component.endingBalance), 20, true);
      yPosition += 10;
    });

    // Total Changes and Ending Equity
    checkPageBreak(40);
    addLine();
    addTableRow('Total Changes in Equity', formatCurrency(data.equityStatement.totalNetChanges), 0, true);
    addLine();
    addTableRow('ENDING EQUITY', formatCurrency(data.equityStatement.totalEndingEquity), 0, true);
  }

  // Financial Ratios
  if (selectedReports.includes('financial-ratios') && data.ratios) {
    checkPageBreak(100);
    if (yPosition > margin + 50) {
      pdf.addPage();
      yPosition = margin;
    }

    addTitle('Financial Ratios Analysis');
    addLine();
    yPosition += 10;

    // Liquidity Ratios
    addSubtitle('Liquidity Ratios');
    addTableRow('Current Ratio', data.ratios.currentRatio.toFixed(2));
    addTableRow('Quick Ratio', data.ratios.quickRatio.toFixed(2));
    addTableRow('Cash Ratio', data.ratios.cashRatio.toFixed(2));
    addTableRow('Working Capital', formatCurrency(data.ratios.workingCapital));
    yPosition += 10;

    // Profitability Ratios
    checkPageBreak(80);
    addSubtitle('Profitability Ratios');
    addTableRow('Gross Margin', `${data.ratios.grossMargin.toFixed(1)}%`);
    addTableRow('Operating Margin', `${data.ratios.operatingMargin.toFixed(1)}%`);
    addTableRow('Net Margin', `${data.ratios.netMargin.toFixed(1)}%`);
    addTableRow('Return on Equity (ROE)', `${data.ratios.returnOnEquity.toFixed(1)}%`);
    addTableRow('Return on Assets (ROA)', `${data.ratios.returnOnAssets.toFixed(1)}%`);
    addTableRow('Return on Investment (ROI)', `${data.ratios.returnOnInvestment.toFixed(1)}%`);
    yPosition += 10;

    // Efficiency/Activity Ratios
    checkPageBreak(60);
    addSubtitle('Efficiency/Activity Ratios');
    addTableRow('Asset Turnover', data.ratios.assetTurnover.toFixed(2));
    addTableRow('Receivables Turnover', data.ratios.receivablesTurnover.toFixed(2));
    addTableRow('Inventory Turnover', data.ratios.inventoryTurnover.toFixed(2));
    addTableRow('Payables Turnover', data.ratios.payablesTurnover.toFixed(2));
    yPosition += 10;

    // Leverage/Solvency Ratios
    checkPageBreak(60);
    addSubtitle('Leverage/Solvency Ratios');
    addTableRow('Debt-to-Equity Ratio', data.ratios.debtToEquityRatio.toFixed(2));
    addTableRow('Debt Ratio', data.ratios.debtRatio.toFixed(2));
    addTableRow('Equity Ratio', data.ratios.equityRatio.toFixed(2));
    addTableRow('Interest Coverage', data.ratios.interestCoverage.toFixed(2));
  }

  // Footer on each page
  const totalPages = pdf.internal.pages.length - 1; // Subtract 1 because pages array includes a null element
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Page ${i} of ${totalPages}`, pdf.internal.pageSize.width - 40, pdf.internal.pageSize.height - 10);
    pdf.text('Generated by FinanceAudit Pro', margin, pdf.internal.pageSize.height - 10);
  }

  // Download the PDF
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('.')[0];
  const fileName = `Financial_Audit_Report_${timestamp}.pdf`;
  pdf.save(fileName);
}
