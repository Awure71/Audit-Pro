import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileBarChart, Scale, Calculator } from "lucide-react";
import { Link } from "wouter";
import { IncomeStatement, BalanceSheet, FinancialRatios } from "@shared/schema";

interface FinancialPreviewCardsProps {
  projectId: string;
  formatCurrency: (amount: number) => string;
}

export default function FinancialPreviewCards({ projectId, formatCurrency }: FinancialPreviewCardsProps) {
  const { data: incomeStatement } = useQuery<IncomeStatement>({
    queryKey: ["/api/projects", projectId, "income-statement"],
  });

  const { data: balanceSheet } = useQuery<BalanceSheet>({
    queryKey: ["/api/projects", projectId, "balance-sheet"],
  });

  const { data: ratios } = useQuery<FinancialRatios>({
    queryKey: ["/api/projects", projectId, "financial-ratios"],
  });

  const getRatioColor = (ratio: number, type: 'current' | 'margin' | 'roe') => {
    switch (type) {
      case 'current':
        return ratio >= 2 ? 'text-green-800 bg-green-100' : ratio >= 1 ? 'text-yellow-800 bg-yellow-100' : 'text-red-800 bg-red-100';
      case 'margin':
        return ratio >= 20 ? 'text-green-800 bg-green-100' : ratio >= 10 ? 'text-yellow-800 bg-yellow-100' : 'text-red-800 bg-red-100';
      case 'roe':
        return ratio >= 15 ? 'text-green-800 bg-green-100' : ratio >= 8 ? 'text-yellow-800 bg-yellow-100' : 'text-red-800 bg-red-100';
      default:
        return 'text-green-800 bg-green-100';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="financial-preview-cards">
      {/* Income Statement Preview */}
      <Card data-testid="income-statement-preview">
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <FileBarChart className="text-primary mr-2 h-5 w-5" />
            Income Statement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Revenue</span>
            <span className="font-mono text-foreground">
              {incomeStatement ? formatCurrency(incomeStatement.totalRevenue) : formatCurrency(0)}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Cost of Goods Sold</span>
            <span className="font-mono text-foreground">
              ({incomeStatement ? formatCurrency(incomeStatement.totalCOGS) : formatCurrency(0)})
            </span>
          </div>
          <div className="border-t border-border pt-2">
            <div className="flex justify-between text-sm font-semibold">
              <span className="text-foreground">Gross Profit</span>
              <span className="font-mono text-green-600">
                {incomeStatement ? formatCurrency(incomeStatement.grossProfit) : formatCurrency(0)}
              </span>
            </div>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Operating Expenses</span>
            <span className="font-mono text-foreground">
              ({incomeStatement ? formatCurrency(incomeStatement.totalOperatingExpenses) : formatCurrency(0)})
            </span>
          </div>
          <div className="border-t border-border pt-2">
            <div className="flex justify-between font-semibold">
              <span className="text-foreground">Net Income</span>
              <span className="font-mono text-green-600">
                {incomeStatement ? formatCurrency(incomeStatement.netIncome) : formatCurrency(0)}
              </span>
            </div>
          </div>
          <Link href="/income-statement">
            <Button variant="secondary" className="w-full mt-4" data-testid="button-view-income-statement">
              View Full Statement
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Balance Sheet Preview */}
      <Card data-testid="balance-sheet-preview">
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <Scale className="text-primary mr-2 h-5 w-5" />
            Balance Sheet
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm font-medium text-foreground">Assets</div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground ml-4">Current Assets</span>
            <span className="font-mono text-foreground">
              {balanceSheet ? formatCurrency(balanceSheet.totalCurrentAssets) : formatCurrency(0)}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground ml-4">Non-Current Assets</span>
            <span className="font-mono text-foreground">
              {balanceSheet ? formatCurrency(balanceSheet.totalNonCurrentAssets) : formatCurrency(0)}
            </span>
          </div>
          <div className="border-t border-border pt-2">
            <div className="flex justify-between text-sm font-semibold">
              <span className="text-foreground">Total Assets</span>
              <span className="font-mono text-foreground">
                {balanceSheet ? formatCurrency(balanceSheet.totalAssets) : formatCurrency(0)}
              </span>
            </div>
          </div>
          <div className="text-sm font-medium text-foreground mt-4">Liabilities & Equity</div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground ml-4">Current Liabilities</span>
            <span className="font-mono text-foreground">
              {balanceSheet ? formatCurrency(balanceSheet.totalCurrentLiabilities) : formatCurrency(0)}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground ml-4">Equity</span>
            <span className="font-mono text-foreground">
              {balanceSheet ? formatCurrency(balanceSheet.totalEquity) : formatCurrency(0)}
            </span>
          </div>
          <Link href="/balance-sheet">
            <Button variant="secondary" className="w-full mt-4" data-testid="button-view-balance-sheet">
              View Full Statement
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Financial Ratios Preview */}
      <Card data-testid="financial-ratios-preview">
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <Calculator className="text-primary mr-2 h-5 w-5" />
            Key Ratios
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Current Ratio</span>
            <span className={`text-sm font-mono px-2 py-1 rounded ${
              ratios ? getRatioColor(ratios.currentRatio, 'current') : 'text-gray-600 bg-gray-100'
            }`}>
              {ratios ? ratios.currentRatio.toFixed(2) : '0.00'}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Gross Margin</span>
            <span className={`text-sm font-mono px-2 py-1 rounded ${
              ratios ? getRatioColor(ratios.grossMargin, 'margin') : 'text-gray-600 bg-gray-100'
            }`}>
              {ratios ? `${ratios.grossMargin.toFixed(1)}%` : '0.0%'}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Net Margin</span>
            <span className={`text-sm font-mono px-2 py-1 rounded ${
              ratios ? getRatioColor(ratios.netMargin, 'margin') : 'text-gray-600 bg-gray-100'
            }`}>
              {ratios ? `${ratios.netMargin.toFixed(1)}%` : '0.0%'}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Debt-to-Equity</span>
            <span className={`text-sm font-mono px-2 py-1 rounded ${
              ratios ? (ratios.debtToEquityRatio <= 1 ? 'text-green-800 bg-green-100' : 'text-yellow-800 bg-yellow-100') : 'text-gray-600 bg-gray-100'
            }`}>
              {ratios ? ratios.debtToEquityRatio.toFixed(2) : '0.00'}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">ROE</span>
            <span className={`text-sm font-mono px-2 py-1 rounded ${
              ratios ? getRatioColor(ratios.returnOnEquity, 'roe') : 'text-gray-600 bg-gray-100'
            }`}>
              {ratios ? `${ratios.returnOnEquity.toFixed(1)}%` : '0.0%'}
            </span>
          </div>
          <Link href="/financial-ratios">
            <Button variant="secondary" className="w-full mt-4" data-testid="button-view-ratios">
              View All Ratios
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
