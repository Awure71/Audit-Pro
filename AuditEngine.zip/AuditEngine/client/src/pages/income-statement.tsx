import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileBarChart, Download, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { IncomeStatement } from "@shared/schema";

export default function IncomeStatementPage() {
  const projectId = "default";

  const { data: incomeStatement, isLoading } = useQuery<IncomeStatement>({
    queryKey: ["/api/projects", projectId, "income-statement"],
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading income statement...</div>
      </div>
    );
  }

  if (!incomeStatement) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No income statement data available. Please add trial balance entries first.</p>
            <Link href="/">
              <Button className="mt-4">Go to Trial Balance</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Income Statement
              </h2>
              <p className="text-sm text-muted-foreground">
                Comprehensive profit and loss statement
              </p>
            </div>
          </div>
          <Button data-testid="button-export-pdf">
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <Card data-testid="income-statement-detail">
          <CardHeader>
            <CardTitle className="flex items-center text-xl">
              <FileBarChart className="text-primary mr-3 h-6 w-6" />
              Income Statement
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Revenue Section */}
            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-foreground">Revenue</h3>
              <div className="ml-4 space-y-1">
                {incomeStatement.revenue.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.name}</span>
                    <span className="font-mono">{formatCurrency(item.amount)}</span>
                  </div>
                ))}
                <div className="border-t pt-1 mt-2">
                  <div className="flex justify-between font-semibold">
                    <span>Total Revenue</span>
                    <span className="font-mono">{formatCurrency(incomeStatement.totalRevenue)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Cost of Goods Sold Section */}
            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-foreground">Cost of Goods Sold</h3>
              <div className="ml-4 space-y-1">
                {incomeStatement.costOfGoodsSold.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.name}</span>
                    <span className="font-mono">({formatCurrency(item.amount)})</span>
                  </div>
                ))}
                <div className="border-t pt-1 mt-2">
                  <div className="flex justify-between font-semibold">
                    <span>Total COGS</span>
                    <span className="font-mono">({formatCurrency(incomeStatement.totalCOGS)})</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Gross Profit */}
            <div className="border-t pt-4">
              <div className="flex justify-between font-bold text-lg">
                <span className="text-foreground">Gross Profit</span>
                <span className="font-mono text-green-600">{formatCurrency(incomeStatement.grossProfit)}</span>
              </div>
            </div>

            {/* Operating Expenses Section */}
            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-foreground">Operating Expenses</h3>
              <div className="ml-4 space-y-1">
                {incomeStatement.operatingExpenses.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.name}</span>
                    <span className="font-mono">({formatCurrency(item.amount)})</span>
                  </div>
                ))}
                <div className="border-t pt-1 mt-2">
                  <div className="flex justify-between font-semibold">
                    <span>Total Operating Expenses</span>
                    <span className="font-mono">({formatCurrency(incomeStatement.totalOperatingExpenses)})</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Operating Income */}
            <div className="border-t pt-4">
              <div className="flex justify-between font-bold text-lg">
                <span className="text-foreground">Operating Income</span>
                <span className="font-mono text-blue-600">{formatCurrency(incomeStatement.operatingIncome)}</span>
              </div>
            </div>

            {/* Other Income/Expenses */}
            {(incomeStatement.otherIncome.length > 0 || incomeStatement.otherExpenses.length > 0) && (
              <>
                {incomeStatement.otherIncome.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg text-foreground">Other Income</h3>
                    <div className="ml-4 space-y-1">
                      {incomeStatement.otherIncome.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{item.name}</span>
                          <span className="font-mono">{formatCurrency(item.amount)}</span>
                        </div>
                      ))}
                      <div className="border-t pt-1 mt-2">
                        <div className="flex justify-between font-semibold">
                          <span>Total Other Income</span>
                          <span className="font-mono">{formatCurrency(incomeStatement.totalOtherIncome)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {incomeStatement.otherExpenses.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg text-foreground">Other Expenses</h3>
                    <div className="ml-4 space-y-1">
                      {incomeStatement.otherExpenses.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{item.name}</span>
                          <span className="font-mono">({formatCurrency(item.amount)})</span>
                        </div>
                      ))}
                      <div className="border-t pt-1 mt-2">
                        <div className="flex justify-between font-semibold">
                          <span>Total Other Expenses</span>
                          <span className="font-mono">({formatCurrency(incomeStatement.totalOtherExpenses)})</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Net Income */}
            <div className="border-t-2 border-primary pt-4">
              <div className="flex justify-between font-bold text-xl">
                <span className="text-foreground">Net Income</span>
                <span className={`font-mono ${incomeStatement.netIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(incomeStatement.netIncome)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
