import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileDown, ArrowLeft, FileText, CheckCircle, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { exportToPDF } from "@/lib/pdf-export";
import { queryClient } from "@/lib/queryClient";
import { IncomeStatement, BalanceSheet, FinancialRatios, currencies } from "@shared/schema";

export default function ExportReportsPage() {
  const projectId = "default";
  const [selectedReports, setSelectedReports] = useState<string[]>(["income-statement", "balance-sheet", "financial-ratios"]);
  const [exportFormat, setExportFormat] = useState("pdf");
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const { data: incomeStatement, refetch: refetchIncomeStatement } = useQuery<IncomeStatement>({
    queryKey: ["/api/projects", projectId, "income-statement"],
    staleTime: 0, // Always fetch fresh data for audit reports
  });

  const { data: balanceSheet, refetch: refetchBalanceSheet } = useQuery<BalanceSheet>({
    queryKey: ["/api/projects", projectId, "balance-sheet"],
    staleTime: 0, // Always fetch fresh data for audit reports
  });

  const { data: ratios, refetch: refetchRatios } = useQuery<FinancialRatios>({
    queryKey: ["/api/projects", projectId, "financial-ratios"],
    staleTime: 0, // Always fetch fresh data for audit reports
  });

  const reports = [
    {
      id: "income-statement",
      name: "Income Statement",
      description: "Profit and loss statement showing revenue, expenses, and net income",
      data: incomeStatement,
    },
    {
      id: "balance-sheet",
      name: "Balance Sheet",
      description: "Financial position showing assets, liabilities, and equity",
      data: balanceSheet,
    },
    {
      id: "financial-ratios",
      name: "Financial Ratios",
      description: "Comprehensive ratio analysis for performance evaluation",
      data: ratios,
    },
  ];

  const handleReportToggle = (reportId: string) => {
    setSelectedReports(prev => 
      prev.includes(reportId)
        ? prev.filter(id => id !== reportId)
        : [...prev, reportId]
    );
  };

  const refreshAllData = async () => {
    toast({
      title: "Refreshing Data",
      description: "Fetching latest financial data for audit reports...",
    });
    
    try {
      // Refresh all financial data and get fresh datasets
      const [incomeResult, balanceResult, ratiosResult] = await Promise.all([
        refetchIncomeStatement(),
        refetchBalanceSheet(),
        refetchRatios(),
      ]);
      
      // Check if any refetch failed
      if (incomeResult.isError || balanceResult.isError || ratiosResult.isError) {
        throw new Error("One or more data fetches failed");
      }
      
      toast({
        title: "Data Refreshed",
        description: "All financial data has been updated to the latest version",
      });
      
      // Return the fresh data
      return {
        incomeStatement: incomeResult.data,
        balanceSheet: balanceResult.data,
        ratios: ratiosResult.data,
      };
    } catch (error) {
      toast({
        title: "Refresh Failed", 
        description: "Unable to refresh financial data. Please try again.",
        variant: "destructive"
      });
      throw error; // Propagate error to caller
    }
  };

  const handleExport = async () => {
    if (selectedReports.length === 0) {
      toast({
        title: "No Reports Selected",
        description: "Please select at least one report to export",
        variant: "destructive"
      });
      return;
    }

    setIsExporting(true);
    
    try {
      // First, ensure we have the latest data before generating audit reports
      const freshData = await refreshAllData();
      
      const selectedData = {
        incomeStatement: selectedReports.includes("income-statement") ? freshData.incomeStatement : undefined,
        balanceSheet: selectedReports.includes("balance-sheet") ? freshData.balanceSheet : undefined,
        ratios: selectedReports.includes("financial-ratios") ? freshData.ratios : undefined,
      };

      if (exportFormat === "pdf") {
        await exportToPDF(selectedData, selectedReports);
        toast({
          title: "Audit Report Generated",
          description: "Financial audit reports exported with latest data as PDF"
        });
      } else {
        // Handle other export formats (CSV, Excel) here in the future
        toast({
          title: "Feature Coming Soon",
          description: "Additional export formats will be available soon"
        });
      }
    } catch (error) {
      if (error instanceof Error && error.message.includes("data fetches failed")) {
        toast({
          title: "Export Aborted",
          description: "Could not refresh financial data. Please try again.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Export Failed",
          description: "Failed to export reports. Please try again.",
          variant: "destructive"
        });
      }
    } finally {
      setIsExporting(false);
    }
  };

  const hasData = incomeStatement || balanceSheet || ratios;

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Export Reports
              </h2>
              <p className="text-sm text-muted-foreground">
                Generate audit reports with latest financial data
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={refreshAllData}
              className="flex items-center gap-2"
              data-testid="button-refresh-data"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh Data
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 space-y-6">
        {!hasData ? (
          <Card data-testid="no-data-notice">
            <CardContent className="p-6 text-center">
              <FileText className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                No Financial Data Available
              </h3>
              <p className="text-muted-foreground mb-6">
                Please add trial balance entries to generate financial statements before exporting reports.
              </p>
              <Link href="/">
                <Button>Go to Trial Balance</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Export Configuration */}
            <Card data-testid="export-config">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileDown className="text-primary mr-2 h-5 w-5" />
                  Export Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Report Selection */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Select Reports to Export</h3>
                  <div className="space-y-3">
                    {reports.map((report) => (
                      <div
                        key={report.id}
                        className="flex items-start space-x-3 p-3 border border-border rounded-lg hover:bg-accent/50"
                        data-testid={`report-option-${report.id}`}
                      >
                        <Checkbox
                          id={report.id}
                          checked={selectedReports.includes(report.id)}
                          onCheckedChange={() => handleReportToggle(report.id)}
                          disabled={!report.data}
                        />
                        <div className="flex-1 min-w-0">
                          <label
                            htmlFor={report.id}
                            className={`font-medium cursor-pointer ${
                              report.data ? 'text-foreground' : 'text-muted-foreground'
                            }`}
                          >
                            {report.name}
                            {report.data && (
                              <CheckCircle className="inline ml-2 h-4 w-4 text-green-600" />
                            )}
                          </label>
                          <p className="text-sm text-muted-foreground mt-1">
                            {report.description}
                          </p>
                          {!report.data && (
                            <p className="text-xs text-red-600 mt-1">
                              No data available - add trial balance entries first
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Export Format */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Export Format</h3>
                  <Select value={exportFormat} onValueChange={setExportFormat} data-testid="select-export-format">
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Document</SelectItem>
                      <SelectItem value="csv" disabled>CSV Files (Coming Soon)</SelectItem>
                      <SelectItem value="excel" disabled>Excel Workbook (Coming Soon)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Export Options */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Export Options</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="p-4">
                      <h4 className="font-medium text-foreground mb-2">Professional Formatting</h4>
                      <p className="text-sm text-muted-foreground">
                        Clean, professional layout suitable for auditors and stakeholders
                      </p>
                    </Card>
                    <Card className="p-4">
                      <h4 className="font-medium text-foreground mb-2">Multi-Currency Support</h4>
                      <p className="text-sm text-muted-foreground">
                        Amounts displayed in your selected currency format
                      </p>
                    </Card>
                  </div>
                </div>

                {/* Export Button */}
                <div className="flex justify-center pt-4">
                  <Button
                    size="lg"
                    onClick={handleExport}
                    disabled={isExporting || selectedReports.length === 0}
                    data-testid="button-export-reports"
                  >
                    <FileDown className="mr-2 h-4 w-4" />
                    {isExporting ? "Exporting..." : `Export ${selectedReports.length} Report${selectedReports.length !== 1 ? 's' : ''}`}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Export Preview */}
            <Card data-testid="export-preview">
              <CardHeader>
                <CardTitle>Export Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {selectedReports.map((reportId) => {
                    const report = reports.find(r => r.id === reportId);
                    return report ? (
                      <div
                        key={reportId}
                        className="p-4 border border-border rounded-lg text-center"
                        data-testid={`preview-${reportId}`}
                      >
                        <FileText className="mx-auto h-8 w-8 text-primary mb-2" />
                        <h4 className="font-medium text-foreground">{report.name}</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          Ready for export
                        </p>
                      </div>
                    ) : null;
                  })}
                </div>
                {selectedReports.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    Select reports above to see preview
                  </p>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  );
}
