import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Globe, ArrowLeft, Save, RotateCcw, Settings as SettingsIcon } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { currencies, type Project } from "@shared/schema";

export default function SettingsPage() {
  const projectId = "default";
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [tempCurrency, setTempCurrency] = useState("");
  const [tempProjectName, setTempProjectName] = useState("");

  const { data: project, isLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  // Set temporary values when project data is available
  if (project && tempCurrency === "" && tempProjectName === "") {
    setTempCurrency(project.currency);
    setTempProjectName(project.name);
  }

  const updateProjectMutation = useMutation({
    mutationFn: (updates: { name?: string; currency?: string }) =>
      apiRequest("PUT", `/api/projects/${projectId}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId] });
      toast({
        title: "Settings Saved",
        description: "Your preferences have been updated successfully"
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save settings. Please try again.",
        variant: "destructive"
      });
    },
  });

  const handleSave = () => {
    const updates: { name?: string; currency?: string } = {};
    
    if (project && tempProjectName !== project.name) {
      updates.name = tempProjectName;
    }
    
    if (project && tempCurrency !== project.currency) {
      updates.currency = tempCurrency;
    }
    
    if (Object.keys(updates).length > 0) {
      updateProjectMutation.mutate(updates);
    } else {
      toast({
        title: "No Changes",
        description: "No settings were modified"
      });
    }
  };

  const handleReset = () => {
    if (project) {
      setTempCurrency(project.currency);
      setTempProjectName(project.name);
      toast({
        title: "Settings Reset",
        description: "Settings have been reset to saved values"
      });
    }
  };

  const hasChanges = project && (tempCurrency !== project.currency || tempProjectName !== project.name);

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading settings...</div>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Settings
              </h2>
              <p className="text-sm text-muted-foreground">
                Configure application preferences and project settings
              </p>
            </div>
          </div>
          {hasChanges && (
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleReset}
                data-testid="button-reset-settings"
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button 
                size="sm"
                onClick={handleSave}
                disabled={updateProjectMutation.isPending}
                data-testid="button-save-settings"
              >
                <Save className="mr-2 h-4 w-4" />
                {updateProjectMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 space-y-6 max-w-4xl">
        {/* Project Settings */}
        <Card data-testid="project-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <SettingsIcon className="text-primary mr-2 h-5 w-5" />
              Project Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="project-name">Project Name</Label>
              <Input
                id="project-name"
                value={tempProjectName}
                onChange={(e) => setTempProjectName(e.target.value)}
                placeholder="Enter project name"
                data-testid="input-project-name"
              />
              <p className="text-sm text-muted-foreground">
                This name will appear on exported financial reports
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label htmlFor="project-currency">Default Currency</Label>
              <Select 
                value={tempCurrency} 
                onValueChange={setTempCurrency} 
                data-testid="select-project-currency"
              >
                <SelectTrigger id="project-currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      <div className="flex items-center">
                        <span className="font-mono mr-2">{currency.symbol}</span>
                        <span>{currency.name} ({currency.code})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                All amounts will be displayed and exported in this currency
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Regional Settings */}
        <Card data-testid="regional-settings">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="text-primary mr-2 h-5 w-5" />
              Regional Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Number Format</Label>
                <div className="text-sm text-muted-foreground">
                  Numbers will be formatted according to your selected currency and locale
                </div>
                <div className="p-3 bg-muted/50 rounded-lg font-mono text-sm">
                  Example: {new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: tempCurrency || 'USD',
                    minimumFractionDigits: 2,
                  }).format(123456.78)}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Date Format</Label>
                <div className="text-sm text-muted-foreground">
                  Dates will be displayed in standard format
                </div>
                <div className="p-3 bg-muted/50 rounded-lg font-mono text-sm">
                  Example: {new Date().toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Export Settings */}
        <Card data-testid="export-settings">
          <CardHeader>
            <CardTitle>Export Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-foreground">PDF Export Options</h4>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Professional formatting enabled
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Company logo support (coming soon)
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Multi-page reports
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Digital signatures (coming soon)
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-foreground">Data Import Settings</h4>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Automatic account classification
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    CSV format validation
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Duplicate detection
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
                    Excel import (coming soon)
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Information */}
        <Card data-testid="system-info">
          <CardHeader>
            <CardTitle>System Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Application Version:</span>
                  <span className="font-mono">1.0.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Project Created:</span>
                  <span className="font-mono">
                    {project?.createdAt ? new Date(project.createdAt).toLocaleDateString() : 'N/A'}
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Storage Type:</span>
                  <span className="font-mono">In-Memory</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Data Backup:</span>
                  <span className="font-mono">Session-based</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
