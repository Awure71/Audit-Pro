import { TrialBalanceEntry, IncomeStatement, BalanceSheet, FinancialRatios, CashFlowStatement, EquityStatement } from "@shared/schema";

export function calculateIncomeStatement(entries: TrialBalanceEntry[]): IncomeStatement {
  const revenue = entries
    .filter(e => e.category === "Revenue")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.creditAmount || "0") }));
  
  const costOfGoodsSold = entries
    .filter(e => e.category === "Cost of Goods Sold")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.debitAmount || "0") }));
  
  const operatingExpenses = entries
    .filter(e => e.category === "Operating Expenses")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.debitAmount || "0") }));
  
  const otherIncome = entries
    .filter(e => e.category === "Other Income")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.creditAmount || "0") }));
  
  const otherExpenses = entries
    .filter(e => e.category === "Other Expenses")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.debitAmount || "0") }));

  const totalRevenue = revenue.reduce((sum, item) => sum + item.amount, 0);
  const totalCOGS = costOfGoodsSold.reduce((sum, item) => sum + item.amount, 0);
  const grossProfit = totalRevenue - totalCOGS;
  const totalOperatingExpenses = operatingExpenses.reduce((sum, item) => sum + item.amount, 0);
  const operatingIncome = grossProfit - totalOperatingExpenses;
  const totalOtherIncome = otherIncome.reduce((sum, item) => sum + item.amount, 0);
  const totalOtherExpenses = otherExpenses.reduce((sum, item) => sum + item.amount, 0);
  const netIncome = operatingIncome + totalOtherIncome - totalOtherExpenses;

  return {
    revenue,
    costOfGoodsSold,
    operatingExpenses,
    otherIncome,
    otherExpenses,
    totalRevenue,
    totalCOGS,
    grossProfit,
    totalOperatingExpenses,
    operatingIncome,
    totalOtherIncome,
    totalOtherExpenses,
    netIncome,
  };
}

export function calculateBalanceSheet(entries: TrialBalanceEntry[]): BalanceSheet {
  const currentAssets = entries
    .filter(e => e.category === "Current Assets")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.debitAmount || "0") - parseFloat(e.creditAmount || "0") }))
    .filter(item => item.amount !== 0);
  
  const nonCurrentAssets = entries
    .filter(e => e.category === "Non-Current Assets")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.debitAmount || "0") - parseFloat(e.creditAmount || "0") }))
    .filter(item => item.amount !== 0);
  
  const currentLiabilities = entries
    .filter(e => e.category === "Current Liabilities")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.creditAmount || "0") - parseFloat(e.debitAmount || "0") }))
    .filter(item => item.amount !== 0);
  
  const nonCurrentLiabilities = entries
    .filter(e => e.category === "Non-Current Liabilities")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.creditAmount || "0") - parseFloat(e.debitAmount || "0") }))
    .filter(item => item.amount !== 0);
  
  const equity = entries
    .filter(e => e.category === "Equity")
    .map(e => ({ name: e.accountName, amount: parseFloat(e.creditAmount || "0") - parseFloat(e.debitAmount || "0") }))
    .filter(item => item.amount !== 0);

  const totalCurrentAssets = currentAssets.reduce((sum, item) => sum + item.amount, 0);
  const totalNonCurrentAssets = nonCurrentAssets.reduce((sum, item) => sum + item.amount, 0);
  const totalAssets = totalCurrentAssets + totalNonCurrentAssets;
  const totalCurrentLiabilities = currentLiabilities.reduce((sum, item) => sum + item.amount, 0);
  const totalNonCurrentLiabilities = nonCurrentLiabilities.reduce((sum, item) => sum + item.amount, 0);
  const totalLiabilities = totalCurrentLiabilities + totalNonCurrentLiabilities;
  const totalEquity = equity.reduce((sum, item) => sum + item.amount, 0);
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;

  return {
    currentAssets,
    nonCurrentAssets,
    currentLiabilities,
    nonCurrentLiabilities,
    equity,
    totalCurrentAssets,
    totalNonCurrentAssets,
    totalAssets,
    totalCurrentLiabilities,
    totalNonCurrentLiabilities,
    totalLiabilities,
    totalEquity,
    totalLiabilitiesAndEquity,
  };
}

export function calculateFinancialRatios(entries: TrialBalanceEntry[]): FinancialRatios {
  const balanceSheet = calculateBalanceSheet(entries);
  const incomeStatement = calculateIncomeStatement(entries);

  const currentRatio = balanceSheet.totalCurrentLiabilities !== 0 
    ? balanceSheet.totalCurrentAssets / balanceSheet.totalCurrentLiabilities 
    : 0;

  const quickRatio = balanceSheet.totalCurrentLiabilities !== 0 
    ? (balanceSheet.totalCurrentAssets * 0.8) / balanceSheet.totalCurrentLiabilities // Simplified quick assets calculation
    : 0;

  const debtToEquityRatio = balanceSheet.totalEquity !== 0 
    ? balanceSheet.totalLiabilities / balanceSheet.totalEquity 
    : 0;

  const returnOnEquity = balanceSheet.totalEquity !== 0 
    ? (incomeStatement.netIncome / balanceSheet.totalEquity) * 100 
    : 0;

  const returnOnAssets = balanceSheet.totalAssets !== 0 
    ? (incomeStatement.netIncome / balanceSheet.totalAssets) * 100 
    : 0;

  const grossMargin = incomeStatement.totalRevenue !== 0 
    ? (incomeStatement.grossProfit / incomeStatement.totalRevenue) * 100 
    : 0;

  const netMargin = incomeStatement.totalRevenue !== 0 
    ? (incomeStatement.netIncome / incomeStatement.totalRevenue) * 100 
    : 0;

  const assetTurnover = balanceSheet.totalAssets !== 0 
    ? incomeStatement.totalRevenue / balanceSheet.totalAssets 
    : 0;

  const workingCapital = balanceSheet.totalCurrentAssets - balanceSheet.totalCurrentLiabilities;

  // Enhanced ratio calculations
  const cashRatio = balanceSheet.totalCurrentLiabilities !== 0 
    ? (balanceSheet.totalCurrentAssets * 0.2) / balanceSheet.totalCurrentLiabilities // Assuming 20% of current assets are cash equivalents
    : 0;

  const operatingMargin = incomeStatement.totalRevenue !== 0 
    ? (incomeStatement.operatingIncome / incomeStatement.totalRevenue) * 100 
    : 0;

  const returnOnInvestment = (balanceSheet.totalAssets - balanceSheet.totalCurrentLiabilities) !== 0 
    ? (incomeStatement.netIncome / (balanceSheet.totalAssets - balanceSheet.totalCurrentLiabilities)) * 100 
    : 0;

  const debtRatio = balanceSheet.totalAssets !== 0 
    ? balanceSheet.totalLiabilities / balanceSheet.totalAssets 
    : 0;

  const equityRatio = balanceSheet.totalAssets !== 0 
    ? balanceSheet.totalEquity / balanceSheet.totalAssets 
    : 0;

  // Simplified turnover ratios (would need more specific account data for accuracy)
  const receivablesTurnover = balanceSheet.totalCurrentAssets !== 0 
    ? incomeStatement.totalRevenue / (balanceSheet.totalCurrentAssets * 0.3) // Assuming 30% of current assets are receivables
    : 0;

  const inventoryTurnover = balanceSheet.totalCurrentAssets !== 0 
    ? incomeStatement.totalCOGS / (balanceSheet.totalCurrentAssets * 0.25) // Assuming 25% of current assets are inventory
    : 0;

  const payablesTurnover = balanceSheet.totalCurrentLiabilities !== 0 
    ? incomeStatement.totalCOGS / (balanceSheet.totalCurrentLiabilities * 0.6) // Assuming 60% of current liabilities are payables
    : 0;

  const debtServiceCoverage = balanceSheet.totalLiabilities !== 0 
    ? incomeStatement.netIncome / (balanceSheet.totalLiabilities * 0.1) // Simplified debt service calculation
    : 0;

  return {
    // Liquidity Ratios
    currentRatio,
    quickRatio,
    cashRatio,
    workingCapital,
    
    // Profitability Ratios
    grossMargin,
    operatingMargin,
    netMargin,
    returnOnEquity,
    returnOnAssets,
    returnOnInvestment,
    
    // Efficiency/Activity Ratios
    assetTurnover,
    receivablesTurnover,
    inventoryTurnover,
    payablesTurnover,
    
    // Leverage/Solvency Ratios
    debtToEquityRatio,
    debtRatio,
    equityRatio,
    interestCoverage: 0, // Would need interest expense data
    debtServiceCoverage,
  };
}

export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(amount);
}

export function formatPercentage(value: number, decimals: number = 1): string {
  return `${value.toFixed(decimals)}%`;
}

export function formatNumber(value: number, decimals: number = 2): string {
  return value.toFixed(decimals);
}

export function calculateCashFlowStatement(entries: TrialBalanceEntry[]): CashFlowStatement {
  const incomeStatement = calculateIncomeStatement(entries);
  const balanceSheet = calculateBalanceSheet(entries);

  // Operating Activities
  const adjustments = [
    { name: "Depreciation & Amortization", amount: balanceSheet.totalAssets * 0.05 }, // Estimated
    { name: "Changes in Deferred Tax", amount: 0 },
  ];

  const workingCapitalChanges = [
    { name: "Change in Accounts Receivable", amount: -balanceSheet.totalCurrentAssets * 0.1 },
    { name: "Change in Inventory", amount: -balanceSheet.totalCurrentAssets * 0.05 },
    { name: "Change in Accounts Payable", amount: balanceSheet.totalCurrentLiabilities * 0.1 },
    { name: "Change in Accrued Liabilities", amount: balanceSheet.totalCurrentLiabilities * 0.05 },
  ];

  const totalOperatingCashFlow = incomeStatement.netIncome + 
    adjustments.reduce((sum, adj) => sum + adj.amount, 0) +
    workingCapitalChanges.reduce((sum, change) => sum + change.amount, 0);

  // Investing Activities
  const investingActivities = [
    { name: "Purchase of Property, Plant & Equipment", amount: -balanceSheet.totalNonCurrentAssets * 0.1 },
    { name: "Sale of Assets", amount: balanceSheet.totalNonCurrentAssets * 0.02 },
    { name: "Investment Activities", amount: -balanceSheet.totalAssets * 0.01 },
  ];

  const totalInvestingCashFlow = investingActivities.reduce((sum, activity) => sum + activity.amount, 0);

  // Financing Activities
  const financingActivities = [
    { name: "Proceeds from Debt", amount: balanceSheet.totalLiabilities * 0.1 },
    { name: "Repayment of Debt", amount: -balanceSheet.totalLiabilities * 0.05 },
    { name: "Dividends Paid", amount: -incomeStatement.netIncome * 0.3 },
    { name: "Equity Transactions", amount: balanceSheet.totalEquity * 0.02 },
  ];

  const totalFinancingCashFlow = financingActivities.reduce((sum, activity) => sum + activity.amount, 0);

  const netCashFlow = totalOperatingCashFlow + totalInvestingCashFlow + totalFinancingCashFlow;
  const beginningCash = balanceSheet.totalCurrentAssets * 0.2; // Estimated beginning cash
  const endingCash = beginningCash + netCashFlow;

  return {
    operatingActivities: {
      netIncome: incomeStatement.netIncome,
      adjustments,
      workingCapitalChanges,
      totalOperatingCashFlow,
    },
    investingActivities: {
      activities: investingActivities,
      totalInvestingCashFlow,
    },
    financingActivities: {
      activities: financingActivities,
      totalFinancingCashFlow,
    },
    netCashFlow,
    beginningCash,
    endingCash,
  };
}

export function calculateEquityStatement(entries: TrialBalanceEntry[]): EquityStatement {
  const balanceSheet = calculateBalanceSheet(entries);
  const incomeStatement = calculateIncomeStatement(entries);

  // Analyze equity components
  const equityComponents = balanceSheet.equity.map(component => {
    const beginningBalance = component.amount * 0.9; // Estimated beginning balance
    const netIncome = component.name.toLowerCase().includes('retained') ? incomeStatement.netIncome : 0;
    const dividends = component.name.toLowerCase().includes('retained') ? incomeStatement.netIncome * 0.3 : 0;
    const otherChanges = component.amount - beginningBalance - netIncome + dividends;

    return {
      name: component.name,
      beginningBalance,
      additions: Math.max(0, netIncome + otherChanges),
      reductions: Math.max(0, dividends - Math.min(0, otherChanges)),
      endingBalance: component.amount,
    };
  });

  const totalBeginningEquity = equityComponents.reduce((sum, comp) => sum + comp.beginningBalance, 0);
  const totalNetChanges = balanceSheet.totalEquity - totalBeginningEquity;
  const dividendsPaid = incomeStatement.netIncome * 0.3;

  return {
    equityComponents,
    totalBeginningEquity,
    totalNetChanges,
    totalEndingEquity: balanceSheet.totalEquity,
    netIncome: incomeStatement.netIncome,
    dividendsPaid,
    otherComprehensiveIncome: 0, // Would need additional data
  };
}

export function validateTrialBalance(entries: TrialBalanceEntry[]): {
  isBalanced: boolean;
  totalDebits: number;
  totalCredits: number;
  difference: number;
  errors: string[];
} {
  const errors: string[] = [];
  let totalDebits = 0;
  let totalCredits = 0;

  entries.forEach((entry, index) => {
    const debit = parseFloat(entry.debitAmount || "0");
    const credit = parseFloat(entry.creditAmount || "0");

    // Validate that each entry has either debit or credit, but not both (unless it's an adjustment entry)
    if (debit > 0 && credit > 0) {
      errors.push(`Entry ${index + 1} (${entry.accountName}): Cannot have both debit and credit amounts`);
    }

    // Validate that each entry has at least one amount
    if (debit === 0 && credit === 0) {
      errors.push(`Entry ${index + 1} (${entry.accountName}): Must have either debit or credit amount`);
    }

    // Validate account code format
    if (!entry.accountCode || entry.accountCode.trim() === "") {
      errors.push(`Entry ${index + 1} (${entry.accountName}): Account code is required`);
    }

    // Validate account name
    if (!entry.accountName || entry.accountName.trim() === "") {
      errors.push(`Entry ${index + 1}: Account name is required`);
    }

    totalDebits += debit;
    totalCredits += credit;
  });

  const difference = totalDebits - totalCredits;
  const isBalanced = Math.abs(difference) < 0.01; // Allow for small rounding differences

  if (!isBalanced) {
    errors.push(`Trial balance is out of balance by ${formatCurrency(Math.abs(difference))}`);
  }

  return {
    isBalanced,
    totalDebits,
    totalCredits,
    difference,
    errors,
  };
}

// Period Comparison Types
export interface PeriodComparison {
  currentPeriod: {
    name: string;
    startDate: string;
    endDate: string;
  };
  comparisonPeriod: {
    name: string;
    startDate: string;
    endDate: string;
  };
  incomeStatement?: {
    current: IncomeStatement;
    comparison: IncomeStatement;
    changes: {
      totalRevenue: { amount: number; percentage: number | null };
      totalCOGS: { amount: number; percentage: number | null };
      grossProfit: { amount: number; percentage: number | null };
      totalOperatingExpenses: { amount: number; percentage: number | null };
      operatingIncome: { amount: number; percentage: number | null };
      netIncome: { amount: number; percentage: number | null };
    };
  };
  balanceSheet?: {
    current: BalanceSheet;
    comparison: BalanceSheet;
    changes: {
      totalAssets: { amount: number; percentage: number | null };
      totalLiabilities: { amount: number; percentage: number | null };
      totalEquity: { amount: number; percentage: number | null };
    };
  };
  ratios?: {
    current: FinancialRatios;
    comparison: FinancialRatios;
    changes: {
      currentRatio: { amount: number; percentage: number | null };
      quickRatio: { amount: number; percentage: number | null };
      grossMargin: { amount: number; percentage: number | null };
      netMargin: { amount: number; percentage: number | null };
      returnOnEquity: { amount: number; percentage: number | null };
      returnOnAssets: { amount: number; percentage: number | null };
      debtToEquityRatio: { amount: number; percentage: number | null };
    };
  };
}

export function calculatePercentageChange(current: number, previous: number): { amount: number; percentage: number | null } {
  const amount = current - previous;
  const percentage = previous !== 0 ? (amount / Math.abs(previous)) * 100 : null;
  return { amount, percentage };
}

export function calculatePeriodComparison(
  currentPeriodData: {
    name: string;
    startDate: string;
    endDate: string;
    entries: TrialBalanceEntry[];
  },
  comparisonPeriodData: {
    name: string;
    startDate: string;
    endDate: string;
    entries: TrialBalanceEntry[];
  }
): PeriodComparison {
  // Calculate financial statements for both periods
  const currentIncome = calculateIncomeStatement(currentPeriodData.entries);
  const comparisonIncome = calculateIncomeStatement(comparisonPeriodData.entries);
  
  const currentBalance = calculateBalanceSheet(currentPeriodData.entries);
  const comparisonBalance = calculateBalanceSheet(comparisonPeriodData.entries);
  
  const currentRatios = calculateFinancialRatios(currentPeriodData.entries);
  const comparisonRatios = calculateFinancialRatios(comparisonPeriodData.entries);

  return {
    currentPeriod: {
      name: currentPeriodData.name,
      startDate: currentPeriodData.startDate,
      endDate: currentPeriodData.endDate,
    },
    comparisonPeriod: {
      name: comparisonPeriodData.name,
      startDate: comparisonPeriodData.startDate,
      endDate: comparisonPeriodData.endDate,
    },
    incomeStatement: {
      current: currentIncome,
      comparison: comparisonIncome,
      changes: {
        totalRevenue: calculatePercentageChange(currentIncome.totalRevenue, comparisonIncome.totalRevenue),
        totalCOGS: calculatePercentageChange(currentIncome.totalCOGS, comparisonIncome.totalCOGS),
        grossProfit: calculatePercentageChange(currentIncome.grossProfit, comparisonIncome.grossProfit),
        totalOperatingExpenses: calculatePercentageChange(currentIncome.totalOperatingExpenses, comparisonIncome.totalOperatingExpenses),
        operatingIncome: calculatePercentageChange(currentIncome.operatingIncome, comparisonIncome.operatingIncome),
        netIncome: calculatePercentageChange(currentIncome.netIncome, comparisonIncome.netIncome),
      },
    },
    balanceSheet: {
      current: currentBalance,
      comparison: comparisonBalance,
      changes: {
        totalAssets: calculatePercentageChange(currentBalance.totalAssets, comparisonBalance.totalAssets),
        totalLiabilities: calculatePercentageChange(currentBalance.totalLiabilities, comparisonBalance.totalLiabilities),
        totalEquity: calculatePercentageChange(currentBalance.totalEquity, comparisonBalance.totalEquity),
      },
    },
    ratios: {
      current: currentRatios,
      comparison: comparisonRatios,
      changes: {
        currentRatio: calculatePercentageChange(currentRatios.currentRatio, comparisonRatios.currentRatio),
        quickRatio: calculatePercentageChange(currentRatios.quickRatio, comparisonRatios.quickRatio),
        grossMargin: calculatePercentageChange(currentRatios.grossMargin, comparisonRatios.grossMargin),
        netMargin: calculatePercentageChange(currentRatios.netMargin, comparisonRatios.netMargin),
        returnOnEquity: calculatePercentageChange(currentRatios.returnOnEquity, comparisonRatios.returnOnEquity),
        returnOnAssets: calculatePercentageChange(currentRatios.returnOnAssets, comparisonRatios.returnOnAssets),
        debtToEquityRatio: calculatePercentageChange(currentRatios.debtToEquityRatio, comparisonRatios.debtToEquityRatio),
      },
    },
  };
}
