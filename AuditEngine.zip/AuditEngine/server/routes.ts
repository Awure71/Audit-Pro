import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertTrialBalanceEntrySchema, updateTrialBalanceEntrySchema, subscriptionPlans } from "@shared/schema";
import { calculateIncomeStatement, calculateBalanceSheet, calculateFinancialRatios, calculateCashFlowStatement, calculateEquityStatement, calculatePeriodComparison } from "../client/src/lib/financial-calculations";
import multer from "multer";
import { z } from "zod";
import Stripe from "stripe";
import { setupAuth, isAuthenticated } from "./replitAuth";

const upload = multer({ storage: multer.memoryStorage() });

// Initialize Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Authentication
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Projects - Protected routes
  app.get("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projects = await storage.getProjectsByUser(userId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      // Ensure user owns this project
      if (project.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectData = insertProjectSchema.parse({
        ...req.body,
        userId, // Link project to user
      });
      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Trial Balance Entries
  app.get("/api/projects/:projectId/trial-balance", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getTrialBalanceEntriesByProject(req.params.projectId);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trial balance entries" });
    }
  });

  app.post("/api/projects/:projectId/trial-balance", isAuthenticated, async (req, res) => {
    try {
      const entryData = insertTrialBalanceEntrySchema.parse({
        ...req.body,
        projectId: req.params.projectId,
      });
      const entry = await storage.createTrialBalanceEntry(entryData);
      res.json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create trial balance entry" });
    }
  });

  app.put("/api/trial-balance/:id", isAuthenticated, async (req, res) => {
    try {
      const updates = updateTrialBalanceEntrySchema.parse(req.body);
      const entry = await storage.updateTrialBalanceEntry(req.params.id, updates);
      if (!entry) {
        return res.status(404).json({ message: "Trial balance entry not found" });
      }
      res.json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update trial balance entry" });
    }
  });

  app.delete("/api/trial-balance/:id", isAuthenticated, async (req, res) => {
    try {
      const deleted = await storage.deleteTrialBalanceEntry(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Trial balance entry not found" });
      }
      res.json({ message: "Trial balance entry deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete trial balance entry" });
    }
  });

  app.delete("/api/projects/:projectId/trial-balance", isAuthenticated, async (req, res) => {
    try {
      await storage.deleteAllTrialBalanceEntries(req.params.projectId);
      res.json({ message: "All trial balance entries deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete trial balance entries" });
    }
  });

  // CSV Upload
  app.post("/api/projects/:projectId/trial-balance/upload", isAuthenticated, upload.single("csvFile"), async (req: Request & { file?: Express.Multer.File }, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const csvContent = req.file.buffer.toString();
      const lines = csvContent.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 2) {
        return res.status(400).json({ message: "CSV file must have at least a header row and one data row" });
      }

      const headers = lines[0].split(',').map((h: string) => h.trim().toLowerCase());
      const requiredHeaders = ['account name', 'account code', 'debit', 'credit'];
      
      const missingHeaders = requiredHeaders.filter(header => 
        !headers.some((h: string) => h.includes(header.replace(' ', '')))
      );
      
      if (missingHeaders.length > 0) {
        return res.status(400).json({ 
          message: `Missing required columns: ${missingHeaders.join(', ')}. Expected columns: Account Name, Account Code, Debit, Credit` 
        });
      }

      const entries: any[] = [];
      const errors: string[] = [];

      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map((v: string) => v.trim().replace(/"/g, ''));
        
        if (values.length < 4) {
          errors.push(`Row ${i + 1}: Insufficient columns`);
          continue;
        }

        const accountName = values[0];
        const accountCode = values[1];
        const debit = parseFloat(values[2]) || 0;
        const credit = parseFloat(values[3]) || 0;

        if (!accountName || !accountCode) {
          errors.push(`Row ${i + 1}: Account name and code are required`);
          continue;
        }

        // Auto-classify accounts based on account code patterns
        let category = "Current Assets"; // default
        const code = parseInt(accountCode);
        if (code >= 1000 && code < 2000) category = "Current Assets";
        else if (code >= 2000 && code < 3000) category = "Current Liabilities";
        else if (code >= 3000 && code < 4000) category = "Equity";
        else if (code >= 4000 && code < 5000) category = "Revenue";
        else if (code >= 5000 && code < 6000) category = "Cost of Goods Sold";
        else if (code >= 6000 && code < 8000) category = "Operating Expenses";
        else if (code >= 8000 && code < 9000) category = "Other Income";
        else if (code >= 9000) category = "Other Expenses";

        entries.push({
          projectId: req.params.projectId,
          accountCode,
          accountName,
          category,
          debitAmount: debit.toString(),
          creditAmount: credit.toString(),
        });
      }

      if (errors.length > 0 && entries.length === 0) {
        return res.status(400).json({ message: "No valid entries found", errors });
      }

      const createdEntries = await storage.bulkCreateTrialBalanceEntries(entries);
      
      res.json({ 
        message: `Successfully imported ${createdEntries.length} entries`,
        entries: createdEntries,
        warnings: errors.length > 0 ? errors : undefined
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to process CSV file" });
    }
  });

  // Financial Statements Generation
  app.get("/api/projects/:projectId/income-statement", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getTrialBalanceEntriesByProject(req.params.projectId);
      const incomeStatement = calculateIncomeStatement(entries);
      res.json(incomeStatement);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate income statement" });
    }
  });

  app.get("/api/projects/:projectId/balance-sheet", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getTrialBalanceEntriesByProject(req.params.projectId);
      const balanceSheet = calculateBalanceSheet(entries);
      res.json(balanceSheet);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate balance sheet" });
    }
  });

  app.get("/api/projects/:projectId/financial-ratios", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getTrialBalanceEntriesByProject(req.params.projectId);
      const ratios = calculateFinancialRatios(entries);
      res.json(ratios);
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate financial ratios" });
    }
  });

  // New Comprehensive Financial Statements
  app.get("/api/projects/:projectId/cash-flow-statement", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getTrialBalanceEntriesByProject(req.params.projectId);
      const cashFlowStatement = calculateCashFlowStatement(entries);
      res.json(cashFlowStatement);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate cash flow statement" });
    }
  });

  app.get("/api/projects/:projectId/equity-statement", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getTrialBalanceEntriesByProject(req.params.projectId);
      const equityStatement = calculateEquityStatement(entries);
      res.json(equityStatement);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate equity statement" });
    }
  });

  // Period comparison endpoint with validation
  const periodComparisonSchema = z.object({
    currentPeriodEntries: z.array(insertTrialBalanceEntrySchema),
    comparisonPeriodEntries: z.array(insertTrialBalanceEntrySchema),
    currentPeriodData: z.object({
      name: z.string().min(1, "Period name is required"),
      startDate: z.string().min(1, "Start date is required"),
      endDate: z.string().min(1, "End date is required"),
    }),
    comparisonPeriodData: z.object({
      name: z.string().min(1, "Period name is required"),
      startDate: z.string().min(1, "Start date is required"),
      endDate: z.string().min(1, "End date is required"),
    }),
  });

  app.post("/api/projects/:projectId/period-comparison", isAuthenticated, async (req, res) => {
    try {
      const validatedData = periodComparisonSchema.parse(req.body);
      const projectId = req.params.projectId;
      
      if (!projectId || projectId === "") {
        return res.status(400).json({ message: "Project ID is required" });
      }

      // Validate that all entries belong to the specified project for data integrity
      const allEntries = [...validatedData.currentPeriodEntries, ...validatedData.comparisonPeriodEntries];
      const invalidEntries = allEntries.filter(entry => entry.projectId && entry.projectId !== projectId);
      
      if (invalidEntries.length > 0) {
        return res.status(400).json({ 
          message: "Data integrity error: Some entries do not belong to the specified project",
          invalidEntries: invalidEntries.length
        });
      }

      // Check if the two periods contain identical entry sets (would result in zero changes)
      // Use stable fields that exist in the schema for comparison
      const normalizeEntry = (entry: any) => ({
        accountName: entry.accountName,
        category: entry.category,
        debitAmount: entry.debitAmount || 0,
        creditAmount: entry.creditAmount || 0
      });
      
      const currentNormalized = validatedData.currentPeriodEntries.map(normalizeEntry).sort((a, b) => 
        a.accountName.localeCompare(b.accountName) || a.category.localeCompare(b.category)
      );
      const comparisonNormalized = validatedData.comparisonPeriodEntries.map(normalizeEntry).sort((a, b) => 
        a.accountName.localeCompare(b.accountName) || a.category.localeCompare(b.category)
      );
      
      const isIdenticalDataset = JSON.stringify(currentNormalized) === JSON.stringify(comparisonNormalized);

      const periodComparison = calculatePeriodComparison(
        {
          name: validatedData.currentPeriodData.name,
          startDate: validatedData.currentPeriodData.startDate,
          endDate: validatedData.currentPeriodData.endDate,
          entries: validatedData.currentPeriodEntries as any,
        },
        {
          name: validatedData.comparisonPeriodData.name,
          startDate: validatedData.comparisonPeriodData.startDate,
          endDate: validatedData.comparisonPeriodData.endDate,
          entries: validatedData.comparisonPeriodEntries as any,
        }
      );
      
      // Add warning if datasets are identical
      const response = {
        ...periodComparison,
        ...(isIdenticalDataset && {
          warning: "Both periods contain identical data. Date-based filtering is not available in the current version."
        })
      };
      
      res.json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid period comparison data", 
          errors: error.errors 
        });
      }
      console.error("Error calculating period comparison:", error);
      res.status(500).json({ message: "Failed to calculate period comparison" });
    }
  });

  // Stripe payment routes for subscription plans
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      const { amount, planId } = req.body;
      
      // Validate plan
      const plan = subscriptionPlans.find(p => p.id === planId);
      if (!plan) {
        return res.status(400).json({ message: "Invalid subscription plan" });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: plan.price * 100, // Convert to cents
        currency: "usd",
        metadata: {
          planId: plan.id,
          planName: plan.name,
        },
      });

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        planId: plan.id,
        amount: plan.price
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Get subscription plans
  app.get("/api/subscription-plans", async (req, res) => {
    try {
      res.json(subscriptionPlans);
    } catch (error) {
      console.error("Error fetching subscription plans:", error);
      res.status(500).json({ message: "Failed to fetch subscription plans" });
    }
  });

  // Process successful payment and update project subscription
  app.post("/api/process-payment", isAuthenticated, async (req, res) => {
    try {
      const { paymentIntentId, projectId } = req.body;
      
      // Verify payment with Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status === 'succeeded') {
        const planId = paymentIntent.metadata.planId;
        const plan = subscriptionPlans.find(p => p.id === planId);
        
        if (plan) {
          // Update project with subscription details
          const subscriptionEndDate = new Date();
          subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1); // 1 month subscription
          
          await storage.updateProject(projectId, {
            subscriptionPlan: plan.id as any,
            subscriptionStatus: "active",
            subscriptionStartDate: new Date(),
            subscriptionEndDate: subscriptionEndDate,
          });

          res.json({ 
            success: true, 
            message: `Successfully subscribed to ${plan.name} plan`,
            plan: plan
          });
        } else {
          res.status(400).json({ message: "Invalid plan in payment metadata" });
        }
      } else {
        res.status(400).json({ message: "Payment was not successful" });
      }
    } catch (error: any) {
      console.error("Error processing payment:", error);
      res.status(500).json({ message: "Error processing payment: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
