import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, boolean, integer, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(), // Link projects to users
  name: text("name").notNull(),
  currency: text("currency").notNull().default("USD"),
  subscriptionPlan: text("subscription_plan").default("basic"),
  subscriptionStatus: text("subscription_status").default("trial"),
  subscriptionStartDate: timestamp("subscription_start_date"),
  subscriptionEndDate: timestamp("subscription_end_date"),
  reportsGenerated: integer("reports_generated").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trialBalanceEntries = pgTable("trial_balance_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  accountCode: text("account_code").notNull(),
  accountName: text("account_name").notNull(),
  category: text("category").notNull(), // Current Assets, Non-Current Assets, Current Liabilities, Non-Current Liabilities, Equity, Revenue, Expenses
  debitAmount: decimal("debit_amount", { precision: 15, scale: 2 }).default("0"),
  creditAmount: decimal("credit_amount", { precision: 15, scale: 2 }).default("0"),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});

export const insertTrialBalanceEntrySchema = createInsertSchema(trialBalanceEntries).omit({
  id: true,
});

export const updateTrialBalanceEntrySchema = createInsertSchema(trialBalanceEntries).omit({
  id: true,
  projectId: true,
}).partial();

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertTrialBalanceEntry = z.infer<typeof insertTrialBalanceEntrySchema>;
export type TrialBalanceEntry = typeof trialBalanceEntries.$inferSelect;
export type UpdateTrialBalanceEntry = z.infer<typeof updateTrialBalanceEntrySchema>;

// Financial statement types
export interface IncomeStatement {
  revenue: { name: string; amount: number }[];
  costOfGoodsSold: { name: string; amount: number }[];
  operatingExpenses: { name: string; amount: number }[];
  otherIncome: { name: string; amount: number }[];
  otherExpenses: { name: string; amount: number }[];
  totalRevenue: number;
  totalCOGS: number;
  grossProfit: number;
  totalOperatingExpenses: number;
  operatingIncome: number;
  totalOtherIncome: number;
  totalOtherExpenses: number;
  netIncome: number;
}

export interface BalanceSheet {
  currentAssets: { name: string; amount: number }[];
  nonCurrentAssets: { name: string; amount: number }[];
  currentLiabilities: { name: string; amount: number }[];
  nonCurrentLiabilities: { name: string; amount: number }[];
  equity: { name: string; amount: number }[];
  totalCurrentAssets: number;
  totalNonCurrentAssets: number;
  totalAssets: number;
  totalCurrentLiabilities: number;
  totalNonCurrentLiabilities: number;
  totalLiabilities: number;
  totalEquity: number;
  totalLiabilitiesAndEquity: number;
}

export interface FinancialRatios {
  // Liquidity Ratios
  currentRatio: number;
  quickRatio: number;
  cashRatio: number;
  workingCapital: number;
  
  // Profitability Ratios
  grossMargin: number;
  operatingMargin: number;
  netMargin: number;
  returnOnEquity: number;
  returnOnAssets: number;
  returnOnInvestment: number;
  
  // Efficiency/Activity Ratios
  assetTurnover: number;
  receivablesTurnover: number;
  inventoryTurnover: number;
  payablesTurnover: number;
  
  // Leverage/Solvency Ratios
  debtToEquityRatio: number;
  debtRatio: number;
  equityRatio: number;
  interestCoverage: number;
  debtServiceCoverage: number;
  
  // Market/Valuation Ratios (when applicable)
  priceToEarnings?: number;
  priceToBook?: number;
  dividendYield?: number;
}

export interface CashFlowStatement {
  operatingActivities: {
    netIncome: number;
    adjustments: { name: string; amount: number }[];
    workingCapitalChanges: { name: string; amount: number }[];
    totalOperatingCashFlow: number;
  };
  investingActivities: {
    activities: { name: string; amount: number }[];
    totalInvestingCashFlow: number;
  };
  financingActivities: {
    activities: { name: string; amount: number }[];
    totalFinancingCashFlow: number;
  };
  netCashFlow: number;
  beginningCash: number;
  endingCash: number;
}

export interface EquityStatement {
  equityComponents: {
    name: string;
    beginningBalance: number;
    additions: number;
    reductions: number;
    endingBalance: number;
  }[];
  totalBeginningEquity: number;
  totalNetChanges: number;
  totalEndingEquity: number;
  netIncome: number;
  dividendsPaid: number;
  otherComprehensiveIncome: number;
}

export const accountCategories = [
  "Current Assets",
  "Non-Current Assets", 
  "Current Liabilities",
  "Non-Current Liabilities",
  "Equity",
  "Revenue",
  "Cost of Goods Sold",
  "Operating Expenses",
  "Other Income",
  "Other Expenses"
] as const;

export type AccountCategory = typeof accountCategories[number];

export const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
] as const;

// Reporting periods
export const reportingPeriods = [
  "monthly",
  "quarterly", 
  "semi-annual", // 6 months
  "nine-month",
  "annual"
] as const;

export type ReportingPeriod = typeof reportingPeriods[number];

// Subscription plans
export const subscriptionPlans = [
  { 
    id: "basic", 
    name: "Basic", 
    price: 29, 
    features: ["Monthly reports", "Basic financial statements", "Email support"],
    maxReports: 5
  },
  { 
    id: "professional", 
    name: "Professional", 
    price: 79, 
    features: ["All periods", "Performance analysis", "Management letters", "Priority support"],
    maxReports: 25
  },
  { 
    id: "enterprise", 
    name: "Enterprise", 
    price: 199, 
    features: ["Unlimited reports", "Custom analysis", "Dedicated support", "API access"],
    maxReports: -1 // unlimited
  }
] as const;

export type SubscriptionPlan = typeof subscriptionPlans[number];

// Performance Analysis Types
export interface PerformanceMetrics {
  profitabilityTrends: {
    period: string;
    grossMargin: number;
    netMargin: number;
    revenue: number;
    netIncome: number;
  }[];
  liquidityTrends: {
    period: string;
    currentRatio: number;
    quickRatio: number;
    workingCapital: number;
  }[];
  leverageTrends: {
    period: string;
    debtToEquity: number;
    interestCoverage: number;
    totalDebt: number;
  }[];
  activityTrends: {
    period: string;
    assetTurnover: number;
    receivablesTurnover: number;
    inventoryTurnover: number;
  }[];
}

export interface PerformanceAnalysis {
  reportingPeriod: ReportingPeriod;
  startDate: string;
  endDate: string;
  metrics: PerformanceMetrics;
  insights: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
  recommendations: {
    priority: "high" | "medium" | "low";
    category: "profitability" | "liquidity" | "efficiency" | "leverage";
    description: string;
    expectedImpact: string;
    timeline: string;
  }[];
  industryComparison?: {
    sector: string;
    benchmarks: {
      currentRatio: number;
      debtToEquity: number;
      grossMargin: number;
      netMargin: number;
    };
  };
}

export interface ManagementLetter {
  id: string;
  projectId: string;
  reportingPeriod: ReportingPeriod;
  generatedDate: string;
  executiveSummary: string;
  keyFindings: {
    type: "strength" | "concern" | "opportunity";
    title: string;
    description: string;
    impact: "high" | "medium" | "low";
    recommendation: string;
  }[];
  financialHighlights: {
    revenue: { current: number; previous?: number; change?: number };
    netIncome: { current: number; previous?: number; change?: number };
    totalAssets: { current: number; previous?: number; change?: number };
    equity: { current: number; previous?: number; change?: number };
  };
  riskAssessment: {
    area: string;
    riskLevel: "low" | "medium" | "high";
    description: string;
    mitigation: string;
  }[];
  complianceNotes: string[];
  managementResponse?: string;
  actionPlan: {
    item: string;
    responsible: string;
    deadline: string;
    status: "pending" | "in-progress" | "completed";
  }[];
}

// New tables for enhanced functionality
export const reportingPeriodData = pgTable("reporting_period_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  period: text("period").$type<ReportingPeriod>().notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  isCompleted: text("is_completed").default("false"), // Store as text for now
  performanceAnalysis: text("performance_analysis"), // JSON stored as text
  managementLetter: text("management_letter"), // JSON stored as text
  createdAt: timestamp("created_at").defaultNow(),
});

// Payment and subscription tables
export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  plan: text("plan").$type<SubscriptionPlan["id"]>().notNull(),
  status: text("status").notNull(), // active, inactive, cancelled, past_due
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subscriptionId: varchar("subscription_id").notNull(),
  stripePaymentIntentId: text("stripe_payment_intent_id"),
  amount: integer("amount").notNull(), // in cents
  currency: text("currency").notNull().default("USD"),
  status: text("status").notNull(), // succeeded, failed, pending
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Enhanced schemas and types for new functionality 
export const insertReportingPeriodDataSchema = createInsertSchema(reportingPeriodData, {
  period: z.enum(reportingPeriods),
}).omit({
  id: true,
  createdAt: true,
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions, {
  plan: z.enum(["basic", "professional", "enterprise"]),
}).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export type InsertReportingPeriodData = z.infer<typeof insertReportingPeriodDataSchema>;
export type ReportingPeriodData = typeof reportingPeriodData.$inferSelect;

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
