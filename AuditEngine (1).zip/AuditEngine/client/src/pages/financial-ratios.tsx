import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calculator, Download, ArrowLeft, TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { FinancialRatios } from "@shared/schema";

export default function FinancialRatiosPage() {
  const projectId = "default";

  const { data: ratios, isLoading } = useQuery<FinancialRatios>({
    queryKey: ["/api/projects", projectId, "financial-ratios"],
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const formatRatio = (value: number) => {
    return value.toFixed(2);
  };

  const getRatioStatus = (value: number, type: string) => {
    switch (type) {
      case 'current':
        if (value >= 2) return { color: 'text-green-600', bg: 'bg-green-100', icon: TrendingUp, status: 'Excellent' };
        if (value >= 1) return { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: AlertCircle, status: 'Good' };
        return { color: 'text-red-600', bg: 'bg-red-100', icon: TrendingDown, status: 'Poor' };
      case 'quick':
        if (value >= 1) return { color: 'text-green-600', bg: 'bg-green-100', icon: TrendingUp, status: 'Good' };
        return { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: AlertCircle, status: 'Caution' };
      case 'debt':
        if (value <= 0.5) return { color: 'text-green-600', bg: 'bg-green-100', icon: TrendingUp, status: 'Low Risk' };
        if (value <= 1) return { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: AlertCircle, status: 'Moderate' };
        return { color: 'text-red-600', bg: 'bg-red-100', icon: TrendingDown, status: 'High Risk' };
      case 'roe':
        if (value >= 15) return { color: 'text-green-600', bg: 'bg-green-100', icon: TrendingUp, status: 'Excellent' };
        if (value >= 8) return { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: AlertCircle, status: 'Good' };
        return { color: 'text-red-600', bg: 'bg-red-100', icon: TrendingDown, status: 'Poor' };
      case 'roa':
        if (value >= 10) return { color: 'text-green-600', bg: 'bg-green-100', icon: TrendingUp, status: 'Excellent' };
        if (value >= 5) return { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: AlertCircle, status: 'Good' };
        return { color: 'text-red-600', bg: 'bg-red-100', icon: TrendingDown, status: 'Poor' };
      case 'margin':
        if (value >= 20) return { color: 'text-green-600', bg: 'bg-green-100', icon: TrendingUp, status: 'Excellent' };
        if (value >= 10) return { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: AlertCircle, status: 'Good' };
        return { color: 'text-red-600', bg: 'bg-red-100', icon: TrendingDown, status: 'Poor' };
      default:
        return { color: 'text-gray-600', bg: 'bg-gray-100', icon: AlertCircle, status: 'N/A' };
    }
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading financial ratios...</div>
      </div>
    );
  }

  if (!ratios) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No financial ratios available. Please add trial balance entries first.</p>
            <Link href="/">
              <Button className="mt-4">Go to Trial Balance</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const ratioCategories = [
    {
      title: "Liquidity Ratios",
      description: "Measure the ability to meet short-term obligations",
      ratios: [
        {
          name: "Current Ratio",
          value: ratios.currentRatio,
          format: formatRatio,
          type: "current",
          explanation: "Current Assets ÷ Current Liabilities"
        },
        {
          name: "Quick Ratio",
          value: ratios.quickRatio,
          format: formatRatio,
          type: "quick",
          explanation: "Quick Assets ÷ Current Liabilities"
        },
        {
          name: "Working Capital",
          value: ratios.workingCapital,
          format: formatCurrency,
          type: "currency",
          explanation: "Current Assets - Current Liabilities"
        }
      ]
    },
    {
      title: "Profitability Ratios",
      description: "Measure the company's ability to generate profits",
      ratios: [
        {
          name: "Gross Margin",
          value: ratios.grossMargin,
          format: formatPercentage,
          type: "margin",
          explanation: "Gross Profit ÷ Revenue × 100"
        },
        {
          name: "Net Margin",
          value: ratios.netMargin,
          format: formatPercentage,
          type: "margin",
          explanation: "Net Income ÷ Revenue × 100"
        },
        {
          name: "Return on Equity (ROE)",
          value: ratios.returnOnEquity,
          format: formatPercentage,
          type: "roe",
          explanation: "Net Income ÷ Total Equity × 100"
        },
        {
          name: "Return on Assets (ROA)",
          value: ratios.returnOnAssets,
          format: formatPercentage,
          type: "roa",
          explanation: "Net Income ÷ Total Assets × 100"
        }
      ]
    },
    {
      title: "Leverage Ratios",
      description: "Measure the company's financial leverage and solvency",
      ratios: [
        {
          name: "Debt-to-Equity Ratio",
          value: ratios.debtToEquityRatio,
          format: formatRatio,
          type: "debt",
          explanation: "Total Liabilities ÷ Total Equity"
        }
      ]
    },
    {
      title: "Activity Ratios",
      description: "Measure how efficiently the company uses its assets",
      ratios: [
        {
          name: "Asset Turnover",
          value: ratios.assetTurnover,
          format: formatRatio,
          type: "activity",
          explanation: "Revenue ÷ Total Assets"
        }
      ]
    }
  ];

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Financial Ratios
              </h2>
              <p className="text-sm text-muted-foreground">
                Comprehensive financial ratio analysis
              </p>
            </div>
          </div>
          <Button data-testid="button-export-pdf">
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 space-y-8">
        {ratioCategories.map((category, categoryIndex) => (
          <Card key={categoryIndex} data-testid={`ratio-category-${categoryIndex}`}>
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <Calculator className="text-primary mr-3 h-6 w-6" />
                {category.title}
              </CardTitle>
              <p className="text-sm text-muted-foreground">{category.description}</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.ratios.map((ratio, ratioIndex) => {
                  const status = getRatioStatus(ratio.value, ratio.type);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div
                      key={ratioIndex}
                      className="p-4 border border-border rounded-lg hover:shadow-md transition-shadow"
                      data-testid={`ratio-${ratio.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-foreground">{ratio.name}</h4>
                        <StatusIcon className={`h-5 w-5 ${status.color}`} />
                      </div>
                      
                      <div className="mb-3">
                        <div className={`inline-flex items-center px-3 py-2 rounded-full text-sm font-medium ${status.bg} ${status.color}`}>
                          {ratio.format(ratio.value)}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className={`text-xs font-medium ${status.color}`}>
                          {status.status}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {ratio.explanation}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Summary Insights */}
        <Card data-testid="ratio-insights">
          <CardHeader>
            <CardTitle className="text-xl">Key Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-foreground">Strengths</h4>
                <div className="space-y-2">
                  {ratios.currentRatio >= 2 && (
                    <div className="flex items-center text-sm text-green-600">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Strong liquidity position
                    </div>
                  )}
                  {ratios.grossMargin >= 20 && (
                    <div className="flex items-center text-sm text-green-600">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Healthy gross profit margins
                    </div>
                  )}
                  {ratios.debtToEquityRatio <= 0.5 && (
                    <div className="flex items-center text-sm text-green-600">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Conservative debt levels
                    </div>
                  )}
                  {ratios.returnOnEquity >= 15 && (
                    <div className="flex items-center text-sm text-green-600">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Excellent return on equity
                    </div>
                  )}
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-semibold text-foreground">Areas for Attention</h4>
                <div className="space-y-2">
                  {ratios.currentRatio < 1 && (
                    <div className="flex items-center text-sm text-red-600">
                      <TrendingDown className="h-4 w-4 mr-2" />
                      Low current ratio - liquidity concerns
                    </div>
                  )}
                  {ratios.netMargin < 5 && (
                    <div className="flex items-center text-sm text-red-600">
                      <TrendingDown className="h-4 w-4 mr-2" />
                      Low net profit margin
                    </div>
                  )}
                  {ratios.debtToEquityRatio > 1 && (
                    <div className="flex items-center text-sm text-red-600">
                      <TrendingDown className="h-4 w-4 mr-2" />
                      High debt-to-equity ratio
                    </div>
                  )}
                  {ratios.returnOnEquity < 8 && (
                    <div className="flex items-center text-sm text-red-600">
                      <TrendingDown className="h-4 w-4 mr-2" />
                      Below average return on equity
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
