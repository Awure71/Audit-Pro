import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { currencies, type Project, type TrialBalanceEntry } from "@shared/schema";
import FileUpload from "@/components/file-upload";
import ManualEntryForm from "@/components/manual-entry-form";
import TrialBalanceTable from "@/components/trial-balance-table";
import FinancialPreviewCards from "@/components/financial-preview-cards";
import { Download, Save, RotateCcw, Settings, List, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const [selectedCurrency, setSelectedCurrency] = useState("USD");
  const [currentProject] = useState("default"); // Using default project for now
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: project } = useQuery<Project>({
    queryKey: ["/api/projects", currentProject],
  });

  const { data: trialBalanceEntries = [], isLoading: entriesLoading } = useQuery<TrialBalanceEntry[]>({
    queryKey: ["/api/projects", currentProject, "trial-balance"],
  });

  const clearAllMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/projects/${currentProject}/trial-balance`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", currentProject, "trial-balance"] });
      toast({ title: "Success", description: "All trial balance entries cleared" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to clear entries", variant: "destructive" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: (currency: string) => 
      apiRequest("PUT", `/api/projects/${currentProject}`, { currency }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", currentProject] });
      toast({ title: "Success", description: "Currency updated" });
    },
  });

  // Calculate totals and validation
  const totalDebits = trialBalanceEntries.reduce((sum, entry) => 
    sum + parseFloat(entry.debitAmount || "0"), 0
  );
  
  const totalCredits = trialBalanceEntries.reduce((sum, entry) => 
    sum + parseFloat(entry.creditAmount || "0"), 0
  );
  
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;
  const balanceDifference = totalDebits - totalCredits;

  const selectedCurrencyInfo = currencies.find(c => c.code === selectedCurrency);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: selectedCurrency,
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const handleCurrencyChange = (currency: string) => {
    setSelectedCurrency(currency);
    updateProjectMutation.mutate(currency);
  };

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
              Trial Balance Input
            </h2>
            <p className="text-sm text-muted-foreground">
              Upload or manually enter your trial balance data
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-foreground">Currency:</label>
              <Select value={selectedCurrency} onValueChange={handleCurrencyChange} data-testid="currency-select">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.name} ({currency.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button data-testid="button-export-all">
              <Download className="mr-2 h-4 w-4" />
              Export All Reports
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 space-y-6">
        {/* Data Input Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FileUpload projectId={currentProject} />
          <ManualEntryForm projectId={currentProject} />
        </div>

        {/* Trial Balance Table */}
        <TrialBalanceTable 
          entries={trialBalanceEntries}
          isLoading={entriesLoading}
          projectId={currentProject}
          formatCurrency={formatCurrency}
          onClearAll={() => clearAllMutation.mutate()}
          isClearingAll={clearAllMutation.isPending}
          totalDebits={totalDebits}
          totalCredits={totalCredits}
          isBalanced={isBalanced}
          balanceDifference={balanceDifference}
        />

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card data-testid="stat-total-accounts">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <List className="text-primary h-4 w-4" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-muted-foreground">Total Accounts</p>
                  <p className="text-xl font-semibold text-foreground">{trialBalanceEntries.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="stat-total-debits">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <TrendingUp className="text-green-600 h-4 w-4" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-muted-foreground">Total Debits</p>
                  <p className="text-xl font-semibold text-foreground">{formatCurrency(totalDebits)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="stat-total-credits">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-red-100 rounded-lg">
                  <TrendingDown className="text-red-600 h-4 w-4" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-muted-foreground">Total Credits</p>
                  <p className="text-xl font-semibold text-foreground">{formatCurrency(totalCredits)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="stat-balance-status">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className={`p-2 rounded-lg ${isBalanced ? 'bg-green-100' : 'bg-destructive/10'}`}>
                  <AlertTriangle className={`h-4 w-4 ${isBalanced ? 'text-green-600' : 'text-destructive'}`} />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-muted-foreground">Balance Status</p>
                  <p className={`text-sm font-semibold ${isBalanced ? 'text-green-600' : 'text-destructive'}`}>
                    {isBalanced ? "Balanced" : "Out of Balance"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Financial Statements Preview */}
        <FinancialPreviewCards 
          projectId={currentProject} 
          formatCurrency={formatCurrency} 
        />

        {/* Action Buttons */}
        <div className="flex justify-center space-x-4 pt-6">
          <Button size="lg" data-testid="button-generate-statements">
            <Settings className="mr-2 h-4 w-4" />
            Generate Financial Statements
          </Button>
          <Button variant="secondary" size="lg" data-testid="button-save-project">
            <Save className="mr-2 h-4 w-4" />
            Save Project
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            onClick={() => clearAllMutation.mutate()}
            disabled={clearAllMutation.isPending}
            data-testid="button-reset-data"
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset All Data
          </Button>
        </div>
      </main>
    </div>
  );
}
