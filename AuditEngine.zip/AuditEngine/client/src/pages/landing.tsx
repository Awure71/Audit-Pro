import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileSpreadsheet, BarChart3, TrendingUp, Shield } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-4 text-gray-900 dark:text-white" data-testid="text-hero-title">
            FinanceAudit Pro
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto" data-testid="text-hero-subtitle">
            Professional financial statement generation and analysis for accountants, auditors, and financial professionals
          </p>
          <Button 
            onClick={handleLogin} 
            size="lg" 
            className="text-lg px-8 py-6"
            data-testid="button-login"
          >
            Log In to Get Started
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card>
            <CardHeader>
              <FileSpreadsheet className="w-12 h-12 mb-2 text-blue-600 dark:text-blue-400" />
              <CardTitle>Trial Balance Input</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Enter data manually or upload CSV files for quick and efficient data entry
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <BarChart3 className="w-12 h-12 mb-2 text-green-600 dark:text-green-400" />
              <CardTitle>Financial Statements</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Auto-generate income statements, balance sheets, cash flow, and equity statements
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <TrendingUp className="w-12 h-12 mb-2 text-purple-600 dark:text-purple-400" />
              <CardTitle>Financial Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Comprehensive ratio analysis and period comparison for better insights
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Shield className="w-12 h-12 mb-2 text-red-600 dark:text-red-400" />
              <CardTitle>Professional Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Export professional PDF reports ready for client presentations
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Subscription Plans Preview */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">
            Choose Your Plan
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Flexible pricing for professionals of all sizes
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-2xl">Basic</CardTitle>
                <div className="text-4xl font-bold mt-2">$29<span className="text-lg font-normal text-gray-600 dark:text-gray-400">/mo</span></div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-left">
                  <li>✓ Monthly reports</li>
                  <li>✓ Basic financial statements</li>
                  <li>✓ Email support</li>
                  <li>✓ Up to 5 reports/month</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 border-blue-600 dark:border-blue-400 shadow-lg">
              <CardHeader>
                <div className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm w-fit mb-2">Popular</div>
                <CardTitle className="text-2xl">Professional</CardTitle>
                <div className="text-4xl font-bold mt-2">$79<span className="text-lg font-normal text-gray-600 dark:text-gray-400">/mo</span></div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-left">
                  <li>✓ All periods</li>
                  <li>✓ Performance analysis</li>
                  <li>✓ Management letters</li>
                  <li>✓ Priority support</li>
                  <li>✓ Up to 25 reports/month</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-2xl">Enterprise</CardTitle>
                <div className="text-4xl font-bold mt-2">$199<span className="text-lg font-normal text-gray-600 dark:text-gray-400">/mo</span></div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-left">
                  <li>✓ Unlimited reports</li>
                  <li>✓ Custom analysis</li>
                  <li>✓ Dedicated support</li>
                  <li>✓ API access</li>
                  <li>✓ White-label options</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <Button 
            onClick={handleLogin} 
            size="lg"
            className="text-lg px-8 py-6"
            data-testid="button-login-bottom"
          >
            Start Your Free Trial
          </Button>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-4">
            No credit card required
          </p>
        </div>
      </div>
    </div>
  );
}
