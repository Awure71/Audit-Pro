import { type User, type UpsertUser, type Project, type InsertProject, type TrialBalanceEntry, type InsertTrialBalanceEntry, type UpdateTrialBalanceEntry, users, projects, trialBalanceEntries } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Projects
  getProject(id: string): Promise<Project | undefined>;
  getProjectsByUser(userId: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  getAllProjects(): Promise<Project[]>;

  // Trial Balance Entries
  getTrialBalanceEntry(id: string): Promise<TrialBalanceEntry | undefined>;
  getTrialBalanceEntriesByProject(projectId: string): Promise<TrialBalanceEntry[]>;
  createTrialBalanceEntry(entry: InsertTrialBalanceEntry): Promise<TrialBalanceEntry>;
  updateTrialBalanceEntry(id: string, updates: UpdateTrialBalanceEntry): Promise<TrialBalanceEntry | undefined>;
  deleteTrialBalanceEntry(id: string): Promise<boolean>;
  deleteAllTrialBalanceEntries(projectId: string): Promise<boolean>;
  bulkCreateTrialBalanceEntries(entries: InsertTrialBalanceEntry[]): Promise<TrialBalanceEntry[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations - required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Projects
  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getProjectsByUser(userId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.userId, userId));
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject).returning();
    return project;
  }

  async updateProject(id: string, updates: Partial<InsertProject & { subscriptionPlan?: string; subscriptionStatus?: string; subscriptionStartDate?: Date | null; subscriptionEndDate?: Date | null; reportsGenerated?: number }>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set(updates)
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: string): Promise<boolean> {
    await this.deleteAllTrialBalanceEntries(id);
    const result = await db.delete(projects).where(eq(projects.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async getAllProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  // Trial Balance Entries
  async getTrialBalanceEntry(id: string): Promise<TrialBalanceEntry | undefined> {
    const [entry] = await db.select().from(trialBalanceEntries).where(eq(trialBalanceEntries.id, id));
    return entry;
  }

  async getTrialBalanceEntriesByProject(projectId: string): Promise<TrialBalanceEntry[]> {
    return await db.select().from(trialBalanceEntries).where(eq(trialBalanceEntries.projectId, projectId));
  }

  async createTrialBalanceEntry(insertEntry: InsertTrialBalanceEntry): Promise<TrialBalanceEntry> {
    const [entry] = await db.insert(trialBalanceEntries).values(insertEntry).returning();
    return entry;
  }

  async updateTrialBalanceEntry(id: string, updates: UpdateTrialBalanceEntry): Promise<TrialBalanceEntry | undefined> {
    const [entry] = await db
      .update(trialBalanceEntries)
      .set(updates)
      .where(eq(trialBalanceEntries.id, id))
      .returning();
    return entry;
  }

  async deleteTrialBalanceEntry(id: string): Promise<boolean> {
    const result = await db.delete(trialBalanceEntries).where(eq(trialBalanceEntries.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async deleteAllTrialBalanceEntries(projectId: string): Promise<boolean> {
    await db.delete(trialBalanceEntries).where(eq(trialBalanceEntries.projectId, projectId));
    return true;
  }

  async bulkCreateTrialBalanceEntries(entries: InsertTrialBalanceEntry[]): Promise<TrialBalanceEntry[]> {
    if (entries.length === 0) return [];
    return await db.insert(trialBalanceEntries).values(entries).returning();
  }
}

export const storage = new DatabaseStorage();
