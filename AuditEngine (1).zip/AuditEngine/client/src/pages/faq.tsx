import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HelpCircle } from "lucide-react";

export default function FAQ() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <HelpCircle className="w-16 h-16 text-primary mx-auto" />
        <h1 className="text-4xl font-bold text-foreground" data-testid="text-faq-title">
          Frequently Asked Questions
        </h1>
        <p className="text-lg text-muted-foreground">
          Find answers to common questions about FinanceAudit Pro
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Getting Started</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger data-testid="faq-what-is">What is FinanceAudit Pro?</AccordionTrigger>
              <AccordionContent>
                FinanceAudit Pro is a professional financial statement generation and analysis web application designed for accountants, auditors, and financial professionals. It allows you to input trial balance data (manually or via CSV upload) and automatically generates comprehensive financial statements including income statements, balance sheets, cash flow statements, and financial ratio analyses.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2">
              <AccordionTrigger data-testid="faq-who-for">Who is this software designed for?</AccordionTrigger>
              <AccordionContent>
                FinanceAudit Pro is designed for:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Certified Public Accountants (CPAs)</li>
                  <li>Professional auditors</li>
                  <li>Financial analysts</li>
                  <li>Small business owners</li>
                  <li>Accounting firms and teams</li>
                  <li>Accounting students and educators</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3">
              <AccordionTrigger data-testid="faq-how-start">How do I get started?</AccordionTrigger>
              <AccordionContent>
                Getting started is easy:
                <ol className="list-decimal pl-6 mt-2 space-y-1">
                  <li>Click the "Log In to Get Started" button to create your account</li>
                  <li>Choose your subscription plan (Basic, Professional, or Enterprise)</li>
                  <li>Start entering your trial balance data manually or upload a CSV file</li>
                  <li>Generate your financial statements with a single click</li>
                  <li>Export your reports as PDF for professional presentation</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Features & Functionality</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-4">
              <AccordionTrigger data-testid="faq-statements">What financial statements can I generate?</AccordionTrigger>
              <AccordionContent>
                FinanceAudit Pro generates four comprehensive financial statements:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li><strong>Income Statement:</strong> Shows revenue, expenses, and net income</li>
                  <li><strong>Balance Sheet:</strong> Displays assets, liabilities, and equity</li>
                  <li><strong>Cash Flow Statement:</strong> Tracks operating, investing, and financing activities</li>
                  <li><strong>Statement of Changes in Equity:</strong> Shows changes in shareholders' equity</li>
                </ul>
                All statements are GAAP-compliant and ready for professional use.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5">
              <AccordionTrigger data-testid="faq-ratios">What financial ratios are calculated?</AccordionTrigger>
              <AccordionContent>
                Our platform calculates over 20 key financial ratios across four categories:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li><strong>Liquidity Ratios:</strong> Current Ratio, Quick Ratio, Cash Ratio</li>
                  <li><strong>Profitability Ratios:</strong> Gross Profit Margin, Net Profit Margin, ROA, ROE</li>
                  <li><strong>Efficiency Ratios:</strong> Asset Turnover, Inventory Turnover, Receivables Turnover</li>
                  <li><strong>Leverage Ratios:</strong> Debt-to-Equity, Debt-to-Assets, Interest Coverage</li>
                </ul>
                Each ratio includes interpretation guidelines and industry benchmarks.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6">
              <AccordionTrigger data-testid="faq-csv">Can I import data from my accounting software?</AccordionTrigger>
              <AccordionContent>
                Yes! FinanceAudit Pro supports CSV file imports for trial balance data. Most accounting software can export trial balance reports to CSV format. Simply export your trial balance from your accounting system (QuickBooks, Xero, Sage, etc.) and upload it to FinanceAudit Pro. Our system will automatically map the accounts and generate your financial statements.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-7">
              <AccordionTrigger data-testid="faq-comparison">Can I compare financial data across different periods?</AccordionTrigger>
              <AccordionContent>
                Absolutely! FinanceAudit Pro includes a powerful period comparison feature that allows you to:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Compare current period vs. previous period</li>
                  <li>View side-by-side financial statements</li>
                  <li>Calculate variance amounts and percentages</li>
                  <li>Identify trends and patterns</li>
                  <li>Track ratio changes over time</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-8">
              <AccordionTrigger data-testid="faq-pdf">How do I export my financial statements?</AccordionTrigger>
              <AccordionContent>
                You can export your financial statements as professional PDF documents with a single click. The exported PDFs include:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Company header with your business information</li>
                  <li>All four financial statements</li>
                  <li>Complete trial balance report</li>
                  <li>Financial ratio analysis with interpretations</li>
                  <li>Professional formatting suitable for client presentations, audits, and board meetings</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Pricing & Plans</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-9">
              <AccordionTrigger data-testid="faq-plans">What subscription plans are available?</AccordionTrigger>
              <AccordionContent>
                FinanceAudit Pro offers three subscription tiers:
                <ul className="list-disc pl-6 mt-2 space-y-2">
                  <li><strong>Basic Plan ($29/month):</strong> Up to 5 reports per month, all core features, PDF export</li>
                  <li><strong>Professional Plan ($79/month):</strong> Up to 25 reports per month, enhanced features, priority support</li>
                  <li><strong>Enterprise Plan ($199/month):</strong> Unlimited reports, full feature access, dedicated support</li>
                </ul>
                All plans include secure authentication, data storage, and access to all financial statement types.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-10">
              <AccordionTrigger data-testid="faq-trial">Is there a free trial?</AccordionTrigger>
              <AccordionContent>
                Yes! All new accounts start with a trial period that gives you full access to explore the platform. During the trial, you can test all features, generate sample financial statements, and determine which subscription plan best fits your needs. No credit card is required to start your trial.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-11">
              <AccordionTrigger data-testid="faq-cancel">Can I change or cancel my subscription?</AccordionTrigger>
              <AccordionContent>
                Yes, you can upgrade, downgrade, or cancel your subscription at any time from your account settings. If you upgrade, you'll have immediate access to the new plan's features. If you cancel, you'll retain access until the end of your current billing period. There are no long-term contracts or cancellation fees.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Security & Privacy</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-12">
              <AccordionTrigger data-testid="faq-security">Is my financial data secure?</AccordionTrigger>
              <AccordionContent>
                Absolutely. Security is our top priority:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>All data is encrypted in transit using industry-standard TLS/SSL</li>
                  <li>Data at rest is encrypted using AES-256 encryption</li>
                  <li>User-specific data isolation ensures you only access your own projects</li>
                  <li>Secure OAuth authentication with support for Google, GitHub, and more</li>
                  <li>Regular security audits and updates</li>
                  <li>SOC 2 Type II compliant infrastructure</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-13">
              <AccordionTrigger data-testid="faq-data">Who can access my data?</AccordionTrigger>
              <AccordionContent>
                Only you can access your financial data. Each user account is completely isolated, and projects are linked to specific user accounts. We implement strict access controls to ensure data privacy. Our staff cannot access your financial data without explicit authorization. We never share, sell, or use your data for any purpose other than providing our service to you.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-14">
              <AccordionTrigger data-testid="faq-backup">Is my data backed up?</AccordionTrigger>
              <AccordionContent>
                Yes. All data is automatically backed up using PostgreSQL database replication with point-in-time recovery capabilities. We maintain multiple backup copies across different geographic regions to ensure data durability and availability. In the unlikely event of data loss, we can restore your information to any point in the last 30 days.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Technical Support</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-15">
              <AccordionTrigger data-testid="faq-support">What support options are available?</AccordionTrigger>
              <AccordionContent>
                We offer multiple support channels:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li><strong>Help Documentation:</strong> Comprehensive guides and tutorials</li>
                  <li><strong>Email Support:</strong> Available for all subscription tiers</li>
                  <li><strong>Priority Support:</strong> Faster response times for Professional and Enterprise plans</li>
                  <li><strong>Video Tutorials:</strong> Step-by-step walkthroughs of key features</li>
                  <li><strong>FAQ Section:</strong> Answers to common questions</li>
                </ul>
                Enterprise customers also receive dedicated account management and custom training options.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-16">
              <AccordionTrigger data-testid="faq-mobile">Can I use FinanceAudit Pro on mobile devices?</AccordionTrigger>
              <AccordionContent>
                Yes! FinanceAudit Pro is built as a Progressive Web App (PWA), which means:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Fully responsive design works on all screen sizes</li>
                  <li>Install on Android devices for app-like experience</li>
                  <li>Offline support after initial online visit</li>
                  <li>Touch-optimized interface for mobile use</li>
                  <li>Access from any modern web browser</li>
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-17">
              <AccordionTrigger data-testid="faq-browsers">Which browsers are supported?</AccordionTrigger>
              <AccordionContent>
                FinanceAudit Pro works with all modern web browsers:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Google Chrome (recommended)</li>
                  <li>Mozilla Firefox</li>
                  <li>Microsoft Edge</li>
                  <li>Safari (macOS and iOS)</li>
                  <li>Opera</li>
                </ul>
                For the best experience, we recommend using the latest version of your preferred browser.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Still Have Questions?</h3>
          <p className="text-muted-foreground mb-6">
            Can't find the answer you're looking for? Our support team is here to help.
          </p>
          <p className="text-sm text-muted-foreground">
            Contact us through the Help section or email us directly for personalized assistance.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
