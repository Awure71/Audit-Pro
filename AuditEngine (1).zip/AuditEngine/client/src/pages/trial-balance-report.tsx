import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from "@/components/ui/table";
import { FileText, Download, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { TrialBalanceEntry, Project } from "@shared/schema";

export default function TrialBalanceReport() {
  const projectId = "default";

  const { data: project } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  const { data: entries = [], isLoading } = useQuery<TrialBalanceEntry[]>({
    queryKey: ["/api/projects", projectId, "trial-balance"],
  });

  const formatCurrency = (amount: number) => {
    const currency = project?.currency || 'USD';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const totalDebits = entries.reduce((sum, entry) => 
    sum + parseFloat(entry.debitAmount || "0"), 0
  );
  
  const totalCredits = entries.reduce((sum, entry) => 
    sum + parseFloat(entry.creditAmount || "0"), 0
  );
  
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;
  const balanceDifference = totalDebits - totalCredits;

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading trial balance report...</div>
      </div>
    );
  }

  if (!entries || entries.length === 0) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No trial balance data available. Please add trial balance entries first.</p>
            <Link href="/">
              <Button className="mt-4">Go to Trial Balance Input</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Trial Balance Report
              </h2>
              <p className="text-sm text-muted-foreground">
                Complete listing of all accounts with balances
              </p>
            </div>
          </div>
          <Button data-testid="button-export-pdf">
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <Card data-testid="trial-balance-report">
          <CardHeader>
            <CardTitle className="flex items-center text-xl">
              <FileText className="text-primary mr-3 h-6 w-6" />
              Trial Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[120px]">Account Code</TableHead>
                  <TableHead>Account Name</TableHead>
                  <TableHead className="w-[180px]">Category</TableHead>
                  <TableHead className="text-right w-[150px]">Debit</TableHead>
                  <TableHead className="text-right w-[150px]">Credit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entries.map((entry) => (
                  <TableRow key={entry.id} data-testid={`row-entry-${entry.id}`}>
                    <TableCell className="font-mono text-sm">{entry.accountCode}</TableCell>
                    <TableCell className="font-medium">{entry.accountName}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{entry.category}</TableCell>
                    <TableCell className="text-right font-mono">
                      {parseFloat(entry.debitAmount || "0") > 0 
                        ? formatCurrency(parseFloat(entry.debitAmount || "0"))
                        : "-"
                      }
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {parseFloat(entry.creditAmount || "0") > 0 
                        ? formatCurrency(parseFloat(entry.creditAmount || "0"))
                        : "-"
                      }
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              <TableFooter>
                <TableRow>
                  <TableCell colSpan={3} className="font-bold text-right">Total</TableCell>
                  <TableCell className="text-right font-mono font-bold" data-testid="total-debits">
                    {formatCurrency(totalDebits)}
                  </TableCell>
                  <TableCell className="text-right font-mono font-bold" data-testid="total-credits">
                    {formatCurrency(totalCredits)}
                  </TableCell>
                </TableRow>
              </TableFooter>
            </Table>

            {/* Balance Status */}
            <div className="mt-6 p-4 rounded-lg bg-muted">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-sm text-foreground">Balance Status</h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {isBalanced 
                      ? "Trial balance is in balance" 
                      : `Out of balance by ${formatCurrency(Math.abs(balanceDifference))}`
                    }
                  </p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                  isBalanced 
                    ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" 
                    : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                }`} data-testid="balance-status">
                  {isBalanced ? "Balanced" : "Unbalanced"}
                </div>
              </div>
              
              {!isBalanced && (
                <div className="mt-3 text-xs text-muted-foreground">
                  {balanceDifference > 0 
                    ? `Debits exceed Credits by ${formatCurrency(balanceDifference)}`
                    : `Credits exceed Debits by ${formatCurrency(Math.abs(balanceDifference))}`
                  }
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
