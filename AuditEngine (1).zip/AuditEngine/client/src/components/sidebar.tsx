import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { 
  Upload, 
  FileText,
  FileBarChart, 
  Scale, 
  ArrowRightLeft, 
  Calculator, 
  FileDown, 
  Globe, 
  Settings as SettingsIcon,
  BarChart3,
  CreditCard,
  Users,
  GitCompare,
  Menu,
  X,
  LogOut,
  BookOpen,
  Info,
  HelpCircle,
  Library
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

const navigation = [
  { name: "Trial Balance Input", href: "/", icon: Upload },
  { name: "Trial Balance Report", href: "/trial-balance-report", icon: FileText },
  { name: "Income Statement", href: "/income-statement", icon: FileBarChart },
  { name: "Balance Sheet", href: "/balance-sheet", icon: Scale },
  { name: "Cash Flow Statement", href: "/cash-flow", icon: ArrowRightLeft },
  { name: "Statement of Equity", href: "/equity-statement", icon: Users },
  { name: "Financial Ratios", href: "/financial-ratios", icon: Calculator },
  { name: "Period Comparison", href: "/period-comparison", icon: GitCompare },
  { name: "Export Reports", href: "/export-reports", icon: FileDown },
];

const resources = [
  { name: "Blog", href: "/blog", icon: BookOpen },
  { name: "Resources", href: "/resources", icon: Library },
  { name: "Help & Docs", href: "/help", icon: HelpCircle },
  { name: "FAQ", href: "/faq", icon: Info },
  { name: "About", href: "/about", icon: Info },
];

const settings = [
  { name: "Subscription", href: "/subscription", icon: CreditCard },
  { name: "Currency Settings", href: "/settings", icon: Globe },
  { name: "Preferences", href: "/settings", icon: SettingsIcon },
];

export default function Sidebar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  const closeSidebar = () => setIsOpen(false);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsOpen(!isOpen)}
        data-testid="button-menu-toggle"
      >
        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </Button>

      {isOpen && (
        <div
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden"
          onClick={closeSidebar}
          data-testid="sidebar-overlay"
        />
      )}

      <div
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border transition-transform duration-300 ease-in-out",
          "md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
        data-testid="sidebar"
      >
        <div className="flex items-center h-16 px-6 border-b border-border">
          <BarChart3 className="text-primary text-2xl mr-3" data-testid="logo-icon" />
          <h1 className="text-xl font-bold text-foreground" data-testid="app-title">FinanceAudit Pro</h1>
        </div>
        
        <nav className="mt-6 px-3 flex flex-col h-[calc(100vh-4rem)]">
          <div className="flex-1 overflow-y-auto">
            <ul className="space-y-1">
              {navigation.map((item) => {
                const isActive = location === item.href;
                return (
                  <li key={item.name}>
                    <Link href={item.href} onClick={closeSidebar}>
                      <div
                        className={cn(
                          "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer",
                          isActive
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                        )}
                        data-testid={`nav-${item.href.replace("/", "") || "dashboard"}`}
                      >
                        <item.icon className="mr-3 w-4 h-4" />
                        {item.name}
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
            
            <div className="mt-8 pt-4 border-t border-border">
              <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Resources
              </h3>
              <ul className="mt-2 space-y-1">
                {resources.map((item) => {
                  const isActive = location === item.href;
                  return (
                    <li key={item.name}>
                      <Link href={item.href} onClick={closeSidebar}>
                        <div
                          className={cn(
                            "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer",
                            isActive
                              ? "bg-primary text-primary-foreground"
                              : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                          )}
                          data-testid={`nav-resources-${item.name.toLowerCase().replace(/\s+/g, "-").replace(/&/g, "and")}`}
                        >
                          <item.icon className="mr-3 w-4 h-4" />
                          {item.name}
                        </div>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
            
            <div className="mt-8 pt-4 border-t border-border">
              <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Settings
              </h3>
              <ul className="mt-2 space-y-1">
                {settings.map((item) => {
                  const isActive = location === item.href;
                  return (
                    <li key={item.name}>
                      <Link href={item.href} onClick={closeSidebar}>
                        <div
                          className={cn(
                            "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer",
                            isActive
                              ? "bg-primary text-primary-foreground"
                              : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                          )}
                          data-testid={`nav-settings-${item.name.toLowerCase().replace(" ", "-")}`}
                        >
                          <item.icon className="mr-3 w-4 h-4" />
                          {item.name}
                        </div>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>

          {/* User Info and Logout */}
          <div className="mt-auto pt-4 border-t border-border">
            {user && (
              <div className="px-3 py-2 mb-2">
                <div className="flex items-center space-x-3">
                  {user.profileImageUrl && (
                    <img 
                      src={user.profileImageUrl} 
                      alt="Profile" 
                      className="w-8 h-8 rounded-full object-cover"
                      data-testid="img-user-profile"
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate" data-testid="text-user-name">
                      {user.firstName || user.lastName ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : user.email}
                    </p>
                    {(user.firstName || user.lastName) && user.email && (
                      <p className="text-xs text-muted-foreground truncate" data-testid="text-user-email">
                        {user.email}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
            <Button
              variant="ghost"
              className="w-full justify-start text-muted-foreground hover:text-accent-foreground"
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="mr-3 w-4 h-4" />
              Log Out
            </Button>
          </div>
        </nav>
      </div>
    </>
  );
}
