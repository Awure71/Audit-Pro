import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, FileUp, BarChart3, Download, Settings, TrendingUp } from "lucide-react";

export default function Help() {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <BookOpen className="w-16 h-16 text-primary mx-auto" />
        <h1 className="text-4xl font-bold text-foreground" data-testid="text-help-title">
          Help & Documentation
        </h1>
        <p className="text-lg text-muted-foreground">
          Complete guides and tutorials to help you make the most of FinanceAudit Pro
        </p>
      </div>

      <Tabs defaultValue="getting-started" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
          <TabsTrigger value="getting-started">Getting Started</TabsTrigger>
          <TabsTrigger value="trial-balance">Trial Balance</TabsTrigger>
          <TabsTrigger value="statements">Statements</TabsTrigger>
          <TabsTrigger value="ratios">Ratios</TabsTrigger>
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
        </TabsList>

        <TabsContent value="getting-started" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-primary" />
                Getting Started with FinanceAudit Pro
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none dark:prose-invert">
              <h3>Welcome to FinanceAudit Pro!</h3>
              <p>
                This guide will help you get started with generating professional financial statements quickly and easily.
              </p>

              <h4>Step 1: Create Your Account</h4>
              <ol>
                <li>Click the "Log In to Get Started" button on the landing page</li>
                <li>Choose your authentication method (Google, GitHub, email, etc.)</li>
                <li>Complete the authentication process</li>
                <li>You'll be automatically redirected to your dashboard</li>
              </ol>

              <h4>Step 2: Choose Your Subscription Plan</h4>
              <p>Select the plan that best fits your needs:</p>
              <ul>
                <li><strong>Basic Plan ($29/month):</strong> Perfect for individual accountants with light usage</li>
                <li><strong>Professional Plan ($79/month):</strong> Ideal for active practitioners with multiple clients</li>
                <li><strong>Enterprise Plan ($199/month):</strong> Best for accounting firms with high volume needs</li>
              </ul>

              <h4>Step 3: Create Your First Project</h4>
              <ol>
                <li>Navigate to the Trial Balance Input page</li>
                <li>Enter your company information (name, currency, reporting period)</li>
                <li>Input your trial balance data manually or upload a CSV file</li>
                <li>Click "Save" to store your data</li>
              </ol>

              <h4>Step 4: Generate Financial Statements</h4>
              <p>
                Once your trial balance is saved, navigate to any of the financial statement pages:
              </p>
              <ul>
                <li>Income Statement</li>
                <li>Balance Sheet</li>
                <li>Cash Flow Statement</li>
                <li>Statement of Changes in Equity</li>
              </ul>
              <p>
                Your statements will be automatically generated based on your trial balance data.
              </p>

              <h4>Step 5: Analyze and Export</h4>
              <ul>
                <li>Review the automatically calculated financial ratios</li>
                <li>Compare periods if you have multiple reporting periods</li>
                <li>Export your statements as PDF for professional presentation</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trial-balance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileUp className="w-6 h-6 text-primary" />
                Working with Trial Balance Data
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none dark:prose-invert">
              <h3>Manual Data Entry</h3>
              <p>
                To manually enter trial balance data:
              </p>
              <ol>
                <li>Go to the "Trial Balance Input" page</li>
                <li>Fill in the company information fields:
                  <ul>
                    <li>Company Name</li>
                    <li>Reporting Period (e.g., "Year ended December 31, 2024")</li>
                    <li>Currency (USD, EUR, GBP, etc.)</li>
                  </ul>
                </li>
                <li>Click "Add Account" to create new trial balance entries</li>
                <li>For each account, enter:
                  <ul>
                    <li>Account Code (e.g., 1000, 2000, 3000)</li>
                    <li>Account Name (e.g., "Cash", "Accounts Receivable")</li>
                    <li>Account Type (Asset, Liability, Equity, Revenue, Expense)</li>
                    <li>Debit or Credit Balance</li>
                  </ul>
                </li>
                <li>Click "Save" to store your entries</li>
              </ol>

              <h3>CSV File Import</h3>
              <p>
                You can import trial balance data from your accounting software:
              </p>
              <ol>
                <li>Export your trial balance from your accounting software (QuickBooks, Xero, Sage, etc.) as a CSV file</li>
                <li>Ensure your CSV file has the following columns:
                  <ul>
                    <li>Account Code</li>
                    <li>Account Name</li>
                    <li>Account Type</li>
                    <li>Debit or Credit Balance</li>
                  </ul>
                </li>
                <li>Click the "Upload CSV" button</li>
                <li>Select your file and click "Upload"</li>
                <li>Review the imported data and make any necessary adjustments</li>
              </ol>

              <h3>Account Types Explained</h3>
              <ul>
                <li><strong>Asset:</strong> Resources owned by the company (Cash, Accounts Receivable, Equipment)</li>
                <li><strong>Liability:</strong> Obligations owed to others (Accounts Payable, Loans, Accrued Expenses)</li>
                <li><strong>Equity:</strong> Owner's interest in the company (Capital, Retained Earnings)</li>
                <li><strong>Revenue:</strong> Income from business operations (Sales, Service Revenue)</li>
                <li><strong>Expense:</strong> Costs incurred to generate revenue (Salaries, Rent, Utilities)</li>
              </ul>

              <h3>Validation and Error Checking</h3>
              <p>
                FinanceAudit Pro automatically validates your trial balance:
              </p>
              <ul>
                <li>Ensures total debits equal total credits</li>
                <li>Checks for duplicate account codes</li>
                <li>Validates account type selections</li>
                <li>Alerts you to missing required fields</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="statements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-6 h-6 text-primary" />
                Understanding Financial Statements
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none dark:prose-invert">
              <h3>Income Statement</h3>
              <p>
                The income statement shows your company's profitability over a specific period. It includes:
              </p>
              <ul>
                <li><strong>Revenue:</strong> Total income from operations</li>
                <li><strong>Cost of Goods Sold (COGS):</strong> Direct costs of producing goods/services</li>
                <li><strong>Gross Profit:</strong> Revenue minus COGS</li>
                <li><strong>Operating Expenses:</strong> Indirect costs (salaries, rent, marketing, etc.)</li>
                <li><strong>Operating Income:</strong> Gross profit minus operating expenses</li>
                <li><strong>Other Income/Expenses:</strong> Non-operating items (interest, gains/losses)</li>
                <li><strong>Net Income:</strong> Final profit or loss after all items</li>
              </ul>

              <h3>Balance Sheet</h3>
              <p>
                The balance sheet provides a snapshot of your company's financial position at a specific date:
              </p>
              <ul>
                <li><strong>Assets:</strong> What the company owns
                  <ul>
                    <li>Current Assets: Cash, receivables, inventory</li>
                    <li>Non-Current Assets: Equipment, buildings, long-term investments</li>
                  </ul>
                </li>
                <li><strong>Liabilities:</strong> What the company owes
                  <ul>
                    <li>Current Liabilities: Payables, short-term debt</li>
                    <li>Non-Current Liabilities: Long-term debt, deferred taxes</li>
                  </ul>
                </li>
                <li><strong>Equity:</strong> Owner's stake in the company
                  <ul>
                    <li>Capital contributions</li>
                    <li>Retained earnings</li>
                  </ul>
                </li>
              </ul>
              <p><strong>The fundamental equation: Assets = Liabilities + Equity</strong></p>

              <h3>Cash Flow Statement</h3>
              <p>
                The cash flow statement tracks the movement of cash through three activities:
              </p>
              <ul>
                <li><strong>Operating Activities:</strong> Cash from day-to-day business operations</li>
                <li><strong>Investing Activities:</strong> Cash from buying/selling long-term assets</li>
                <li><strong>Financing Activities:</strong> Cash from debt, equity, and dividends</li>
              </ul>

              <h3>Statement of Changes in Equity</h3>
              <p>
                This statement shows how equity changed during the period:
              </p>
              <ul>
                <li>Beginning equity balance</li>
                <li>Plus: Capital contributions</li>
                <li>Plus: Net income (or minus: Net loss)</li>
                <li>Minus: Dividends or distributions</li>
                <li>Ending equity balance</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ratios" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-primary" />
                Financial Ratio Analysis Guide
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none dark:prose-invert">
              <h3>Liquidity Ratios</h3>
              <p>Measure the company's ability to meet short-term obligations:</p>
              <ul>
                <li><strong>Current Ratio = Current Assets ÷ Current Liabilities</strong>
                  <br />Good: Above 1.0 | Excellent: 2.0 or higher
                </li>
                <li><strong>Quick Ratio = (Current Assets - Inventory) ÷ Current Liabilities</strong>
                  <br />Good: Above 1.0 | Conservative measure excluding inventory
                </li>
                <li><strong>Cash Ratio = Cash ÷ Current Liabilities</strong>
                  <br />Most conservative liquidity measure
                </li>
              </ul>

              <h3>Profitability Ratios</h3>
              <p>Assess the company's ability to generate profit:</p>
              <ul>
                <li><strong>Gross Profit Margin = (Revenue - COGS) ÷ Revenue × 100</strong>
                  <br />Higher is better | Varies by industry
                </li>
                <li><strong>Net Profit Margin = Net Income ÷ Revenue × 100</strong>
                  <br />Shows overall profitability
                </li>
                <li><strong>Return on Assets (ROA) = Net Income ÷ Total Assets × 100</strong>
                  <br />Measures efficiency in using assets
                </li>
                <li><strong>Return on Equity (ROE) = Net Income ÷ Shareholders' Equity × 100</strong>
                  <br />Shows return to shareholders
                </li>
              </ul>

              <h3>Efficiency Ratios</h3>
              <p>Evaluate how effectively the company uses its resources:</p>
              <ul>
                <li><strong>Asset Turnover = Revenue ÷ Average Total Assets</strong>
                  <br />Higher indicates better asset utilization
                </li>
                <li><strong>Inventory Turnover = COGS ÷ Average Inventory</strong>
                  <br />How quickly inventory is sold
                </li>
                <li><strong>Receivables Turnover = Revenue ÷ Average Receivables</strong>
                  <br />How efficiently receivables are collected
                </li>
              </ul>

              <h3>Leverage Ratios</h3>
              <p>Measure the company's debt levels and financial risk:</p>
              <ul>
                <li><strong>Debt-to-Equity = Total Debt ÷ Total Equity</strong>
                  <br />Lower is generally better | Varies by industry
                </li>
                <li><strong>Debt-to-Assets = Total Debt ÷ Total Assets</strong>
                  <br />Percentage of assets financed by debt
                </li>
                <li><strong>Interest Coverage = EBIT ÷ Interest Expense</strong>
                  <br />Higher is better | Above 2.5 is generally healthy
                </li>
              </ul>

              <h3>Interpreting Ratios</h3>
              <p>Important considerations when analyzing ratios:</p>
              <ul>
                <li>Compare to industry benchmarks</li>
                <li>Track trends over multiple periods</li>
                <li>Consider the business model and industry</li>
                <li>Use multiple ratios together for complete analysis</li>
                <li>Understand the quality and accuracy of underlying data</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-6 h-6 text-primary" />
                Period Comparison Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none dark:prose-invert">
              <h3>Setting Up Period Comparison</h3>
              <p>
                Period comparison allows you to analyze changes between two reporting periods:
              </p>
              <ol>
                <li>Create and save two separate projects with trial balance data for different periods</li>
                <li>Navigate to the "Period Comparison" page</li>
                <li>Select your current period project from the dropdown</li>
                <li>Select your comparison (prior) period project</li>
                <li>Click "Compare Periods" to generate the analysis</li>
              </ol>

              <h3>Understanding the Comparison View</h3>
              <p>
                The comparison view displays:
              </p>
              <ul>
                <li><strong>Side-by-Side Statements:</strong> Current and prior period financials</li>
                <li><strong>Variance Amount:</strong> Dollar change between periods</li>
                <li><strong>Variance Percentage:</strong> Percentage change between periods</li>
                <li><strong>Trend Indicators:</strong> Visual cues showing increases/decreases</li>
              </ul>

              <h3>Key Areas to Analyze</h3>
              <ul>
                <li><strong>Revenue Growth:</strong> Is revenue increasing or decreasing?</li>
                <li><strong>Expense Control:</strong> Are expenses growing faster than revenue?</li>
                <li><strong>Profit Margins:</strong> Are margins improving or declining?</li>
                <li><strong>Asset Changes:</strong> How are asset balances changing?</li>
                <li><strong>Debt Levels:</strong> Is debt increasing or being paid down?</li>
                <li><strong>Ratio Trends:</strong> Are key ratios improving?</li>
              </ul>

              <h3>Best Practices</h3>
              <ul>
                <li>Use consistent accounting policies between periods</li>
                <li>Ensure both periods use the same currency</li>
                <li>Account for seasonality in your analysis</li>
                <li>Investigate large variances (typically greater than 10% or material amounts)</li>
                <li>Document explanations for significant changes</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="export" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="w-6 h-6 text-primary" />
                Exporting Financial Reports
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none dark:prose-invert">
              <h3>PDF Export</h3>
              <p>
                Export professional PDF reports with a single click:
              </p>
              <ol>
                <li>Navigate to any financial statement or report page</li>
                <li>Click the "Export PDF" button (usually in the top-right corner)</li>
                <li>Your browser will generate and download the PDF</li>
                <li>The PDF includes all financial statements and analysis</li>
              </ol>

              <h3>What's Included in the PDF</h3>
              <p>
                The exported PDF contains:
              </p>
              <ul>
                <li>Company header with your business name and reporting period</li>
                <li>All four financial statements:
                  <ul>
                    <li>Income Statement</li>
                    <li>Balance Sheet</li>
                    <li>Cash Flow Statement</li>
                    <li>Statement of Changes in Equity</li>
                  </ul>
                </li>
                <li>Complete trial balance report</li>
                <li>Financial ratio analysis with interpretations</li>
                <li>Professional formatting suitable for:
                  <ul>
                    <li>Client presentations</li>
                    <li>Audit documentation</li>
                    <li>Board meetings</li>
                    <li>Loan applications</li>
                    <li>Investor reports</li>
                  </ul>
                </li>
              </ul>

              <h3>Customization Tips</h3>
              <ul>
                <li>Ensure company name and period are correct before exporting</li>
                <li>Review all data for accuracy</li>
                <li>Check that currency settings are appropriate</li>
                <li>Verify calculations before distributing</li>
              </ul>

              <h3>Saving and Organizing Reports</h3>
              <p>
                Best practices for managing exported PDFs:
              </p>
              <ul>
                <li>Use clear, consistent file naming (e.g., "CompanyName_FS_2024.pdf")</li>
                <li>Create folders organized by client or period</li>
                <li>Keep backup copies of all exported reports</li>
                <li>Maintain version control if making revisions</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Need More Help?</h3>
          <p className="text-muted-foreground mb-4">
            Can't find what you're looking for? Check out our FAQ section or contact our support team.
          </p>
          <p className="text-sm text-muted-foreground">
            We're here to help you succeed with FinanceAudit Pro!
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
