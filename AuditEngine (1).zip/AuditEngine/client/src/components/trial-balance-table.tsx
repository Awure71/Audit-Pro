import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { TrialBalanceEntry, accountCategories } from "@shared/schema";
import { TableIcon, Trash2, Edit, Check, X } from "lucide-react";

interface TrialBalanceTableProps {
  entries: TrialBalanceEntry[];
  isLoading: boolean;
  projectId: string;
  formatCurrency: (amount: number) => string;
  onClearAll: () => void;
  isClearingAll: boolean;
  totalDebits: number;
  totalCredits: number;
  isBalanced: boolean;
  balanceDifference: number;
}

export default function TrialBalanceTable({
  entries,
  isLoading,
  projectId,
  formatCurrency,
  onClearAll,
  isClearingAll,
  totalDebits,
  totalCredits,
  isBalanced,
  balanceDifference,
}: TrialBalanceTableProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateEntryMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: any }) =>
      apiRequest("PUT", `/api/trial-balance/${id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "trial-balance"] });
      setEditingId(null);
      toast({ title: "Success", description: "Entry updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update entry", variant: "destructive" });
    },
  });

  const deleteEntryMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/trial-balance/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "trial-balance"] });
      toast({ title: "Success", description: "Entry deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete entry", variant: "destructive" });
    },
  });

  const handleCategoryChange = (entryId: string, category: string) => {
    updateEntryMutation.mutate({ id: entryId, updates: { category } });
  };

  const validateTrialBalance = () => {
    if (isBalanced) {
      toast({ 
        title: "Validation Passed", 
        description: "Trial balance is balanced!" 
      });
    } else {
      toast({ 
        title: "Validation Failed", 
        description: `Trial balance is out of balance by ${formatCurrency(Math.abs(balanceDifference))}`,
        variant: "destructive" 
      });
    }
  };

  if (isLoading) {
    return (
      <Card data-testid="trial-balance-loading">
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="text-muted-foreground">Loading trial balance...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="trial-balance-table">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <TableIcon className="text-primary mr-2 h-5 w-5" />
            Current Trial Balance
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant="destructive"
              size="sm"
              onClick={onClearAll}
              disabled={isClearingAll || entries.length === 0}
              data-testid="button-clear-all"
            >
              <Trash2 className="mr-1 h-4 w-4" />
              Clear All
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={validateTrialBalance}
              data-testid="button-validate"
            >
              <Check className="mr-1 h-4 w-4" />
              Validate
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Account Code</TableHead>
                <TableHead>Account Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Debit</TableHead>
                <TableHead className="text-right">Credit</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {entries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    No trial balance entries found. Upload a CSV file or add entries manually.
                  </TableCell>
                </TableRow>
              ) : (
                entries.map((entry) => (
                  <TableRow key={entry.id} data-testid={`row-entry-${entry.id}`}>
                    <TableCell className="font-mono">{entry.accountCode}</TableCell>
                    <TableCell>{entry.accountName}</TableCell>
                    <TableCell>
                      <Select
                        value={entry.category}
                        onValueChange={(value) => handleCategoryChange(entry.id, value)}
                        data-testid={`select-category-${entry.id}`}
                      >
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {accountCategories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {parseFloat(entry.debitAmount || "0") > 0 
                        ? formatCurrency(parseFloat(entry.debitAmount || "0"))
                        : "-"
                      }
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {parseFloat(entry.creditAmount || "0") > 0 
                        ? formatCurrency(parseFloat(entry.creditAmount || "0"))
                        : "-"
                      }
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex justify-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingId(entry.id)}
                          data-testid={`button-edit-${entry.id}`}
                        >
                          <Edit className="h-4 w-4 text-primary" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteEntryMutation.mutate(entry.id)}
                          disabled={deleteEntryMutation.isPending}
                          data-testid={`button-delete-${entry.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
            {entries.length > 0 && (
              <TableFooter>
                <TableRow className="font-semibold">
                  <TableCell colSpan={3} className="text-right">Total:</TableCell>
                  <TableCell className="text-right font-mono">
                    {formatCurrency(totalDebits)}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {formatCurrency(totalCredits)}
                  </TableCell>
                  <TableCell></TableCell>
                </TableRow>
                {!isBalanced && (
                  <TableRow className="text-destructive">
                    <TableCell colSpan={3} className="text-right text-sm">
                      Out of Balance:
                    </TableCell>
                    <TableCell colSpan={2} className="text-right text-sm font-mono">
                      {formatCurrency(Math.abs(balanceDifference))}
                    </TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                )}
              </TableFooter>
            )}
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
