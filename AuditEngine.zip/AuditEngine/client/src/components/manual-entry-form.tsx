import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { accountCategories } from "@shared/schema";
import { Edit, Plus } from "lucide-react";

const manualEntrySchema = z.object({
  accountCode: z.string().min(1, "Account code is required"),
  accountName: z.string().min(1, "Account name is required"),
  category: z.enum(accountCategories, { required_error: "Category is required" }),
  debitAmount: z.string().regex(/^\d*\.?\d*$/, "Invalid amount").optional(),
  creditAmount: z.string().regex(/^\d*\.?\d*$/, "Invalid amount").optional(),
}).refine(
  (data) => {
    const debit = parseFloat(data.debitAmount || "0");
    const credit = parseFloat(data.creditAmount || "0");
    return (debit > 0 && credit === 0) || (credit > 0 && debit === 0);
  },
  {
    message: "Enter either debit or credit amount, not both",
    path: ["creditAmount"],
  }
);

type ManualEntryFormData = z.infer<typeof manualEntrySchema>;

interface ManualEntryFormProps {
  projectId: string;
}

export default function ManualEntryForm({ projectId }: ManualEntryFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ManualEntryFormData>({
    resolver: zodResolver(manualEntrySchema),
    defaultValues: {
      accountCode: "",
      accountName: "",
      category: "Current Assets",
      debitAmount: "",
      creditAmount: "",
    },
  });

  const addEntryMutation = useMutation({
    mutationFn: (data: ManualEntryFormData) => {
      const entryData = {
        projectId,
        accountCode: data.accountCode,
        accountName: data.accountName,
        category: data.category,
        debitAmount: data.debitAmount || "0",
        creditAmount: data.creditAmount || "0",
      };
      return apiRequest("POST", `/api/projects/${projectId}/trial-balance`, entryData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "trial-balance"] });
      toast({ title: "Success", description: "Account added successfully" });
      form.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add account",
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: ManualEntryFormData) => {
    addEntryMutation.mutate(data);
  };

  // Auto-suggest category based on account code
  const handleAccountCodeChange = (value: string) => {
    form.setValue("accountCode", value);
    
    const code = parseInt(value);
    if (!isNaN(code)) {
      let suggestedCategory: typeof accountCategories[number] = "Current Assets";
      
      if (code >= 1000 && code < 2000) suggestedCategory = "Current Assets";
      else if (code >= 2000 && code < 3000) suggestedCategory = "Current Liabilities";
      else if (code >= 3000 && code < 4000) suggestedCategory = "Equity";
      else if (code >= 4000 && code < 5000) suggestedCategory = "Revenue";
      else if (code >= 5000 && code < 6000) suggestedCategory = "Cost of Goods Sold";
      else if (code >= 6000 && code < 8000) suggestedCategory = "Operating Expenses";
      else if (code >= 8000 && code < 9000) suggestedCategory = "Other Income";
      else if (code >= 9000) suggestedCategory = "Other Expenses";
      
      form.setValue("category", suggestedCategory);
    }
  };

  return (
    <Card data-testid="manual-entry-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Edit className="text-primary mr-2 h-5 w-5" />
          Manual Entry
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="accountName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., Cash at Bank" 
                        {...field}
                        data-testid="input-account-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="accountCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Code</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., 1010" 
                        {...field}
                        onChange={(e) => handleAccountCodeChange(e.target.value)}
                        data-testid="input-account-code"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {accountCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="debitAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Debit Amount</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01" 
                        placeholder="0.00" 
                        {...field}
                        data-testid="input-debit-amount"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="creditAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credit Amount</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01" 
                        placeholder="0.00" 
                        {...field}
                        data-testid="input-credit-amount"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit" 
              className="w-full"
              disabled={addEntryMutation.isPending}
              data-testid="button-add-account"
            >
              <Plus className="mr-2 h-4 w-4" />
              {addEntryMutation.isPending ? "Adding..." : "Add Account"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
