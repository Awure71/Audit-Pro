import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Scale, Download, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { BalanceSheet } from "@shared/schema";

export default function BalanceSheetPage() {
  const projectId = "default";

  const { data: balanceSheet, isLoading } = useQuery<BalanceSheet>({
    queryKey: ["/api/projects", projectId, "balance-sheet"],
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading balance sheet...</div>
      </div>
    );
  }

  if (!balanceSheet) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No balance sheet data available. Please add trial balance entries first.</p>
            <Link href="/">
              <Button className="mt-4">Go to Trial Balance</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Balance Sheet
              </h2>
              <p className="text-sm text-muted-foreground">
                Financial position statement
              </p>
            </div>
          </div>
          <Button data-testid="button-export-pdf">
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Assets */}
          <Card data-testid="assets-section">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <Scale className="text-primary mr-3 h-6 w-6" />
                Assets
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Assets */}
              <div className="space-y-2">
                <h3 className="font-semibold text-lg text-foreground">Current Assets</h3>
                <div className="ml-4 space-y-1">
                  {balanceSheet.currentAssets.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{item.name}</span>
                      <span className="font-mono">{formatCurrency(item.amount)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-1 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total Current Assets</span>
                      <span className="font-mono">{formatCurrency(balanceSheet.totalCurrentAssets)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Non-Current Assets */}
              <div className="space-y-2">
                <h3 className="font-semibold text-lg text-foreground">Non-Current Assets</h3>
                <div className="ml-4 space-y-1">
                  {balanceSheet.nonCurrentAssets.length > 0 ? (
                    balanceSheet.nonCurrentAssets.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{item.name}</span>
                        <span className="font-mono">{formatCurrency(item.amount)}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-muted-foreground">No non-current assets</div>
                  )}
                  <div className="border-t pt-1 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total Non-Current Assets</span>
                      <span className="font-mono">{formatCurrency(balanceSheet.totalNonCurrentAssets)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Total Assets */}
              <div className="border-t-2 border-primary pt-4">
                <div className="flex justify-between font-bold text-lg">
                  <span className="text-foreground">Total Assets</span>
                  <span className="font-mono text-primary">{formatCurrency(balanceSheet.totalAssets)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Liabilities & Equity */}
          <Card data-testid="liabilities-equity-section">
            <CardHeader>
              <CardTitle className="text-xl">Liabilities & Equity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Liabilities */}
              <div className="space-y-2">
                <h3 className="font-semibold text-lg text-foreground">Current Liabilities</h3>
                <div className="ml-4 space-y-1">
                  {balanceSheet.currentLiabilities.length > 0 ? (
                    balanceSheet.currentLiabilities.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{item.name}</span>
                        <span className="font-mono">{formatCurrency(item.amount)}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-muted-foreground">No current liabilities</div>
                  )}
                  <div className="border-t pt-1 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total Current Liabilities</span>
                      <span className="font-mono">{formatCurrency(balanceSheet.totalCurrentLiabilities)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Non-Current Liabilities */}
              <div className="space-y-2">
                <h3 className="font-semibold text-lg text-foreground">Non-Current Liabilities</h3>
                <div className="ml-4 space-y-1">
                  {balanceSheet.nonCurrentLiabilities.length > 0 ? (
                    balanceSheet.nonCurrentLiabilities.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{item.name}</span>
                        <span className="font-mono">{formatCurrency(item.amount)}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-muted-foreground">No non-current liabilities</div>
                  )}
                  <div className="border-t pt-1 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total Non-Current Liabilities</span>
                      <span className="font-mono">{formatCurrency(balanceSheet.totalNonCurrentLiabilities)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Total Liabilities */}
              <div className="border-t pt-2">
                <div className="flex justify-between font-semibold text-lg">
                  <span className="text-foreground">Total Liabilities</span>
                  <span className="font-mono">{formatCurrency(balanceSheet.totalLiabilities)}</span>
                </div>
              </div>

              {/* Equity */}
              <div className="space-y-2">
                <h3 className="font-semibold text-lg text-foreground">Equity</h3>
                <div className="ml-4 space-y-1">
                  {balanceSheet.equity.length > 0 ? (
                    balanceSheet.equity.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{item.name}</span>
                        <span className="font-mono">{formatCurrency(item.amount)}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-muted-foreground">No equity accounts</div>
                  )}
                  <div className="border-t pt-1 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total Equity</span>
                      <span className="font-mono">{formatCurrency(balanceSheet.totalEquity)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Total Liabilities & Equity */}
              <div className="border-t-2 border-primary pt-4">
                <div className="flex justify-between font-bold text-lg">
                  <span className="text-foreground">Total Liabilities & Equity</span>
                  <span className="font-mono text-primary">{formatCurrency(balanceSheet.totalLiabilitiesAndEquity)}</span>
                </div>
              </div>

              {/* Balance Check */}
              {Math.abs(balanceSheet.totalAssets - balanceSheet.totalLiabilitiesAndEquity) > 0.01 && (
                <div className="bg-destructive/10 border border-destructive rounded-lg p-3">
                  <div className="text-destructive text-sm font-medium">
                    Balance Sheet Out of Balance
                  </div>
                  <div className="text-destructive text-xs">
                    Difference: {formatCurrency(Math.abs(balanceSheet.totalAssets - balanceSheet.totalLiabilitiesAndEquity))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
