import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Target, Users, Award, TrendingUp, Shield, Zap } from "lucide-react";

export default function About() {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold text-foreground" data-testid="text-about-title">
          About FinanceAudit Pro
        </h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-about-subtitle">
          Professional financial statement generation and analysis software designed for accountants, auditors, and financial professionals
        </p>
      </div>

      <Card>
        <CardContent className="p-8 md:p-12">
          <div className="prose prose-slate max-w-none dark:prose-invert">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              FinanceAudit Pro was created to streamline the financial reporting process for accounting professionals. We understand the challenges of preparing accurate financial statements, conducting thorough analyses, and meeting tight deadlines. Our platform automates complex calculations while maintaining the precision and accuracy that financial reporting demands.
            </p>

            <h2 className="text-2xl font-bold mb-4 mt-8">Who We Serve</h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              Our software is designed for:
            </p>
            <ul className="text-muted-foreground space-y-2 mb-6">
              <li><strong>Certified Public Accountants (CPAs)</strong> - Streamline client financial statement preparation</li>
              <li><strong>Auditors</strong> - Quickly generate trial balances and financial statements for audit documentation</li>
              <li><strong>Financial Analysts</strong> - Perform comprehensive ratio analysis and trend analysis</li>
              <li><strong>Small Business Owners</strong> - Create professional financial reports without extensive accounting knowledge</li>
              <li><strong>Accounting Firms</strong> - Increase efficiency across multiple client engagements</li>
              <li><strong>Students & Educators</strong> - Learn financial statement preparation with practical examples</li>
            </ul>

            <h2 className="text-2xl font-bold mb-4 mt-8">What Makes Us Different</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Unlike generic accounting software, FinanceAudit Pro focuses specifically on financial statement generation and analysis. We've eliminated unnecessary features to create a streamlined, efficient workflow that gets you from trial balance to comprehensive financial statements in minutes, not hours.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <Target className="w-12 h-12 text-primary mb-4" />
            <CardTitle data-testid="text-feature-accuracy">Accuracy First</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Built by accounting professionals, our platform ensures GAAP-compliant financial statements with built-in validation checks and error detection.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Zap className="w-12 h-12 text-primary mb-4" />
            <CardTitle data-testid="text-feature-speed">Lightning Fast</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Generate complete financial statements in seconds. Import trial balance data via CSV and instantly create income statements, balance sheets, and cash flow statements.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Shield className="w-12 h-12 text-primary mb-4" />
            <CardTitle data-testid="text-feature-security">Secure & Private</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Your financial data is encrypted and securely stored. User-specific data isolation ensures complete privacy and data security for all clients.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <TrendingUp className="w-12 h-12 text-primary mb-4" />
            <CardTitle data-testid="text-feature-analysis">Comprehensive Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Automatically calculate 20+ financial ratios including liquidity, profitability, efficiency, and leverage metrics with industry benchmarks.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Users className="w-12 h-12 text-primary mb-4" />
            <CardTitle data-testid="text-feature-collaboration">Multi-User Support</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Designed for accounting firms and teams. Each user manages their own projects with secure authentication and data isolation.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Award className="w-12 h-12 text-primary mb-4" />
            <CardTitle data-testid="text-feature-professional">Professional Output</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Export polished, presentation-ready financial statements in PDF format. Perfect for client presentations, board meetings, and audits.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-8 md:p-12 text-center">
          <h2 className="text-3xl font-bold mb-4" data-testid="text-commitment-title">Our Commitment to Excellence</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-6">
            We're committed to continuous improvement based on feedback from accounting professionals. Our development team regularly adds new features, enhances existing functionality, and ensures compliance with the latest accounting standards.
          </p>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Whether you're preparing financial statements for a single client or managing multiple engagements, FinanceAudit Pro provides the tools you need to work efficiently while maintaining the highest standards of accuracy and professionalism.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Technology Stack</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            FinanceAudit Pro is built with modern, reliable technologies to ensure performance, security, and scalability:
          </p>
          <ul className="text-muted-foreground space-y-2">
            <li><strong>Frontend:</strong> React with TypeScript for type-safe, maintainable code</li>
            <li><strong>Backend:</strong> Node.js with Express for robust API services</li>
            <li><strong>Database:</strong> PostgreSQL for reliable, ACID-compliant data storage</li>
            <li><strong>Authentication:</strong> Secure OAuth integration with industry-standard encryption</li>
            <li><strong>Infrastructure:</strong> Cloud-hosted with automatic backups and 99.9% uptime</li>
            <li><strong>Progressive Web App:</strong> Install on Android devices for offline access</li>
          </ul>
        </CardContent>
      </Card>

      <div className="text-center space-y-4 py-8">
        <h2 className="text-3xl font-bold">Ready to Transform Your Workflow?</h2>
        <p className="text-xl text-muted-foreground">
          Join thousands of accounting professionals who trust FinanceAudit Pro for their financial reporting needs.
        </p>
      </div>
    </div>
  );
}
