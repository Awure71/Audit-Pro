import { InsertTrialBalanceEntry, AccountCategory } from "@shared/schema";

export interface ParsedCSVEntry {
  accountCode: string;
  accountName: string;
  debitAmount: string;
  creditAmount: string;
  category: AccountCategory;
}

export interface CSVParseResult {
  entries: ParsedCSVEntry[];
  errors: string[];
  warnings: string[];
}

export function parseCSV(csvContent: string, projectId: string): CSVParseResult {
  const lines = csvContent.split('\n').filter(line => line.trim());
  const errors: string[] = [];
  const warnings: string[] = [];
  const entries: ParsedCSVEntry[] = [];

  if (lines.length < 2) {
    errors.push("CSV file must have at least a header row and one data row");
    return { entries, errors, warnings };
  }

  // Parse header
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
  const requiredHeaders = ['account name', 'account code', 'debit', 'credit'];
  
  // Check for required headers with flexible matching
  const headerMap: { [key: string]: number } = {};
  headers.forEach((header, index) => {
    if (header.includes('account') && header.includes('name')) {
      headerMap['accountName'] = index;
    } else if (header.includes('account') && header.includes('code')) {
      headerMap['accountCode'] = index;
    } else if (header.includes('debit')) {
      headerMap['debit'] = index;
    } else if (header.includes('credit')) {
      headerMap['credit'] = index;
    }
  });

  // Verify all required headers are present
  const missingHeaders = [];
  if (headerMap['accountName'] === undefined) missingHeaders.push('Account Name');
  if (headerMap['accountCode'] === undefined) missingHeaders.push('Account Code');
  if (headerMap['debit'] === undefined) missingHeaders.push('Debit');
  if (headerMap['credit'] === undefined) missingHeaders.push('Credit');

  if (missingHeaders.length > 0) {
    errors.push(`Missing required columns: ${missingHeaders.join(', ')}`);
    return { entries, errors, warnings };
  }

  // Parse data rows
  for (let i = 1; i < lines.length; i++) {
    const rowNumber = i + 1;
    const values = parseCSVLine(lines[i]);
    
    if (values.length < Math.max(...Object.values(headerMap)) + 1) {
      errors.push(`Row ${rowNumber}: Insufficient columns`);
      continue;
    }

    try {
      const accountName = cleanValue(values[headerMap['accountName']]);
      const accountCode = cleanValue(values[headerMap['accountCode']]);
      const debitStr = cleanValue(values[headerMap['debit']]);
      const creditStr = cleanValue(values[headerMap['credit']]);

      // Validate required fields
      if (!accountName) {
        errors.push(`Row ${rowNumber}: Account name is required`);
        continue;
      }

      if (!accountCode) {
        errors.push(`Row ${rowNumber}: Account code is required`);
        continue;
      }

      // Parse amounts
      const debit = parseAmount(debitStr);
      const credit = parseAmount(creditStr);

      if (isNaN(debit) || isNaN(credit)) {
        errors.push(`Row ${rowNumber}: Invalid amount format`);
        continue;
      }

      if (debit < 0 || credit < 0) {
        warnings.push(`Row ${rowNumber}: Negative amounts detected, using absolute values`);
      }

      const debitAmount = Math.abs(debit);
      const creditAmount = Math.abs(credit);

      // Validate that we have either debit or credit (or both for adjusting entries)
      if (debitAmount === 0 && creditAmount === 0) {
        warnings.push(`Row ${rowNumber}: No amount specified for ${accountName}`);
        continue;
      }

      // Auto-classify account based on account code
      const category = classifyAccount(accountCode);

      entries.push({
        accountCode,
        accountName,
        debitAmount: debitAmount.toFixed(2),
        creditAmount: creditAmount.toFixed(2),
        category,
      });

    } catch (error) {
      errors.push(`Row ${rowNumber}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  return { entries, errors, warnings };
}

function parseCSVLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;
  let i = 0;

  while (i < line.length) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        // Escaped quote
        current += '"';
        i += 2;
      } else {
        // Toggle quote state
        inQuotes = !inQuotes;
        i++;
      }
    } else if (char === ',' && !inQuotes) {
      // Field separator
      values.push(current);
      current = '';
      i++;
    } else {
      // Regular character
      current += char;
      i++;
    }
  }

  // Add the last field
  values.push(current);
  
  return values;
}

function cleanValue(value: string): string {
  return value ? value.trim().replace(/"/g, '') : '';
}

function parseAmount(value: string): number {
  if (!value || value.trim() === '' || value.trim() === '-') {
    return 0;
  }
  
  // Remove currency symbols, commas, and spaces
  const cleaned = value.replace(/[\$,\s€£¥]/g, '');
  
  // Handle parentheses as negative (accounting format)
  if (cleaned.startsWith('(') && cleaned.endsWith(')')) {
    const amount = parseFloat(cleaned.slice(1, -1));
    return isNaN(amount) ? 0 : -amount;
  }
  
  const amount = parseFloat(cleaned);
  return isNaN(amount) ? 0 : amount;
}

function classifyAccount(accountCode: string): AccountCategory {
  const code = parseInt(accountCode);
  
  if (isNaN(code)) {
    // Default classification for non-numeric codes
    return "Current Assets";
  }

  // Standard chart of accounts classification
  if (code >= 1000 && code < 1500) return "Current Assets";
  if (code >= 1500 && code < 2000) return "Non-Current Assets";
  if (code >= 2000 && code < 2500) return "Current Liabilities";
  if (code >= 2500 && code < 3000) return "Non-Current Liabilities";
  if (code >= 3000 && code < 4000) return "Equity";
  if (code >= 4000 && code < 5000) return "Revenue";
  if (code >= 5000 && code < 5500) return "Cost of Goods Sold";
  if (code >= 5500 && code < 8000) return "Operating Expenses";
  if (code >= 8000 && code < 8500) return "Other Income";
  if (code >= 8500 && code < 9000) return "Other Expenses";

  // Default fallback
  return "Current Assets";
}

export function generateCSVTemplate(): string {
  const headers = ['Account Code', 'Account Name', 'Debit', 'Credit'];
  const sampleData = [
    ['1010', 'Cash at Bank', '125000.00', '0.00'],
    ['1200', 'Accounts Receivable', '85000.00', '0.00'],
    ['1300', 'Inventory', '65000.00', '0.00'],
    ['1500', 'Equipment', '150000.00', '0.00'],
    ['2100', 'Accounts Payable', '0.00', '45000.00'],
    ['2200', 'Accrued Expenses', '0.00', '15000.00'],
    ['3000', 'Share Capital', '0.00', '200000.00'],
    ['3100', 'Retained Earnings', '0.00', '50000.00'],
    ['4000', 'Sales Revenue', '0.00', '500000.00'],
    ['4100', 'Interest Income', '0.00', '5000.00'],
    ['5000', 'Cost of Goods Sold', '300000.00', '0.00'],
    ['6100', 'Rent Expense', '24000.00', '0.00'],
    ['6200', 'Salaries Expense', '120000.00', '0.00'],
    ['6300', 'Utilities Expense', '12000.00', '0.00'],
    ['6400', 'Depreciation Expense', '15000.00', '0.00'],
    ['8000', 'Gain on Sale of Asset', '0.00', '3000.00'],
    ['8500', 'Interest Expense', '2000.00', '0.00'],
  ];

  const csv = [headers, ...sampleData]
    .map(row => row.map(cell => `"${cell}"`).join(','))
    .join('\n');

  return csv;
}

export function validateTrialBalanceCSV(entries: ParsedCSVEntry[]): {
  isValid: boolean;
  totalDebits: number;
  totalCredits: number;
  balance: number;
  validationErrors: string[];
} {
  const validationErrors: string[] = [];
  let totalDebits = 0;
  let totalCredits = 0;

  entries.forEach((entry, index) => {
    const debit = parseFloat(entry.debitAmount);
    const credit = parseFloat(entry.creditAmount);

    if (isNaN(debit) || isNaN(credit)) {
      validationErrors.push(`Entry ${index + 1}: Invalid amount format`);
      return;
    }

    totalDebits += debit;
    totalCredits += credit;

    // Check for duplicate account codes
    const duplicates = entries.filter(e => e.accountCode === entry.accountCode);
    if (duplicates.length > 1) {
      validationErrors.push(`Duplicate account code found: ${entry.accountCode}`);
    }
  });

  const balance = totalDebits - totalCredits;
  const isBalanced = Math.abs(balance) < 0.01;

  if (!isBalanced) {
    validationErrors.push(`Trial balance is out of balance by ${Math.abs(balance).toFixed(2)}`);
  }

  return {
    isValid: validationErrors.length === 0,
    totalDebits,
    totalCredits,
    balance,
    validationErrors,
  };
}
