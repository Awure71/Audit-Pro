import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Check, Crown, Star, Zap } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { SubscriptionPlan, Project } from "@shared/schema";

// Initialize Stripe
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface PaymentFormProps {
  plan: SubscriptionPlan;
  projectId: string;
  onSuccess: () => void;
}

function PaymentForm({ plan, projectId, onSuccess }: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin,
        },
        redirect: 'if_required',
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        // Process the payment on our backend
        await apiRequest("POST", "/api/process-payment", {
          paymentIntentId: paymentIntent.id,
          projectId: projectId,
        });

        toast({
          title: "Payment Successful",
          description: `Successfully subscribed to ${plan.name} plan!`,
        });
        onSuccess();
      }
    } catch (error: any) {
      toast({
        title: "Payment Error",
        description: error.message || "An error occurred during payment",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing} 
        className="w-full"
        data-testid="button-submit-payment"
      >
        {isProcessing ? 'Processing...' : `Subscribe to ${plan.name} - $${plan.price}/month`}
      </Button>
    </form>
  );
}

interface CheckoutModalProps {
  plan: SubscriptionPlan;
  projectId: string;
  onClose: () => void;
  onSuccess: () => void;
}

function CheckoutModal({ plan, projectId, onClose, onSuccess }: CheckoutModalProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  // Create payment intent when modal opens
  React.useEffect(() => {
    const createPaymentIntent = async () => {
      try {
        const data = await apiRequest("POST", "/api/create-payment-intent", { 
          planId: plan.id,
          amount: plan.price 
        });
        setClientSecret(data.clientSecret);
        setIsLoading(false);
      } catch (error) {
        console.error("Error creating payment intent:", error);
        setIsLoading(false);
      }
    };
    createPaymentIntent();
  }, [plan.id, plan.price]);

  if (isLoading || !clientSecret) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="flex items-center justify-center p-8">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Subscribe to {plan.name}
            <Button variant="ghost" size="sm" onClick={onClose} data-testid="button-close-checkout">
              ×
            </Button>
          </CardTitle>
          <CardDescription>
            Complete your subscription for ${plan.price}/month
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <PaymentForm plan={plan} projectId={projectId} onSuccess={onSuccess} />
          </Elements>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SubscriptionPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);

  // Get current project
  const { data: project } = useQuery<Project>({
    queryKey: ["/api/projects", "default"],
  });

  // Get subscription plans
  const { data: plans = [], isLoading: plansLoading } = useQuery<SubscriptionPlan[]>({
    queryKey: ["/api/subscription-plans"],
  });

  const handleSelectPlan = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setShowCheckout(true);
  };

  const handlePaymentSuccess = () => {
    setShowCheckout(false);
    setSelectedPlan(null);
    queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    toast({
      title: "Subscription Activated",
      description: "You can now access all premium features!",
    });
  };

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case "basic": return <Star className="h-6 w-6" />;
      case "professional": return <Crown className="h-6 w-6" />;
      case "enterprise": return <Zap className="h-6 w-6" />;
      default: return <Star className="h-6 w-6" />;
    }
  };

  const getPlanColor = (planId: string) => {
    switch (planId) {
      case "basic": return "bg-blue-50 border-blue-200 text-blue-900";
      case "professional": return "bg-purple-50 border-purple-200 text-purple-900";
      case "enterprise": return "bg-gold-50 border-gold-200 text-gold-900";
      default: return "bg-gray-50 border-gray-200 text-gray-900";
    }
  };

  if (plansLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Subscription Plans</h1>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Subscription Plans</h1>
          <p className="text-muted-foreground mt-2">
            Choose the plan that best fits your financial reporting needs
          </p>
        </div>
      </div>

      {project && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-blue-900">Current Plan</h3>
                <p className="text-blue-700 capitalize">
                  {project.subscriptionPlan} Plan ({project.subscriptionStatus})
                </p>
              </div>
              <Badge variant="secondary" data-testid="badge-current-plan">
                {project.reportsGenerated || 0} reports generated
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card 
            key={plan.id} 
            className={`relative ${plan.id === 'professional' ? 'border-2 border-primary' : ''}`}
          >
            {plan.id === 'professional' && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
              </div>
            )}
            
            <CardHeader className="text-center">
              <div className={`mx-auto p-3 rounded-full w-fit ${getPlanColor(plan.id)}`}>
                {getPlanIcon(plan.id)}
              </div>
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <div className="text-3xl font-bold">
                ${plan.price}
                <span className="text-base font-normal text-muted-foreground">/month</span>
              </div>
              <CardDescription>
                {plan.maxReports === -1 ? 'Unlimited' : plan.maxReports} reports per month
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-4">
              <Separator />
              <ul className="space-y-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button
                className="w-full mt-6"
                variant={plan.id === 'professional' ? 'default' : 'outline'}
                onClick={() => handleSelectPlan(plan)}
                disabled={project?.subscriptionPlan === plan.id && project?.subscriptionStatus === 'active'}
                data-testid={`button-select-${plan.id}`}
              >
                {project?.subscriptionPlan === plan.id && project?.subscriptionStatus === 'active' 
                  ? 'Current Plan' 
                  : `Choose ${plan.name}`
                }
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center text-sm text-muted-foreground space-y-2">
        <p>All plans include secure payment processing and data protection.</p>
        <p>Cancel anytime. No long-term commitments.</p>
      </div>

      {showCheckout && selectedPlan && (
        <CheckoutModal
          plan={selectedPlan}
          projectId="default"
          onClose={() => setShowCheckout(false)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
}