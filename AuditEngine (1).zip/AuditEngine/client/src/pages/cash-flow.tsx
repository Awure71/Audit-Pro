import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Download, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { CashFlowStatement } from "@shared/schema";

export default function CashFlowPage() {
  const projectId = "default";

  const { data: cashFlow, isLoading } = useQuery<CashFlowStatement>({
    queryKey: ["/api/projects", projectId, "cash-flow-statement"],
    staleTime: 0, // Always fetch fresh data for audit reports
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading cash flow statement...</div>
      </div>
    );
  }

  if (!cashFlow) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No cash flow data available. Please add trial balance entries first.</p>
            <Link href="/">
              <Button className="mt-4">Go to Trial Balance</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Cash Flow Statement
              </h2>
              <p className="text-sm text-muted-foreground">
                Statement of cash flows from operating, investing, and financing activities
              </p>
            </div>
          </div>
          <Button data-testid="button-export-pdf">
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Operating Activities */}
          <Card data-testid="operating-activities">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="text-blue-600 mr-2 h-5 w-5" />
                Operating Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                <span className="font-medium">Net Income</span>
                <span className="font-semibold text-green-600" data-testid="text-net-income">
                  {formatCurrency(cashFlow.operatingActivities.netIncome)}
                </span>
              </div>

              {/* Adjustments */}
              <div>
                <h4 className="font-medium mb-2 text-muted-foreground">Adjustments for Non-Cash Items:</h4>
                <div className="space-y-2 pl-4">
                  {cashFlow.operatingActivities.adjustments.map((adjustment, index) => (
                    <div key={index} className="flex justify-between">
                      <span>{adjustment.name}</span>
                      <span data-testid={`text-adjustment-${index}`}>
                        {formatCurrency(adjustment.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Working Capital Changes */}
              <div>
                <h4 className="font-medium mb-2 text-muted-foreground">Changes in Working Capital:</h4>
                <div className="space-y-2 pl-4">
                  {cashFlow.operatingActivities.workingCapitalChanges.map((change, index) => (
                    <div key={index} className="flex justify-between">
                      <span>{change.name}</span>
                      <span data-testid={`text-wc-change-${index}`}>
                        {formatCurrency(change.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-3 flex justify-between items-center font-bold text-lg">
                <span>Total Operating Cash Flow</span>
                <span className="text-blue-600" data-testid="text-total-operating">
                  {formatCurrency(cashFlow.operatingActivities.totalOperatingCashFlow)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Investing Activities */}
          <Card data-testid="investing-activities">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="text-purple-600 mr-2 h-5 w-5" />
                Investing Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {cashFlow.investingActivities.activities.map((activity, index) => (
                  <div key={index} className="flex justify-between">
                    <span>{activity.name}</span>
                    <span data-testid={`text-investing-${index}`}>
                      {formatCurrency(activity.amount)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="border-t mt-4 pt-3 flex justify-between items-center font-bold text-lg">
                <span>Total Investing Cash Flow</span>
                <span className="text-purple-600" data-testid="text-total-investing">
                  {formatCurrency(cashFlow.investingActivities.totalInvestingCashFlow)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Financing Activities */}
          <Card data-testid="financing-activities">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="text-orange-600 mr-2 h-5 w-5" />
                Financing Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {cashFlow.financingActivities.activities.map((activity, index) => (
                  <div key={index} className="flex justify-between">
                    <span>{activity.name}</span>
                    <span data-testid={`text-financing-${index}`}>
                      {formatCurrency(activity.amount)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="border-t mt-4 pt-3 flex justify-between items-center font-bold text-lg">
                <span>Total Financing Cash Flow</span>
                <span className="text-orange-600" data-testid="text-total-financing">
                  {formatCurrency(cashFlow.financingActivities.totalFinancingCashFlow)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Net Cash Flow Summary */}
          <Card data-testid="cash-flow-summary">
            <CardHeader>
              <CardTitle>Cash Flow Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                  <span className="font-medium">Beginning Cash</span>
                  <span className="font-semibold" data-testid="text-beginning-cash">
                    {formatCurrency(cashFlow.beginningCash)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Net Cash Flow</span>
                  <span 
                    className={`font-semibold ${cashFlow.netCashFlow >= 0 ? 'text-green-600' : 'text-red-600'}`}
                    data-testid="text-net-cash-flow"
                  >
                    {formatCurrency(cashFlow.netCashFlow)}
                  </span>
                </div>
                <div className="border-t pt-3 flex justify-between items-center font-bold text-xl">
                  <span>Ending Cash</span>
                  <span 
                    className={`${cashFlow.endingCash >= 0 ? 'text-green-600' : 'text-red-600'}`}
                    data-testid="text-ending-cash"
                  >
                    {formatCurrency(cashFlow.endingCash)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}