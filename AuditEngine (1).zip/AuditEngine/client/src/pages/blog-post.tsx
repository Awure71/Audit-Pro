import { useRoute } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, User, ArrowLeft, Clock } from "lucide-react";
import { Link } from "wouter";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  readTime: string;
}

const blogPosts: BlogPost[] = [
  {
    id: "understanding-trial-balance",
    title: "Understanding Trial Balance: A Complete Guide for Accountants",
    excerpt: "Learn the fundamentals of trial balance, its importance in financial reporting, and how to prepare one accurately.",
    content: `A trial balance is a fundamental accounting tool that lists all general ledger accounts and their balances at a specific point in time. It serves as a critical checkpoint in the accounting cycle, ensuring that total debits equal total credits.

## What is a Trial Balance?

A trial balance is a worksheet that contains the closing balances of all the ledger accounts of a company at a specific point in time. The primary purpose of preparing a trial balance is to ensure that the total of all debits equals the total of all credits, which indicates that the ledger accounts are mathematically correct.

## Key Components of a Trial Balance

1. **Account Names**: All general ledger accounts are listed
2. **Debit Column**: Contains all accounts with debit balances
3. **Credit Column**: Contains all accounts with credit balances
4. **Total**: Sum of all debits must equal sum of all credits

## Why is Trial Balance Important?

The trial balance serves several critical functions:

- **Error Detection**: It helps identify mathematical errors in the ledger
- **Financial Statement Preparation**: It serves as the basis for preparing income statements and balance sheets
- **Account Verification**: It ensures all transactions are properly recorded
- **Audit Trail**: It provides a clear audit trail for accountants and auditors

## Common Errors in Trial Balance

Even when a trial balance balances, errors can still exist:

1. **Errors of Omission**: Completely omitting a transaction
2. **Errors of Commission**: Recording correct amount in wrong account
3. **Compensating Errors**: Two errors that cancel each other out
4. **Errors of Principle**: Recording transaction in wrong account type
5. **Errors of Original Entry**: Recording wrong amount in both debit and credit

## Best Practices

- Review all account balances before preparation
- Reconcile bank statements regularly
- Use accounting software to minimize manual errors
- Prepare trial balance at regular intervals (monthly, quarterly)
- Verify unusual account balances
- Document all adjusting entries

A well-prepared trial balance is the foundation of accurate financial reporting and is essential for making informed business decisions.`,
    author: "Sarah Johnson, CPA",
    date: "2024-01-15",
    category: "Accounting Basics",
    readTime: "8 min read"
  },
  {
    id: "financial-ratio-analysis",
    title: "Financial Ratio Analysis: Key Metrics Every Business Owner Should Know",
    excerpt: "Discover the essential financial ratios that help evaluate your company's performance, liquidity, and profitability.",
    content: `Financial ratio analysis is a powerful tool for evaluating a company's financial health and performance. By comparing different financial statement items, ratios provide insights that raw numbers alone cannot reveal.

## Types of Financial Ratios

### 1. Liquidity Ratios

**Current Ratio = Current Assets / Current Liabilities**

This ratio measures a company's ability to pay short-term obligations. A ratio above 1.0 indicates the company has more current assets than current liabilities.

**Quick Ratio = (Current Assets - Inventory) / Current Liabilities**

Also known as the acid-test ratio, this provides a more stringent measure of liquidity by excluding inventory.

### 2. Profitability Ratios

**Gross Profit Margin = (Revenue - Cost of Goods Sold) / Revenue × 100**

This shows the percentage of revenue retained after accounting for the cost of goods sold.

**Net Profit Margin = Net Income / Revenue × 100**

This indicates how much profit a company generates for each dollar of revenue.

**Return on Assets (ROA) = Net Income / Total Assets × 100**

This measures how efficiently a company uses its assets to generate profit.

**Return on Equity (ROE) = Net Income / Shareholders' Equity × 100**

This shows the return generated on shareholders' investments.

### 3. Efficiency Ratios

**Asset Turnover Ratio = Revenue / Average Total Assets**

This measures how efficiently a company uses its assets to generate sales.

**Inventory Turnover = Cost of Goods Sold / Average Inventory**

This indicates how many times inventory is sold and replaced during a period.

### 4. Leverage Ratios

**Debt-to-Equity Ratio = Total Debt / Total Equity**

This shows the proportion of debt financing relative to equity financing.

**Interest Coverage Ratio = EBIT / Interest Expense**

This measures a company's ability to pay interest on its debt.

## Using Ratios Effectively

1. **Compare Over Time**: Track ratios across multiple periods to identify trends
2. **Industry Benchmarks**: Compare your ratios to industry averages
3. **Consider Context**: Understand the business model and industry dynamics
4. **Use Multiple Ratios**: Don't rely on a single ratio for decision-making
5. **Quality of Data**: Ensure financial statements are accurate and consistent

## Common Mistakes to Avoid

- Comparing companies in different industries
- Ignoring seasonal variations
- Using outdated industry benchmarks
- Focusing only on profitability while ignoring liquidity
- Not considering qualitative factors

Financial ratios are tools, not answers. They should be used in conjunction with other analysis methods to make informed business decisions.`,
    author: "Michael Chen, CFA",
    date: "2024-01-10",
    category: "Financial Analysis",
    readTime: "12 min read"
  },
  {
    id: "cash-flow-statement-guide",
    title: "Mastering Cash Flow Statements: From Operating to Financing Activities",
    excerpt: "Learn how to read and analyze cash flow statements to understand a company's true financial position.",
    content: `The cash flow statement is one of the three fundamental financial statements, providing critical insights into how a company generates and uses cash. Unlike the income statement, which can be affected by accounting choices, the cash flow statement shows the actual movement of cash.

## Three Sections of Cash Flow Statement

### 1. Operating Activities

This section shows cash generated or used by the company's core business operations:

**Cash Inflows:**
- Cash received from customers
- Interest received
- Dividends received

**Cash Outflows:**
- Cash paid to suppliers
- Cash paid to employees
- Interest paid
- Taxes paid

### 2. Investing Activities

This section reflects cash used for investments in long-term assets:

**Cash Inflows:**
- Sale of property, plant, and equipment
- Sale of investments
- Collection of loans

**Cash Outflows:**
- Purchase of property, plant, and equipment
- Purchase of investments
- Loans made to others

### 3. Financing Activities

This section shows cash flows related to debt, equity, and dividends:

**Cash Inflows:**
- Issuing stock
- Borrowing money

**Cash Outflows:**
- Repaying debt
- Paying dividends
- Buying back stock

## Why Cash Flow Matters

1. **Cash is King**: A company can be profitable but still fail due to cash shortage
2. **Real Performance**: Cash flow shows actual liquidity, not just accounting profits
3. **Sustainability**: Positive operating cash flow indicates a sustainable business
4. **Investment Decisions**: Helps assess whether the company is investing in growth

## Key Metrics to Watch

**Free Cash Flow = Operating Cash Flow - Capital Expenditures**

This shows cash available after maintaining or expanding the asset base.

**Cash Flow Margin = Operating Cash Flow / Revenue**

This indicates how efficiently a company converts sales to cash.

**Cash Conversion Cycle = Days Inventory Outstanding + Days Sales Outstanding - Days Payable Outstanding**

This measures how long it takes to convert investments back to cash.

## Red Flags in Cash Flow Statements

- Consistently negative operating cash flow
- Large gap between net income and operating cash flow
- Decreasing free cash flow over time
- Heavy reliance on financing activities for cash
- Selling assets to generate cash

## Best Practices for Analysis

1. **Compare to Net Income**: Large differences may indicate accounting issues
2. **Trend Analysis**: Look at multiple periods to identify patterns
3. **Industry Comparison**: Compare cash flow metrics to industry peers
4. **Segment Analysis**: Understand which activities drive cash flow
5. **Forward-Looking**: Use historical data to project future cash flows

Understanding cash flow is essential for financial health assessment, investment decisions, and strategic planning. Always analyze cash flow alongside the income statement and balance sheet for a complete financial picture.`,
    author: "Emily Rodriguez, MBA",
    date: "2024-01-05",
    category: "Financial Statements",
    readTime: "10 min read"
  },
  {
    id: "balance-sheet-essentials",
    title: "Balance Sheet Essentials: Assets, Liabilities, and Equity Explained",
    excerpt: "A comprehensive guide to understanding balance sheets and what they reveal about a company's financial position.",
    content: `The balance sheet, also known as the statement of financial position, provides a snapshot of a company's financial condition at a specific point in time. It follows the fundamental accounting equation: Assets = Liabilities + Equity.

## Understanding the Components

### Assets

Assets are resources owned by the company that have economic value:

**Current Assets** (convertible to cash within one year):
- Cash and cash equivalents
- Accounts receivable
- Inventory
- Prepaid expenses
- Short-term investments

**Non-Current Assets** (long-term resources):
- Property, plant, and equipment (PP&E)
- Intangible assets (patents, trademarks, goodwill)
- Long-term investments
- Deferred tax assets

### Liabilities

Liabilities are obligations the company owes to others:

**Current Liabilities** (due within one year):
- Accounts payable
- Short-term debt
- Accrued expenses
- Current portion of long-term debt
- Unearned revenue

**Non-Current Liabilities** (long-term obligations):
- Long-term debt
- Bonds payable
- Deferred tax liabilities
- Pension obligations
- Lease obligations

### Shareholders' Equity

Equity represents the owners' residual interest:
- Common stock
- Preferred stock
- Retained earnings
- Additional paid-in capital
- Treasury stock
- Accumulated other comprehensive income

## Key Balance Sheet Principles

1. **The Accounting Equation Must Balance**: Total Assets always equal Total Liabilities plus Total Equity
2. **Historical Cost Basis**: Assets are generally recorded at original cost, not market value
3. **Conservative Approach**: When in doubt, understate assets and overstate liabilities
4. **Matching Principle**: Assets and liabilities are classified based on timing

## Analyzing Balance Sheet Health

**Working Capital = Current Assets - Current Liabilities**

Positive working capital indicates the company can meet short-term obligations.

**Debt-to-Assets Ratio = Total Debt / Total Assets**

Lower ratios indicate less financial leverage and lower risk.

**Book Value per Share = (Total Assets - Total Liabilities) / Outstanding Shares**

This shows the theoretical value of each share based on balance sheet values.

## Common Issues and Red Flags

- Declining cash balances
- Increasing accounts receivable without corresponding sales growth
- Rising inventory levels
- High debt levels relative to equity
- Negative working capital
- Goodwill or intangible assets as major portion of total assets

## Best Practices for Analysis

1. **Vertical Analysis**: Express each item as percentage of total assets
2. **Horizontal Analysis**: Compare changes across multiple periods
3. **Liquidity Assessment**: Ensure adequate current assets
4. **Asset Quality**: Evaluate collectibility and usefulness of assets
5. **Capital Structure**: Assess the mix of debt and equity financing

## Balance Sheet vs. Other Statements

- **Income Statement**: Shows profitability over a period
- **Cash Flow Statement**: Shows cash movements over a period
- **Balance Sheet**: Shows financial position at a point in time

All three statements must be analyzed together for complete understanding.

The balance sheet is fundamental to understanding a company's financial strength, stability, and ability to meet obligations. Regular review and analysis of balance sheet trends provides critical insights for stakeholders.`,
    author: "David Park, CPA",
    date: "2023-12-28",
    category: "Financial Statements",
    readTime: "11 min read"
  },
  {
    id: "audit-preparation-checklist",
    title: "Financial Audit Preparation: Complete Checklist for Success",
    excerpt: "Prepare your organization for a smooth audit process with this comprehensive checklist and best practices guide.",
    content: `Preparing for a financial audit doesn't have to be stressful. With proper planning and organization, you can ensure a smooth audit process and demonstrate your commitment to financial accuracy and transparency.

## Pre-Audit Planning (6-8 Weeks Before)

### 1. Assemble Your Audit Team
- Designate a primary contact for auditors
- Identify staff who will provide information
- Assign backup personnel for key roles
- Schedule team briefing sessions

### 2. Organize Financial Records
- Compile complete general ledger for audit period
- Gather all bank statements and reconciliations
- Collect investment statements and confirmations
- Organize accounts receivable and payable details
- Prepare inventory records and physical count results

### 3. Review Internal Controls
- Document accounting policies and procedures
- Test key internal controls
- Identify and document any control weaknesses
- Implement corrective actions where possible

## Document Preparation (4 Weeks Before)

### Financial Documents Needed:
- Trial balance at year-end
- Monthly financial statements for entire year
- Chart of accounts with descriptions
- Closing journal entries
- Supporting schedules for all balance sheet accounts

### Supporting Documentation:
- Contracts and agreements
- Board meeting minutes
- Insurance policies
- Legal correspondence
- Tax returns from previous years
- Payroll records and reports

### Asset and Liability Documentation:
- Fixed asset schedules with depreciation calculations
- Debt schedules showing terms and payments
- Lease agreements
- Investment portfolio details
- Employee benefit plan documents

## Pre-Audit Reconciliations (2 Weeks Before)

Essential reconciliations to complete:
1. **Bank Reconciliations**: All accounts through year-end
2. **Credit Card Reconciliations**: All company cards
3. **Accounts Receivable Aging**: Identify doubtful accounts
4. **Accounts Payable**: Ensure all invoices are recorded
5. **Inventory**: Reconcile physical count to records
6. **Fixed Assets**: Verify existence and valuation
7. **Prepaid Expenses**: Document and amortize properly
8. **Accrued Liabilities**: Ensure completeness

## Common Audit Findings to Prevent

### Documentation Issues:
- Missing invoices or supporting documents
- Inadequate approval signatures
- Incomplete contract files
- Poor filing systems

### Accounting Issues:
- Revenue recognition timing errors
- Improper expense capitalization
- Missing accruals or deferrals
- Incorrect asset valuations
- Inadequate reserve calculations

### Control Weaknesses:
- Lack of segregation of duties
- Inadequate review and approval processes
- Missing authorization for transactions
- Poor documentation of management decisions

## During the Audit

### Communication Best Practices:
- Respond promptly to auditor requests
- Provide complete, organized documentation
- Ask questions when clarification is needed
- Maintain professional relationships
- Document all discussions and decisions

### Common Auditor Requests:
- Confirmations from banks, customers, vendors
- Explanations for unusual transactions
- Evidence of management reviews
- Proof of authorization for significant items
- Physical observation of inventory or assets

## Post-Audit Follow-Up

### Review Audit Findings:
- Understand all identified issues
- Develop action plans for improvements
- Set timelines for implementation
- Assign responsibility for corrections

### Implement Improvements:
- Update policies and procedures
- Enhance internal controls
- Improve documentation practices
- Provide staff training where needed

### Maintain Readiness:
- Keep financial records current and organized
- Perform monthly reconciliations
- Document significant transactions thoroughly
- Conduct periodic internal reviews

## Technology and Tools

Leverage technology to improve audit readiness:
- Use accounting software with strong audit trails
- Implement document management systems
- Utilize electronic confirmations
- Maintain digital backup of all records
- Consider continuous auditing tools

## Tips for Small Organizations

Even smaller organizations can prepare effectively:
- Start early and work consistently
- Focus on key accounts and transactions
- Ensure bank reconciliations are current
- Document unusual items as they occur
- Maintain organized filing systems year-round

## Benefits of Good Audit Preparation

1. **Faster Audit Process**: Reduces time and cost
2. **Fewer Findings**: Demonstrates strong controls
3. **Better Relationships**: Builds trust with auditors
4. **Improved Operations**: Identifies process improvements
5. **Stakeholder Confidence**: Shows financial responsibility

Remember, audit preparation is not just about satisfying auditors—it's about maintaining strong financial management practices that benefit your organization year-round. Start early, stay organized, and view the audit as an opportunity to improve your financial processes.`,
    author: "Jennifer Martinez, CPA, CIA",
    date: "2023-12-20",
    category: "Auditing",
    readTime: "15 min read"
  }
];

export default function BlogPost() {
  const [, params] = useRoute("/blog/:id");
  const post = blogPosts.find(p => p.id === params?.id);

  if (!post) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <h2 className="text-2xl font-bold mb-4">Article Not Found</h2>
            <p className="text-muted-foreground mb-6">The blog post you're looking for doesn't exist.</p>
            <Link href="/blog">
              <Button>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Link href="/blog">
        <Button variant="ghost" data-testid="button-back-to-blog">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Blog
        </Button>
      </Link>

      <Card>
        <CardContent className="p-8 md:p-12">
          <div className="space-y-6">
            <div>
              <span className="bg-primary/10 text-primary px-3 py-1 rounded-md text-sm font-medium">
                {post.category}
              </span>
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight" data-testid="text-post-title">
              {post.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground pb-6 border-b">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{post.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{new Date(post.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{post.readTime}</span>
              </div>
            </div>

            <div 
              className="prose prose-slate max-w-none dark:prose-invert prose-headings:font-bold prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4 prose-h3:text-xl prose-h3:mt-6 prose-h3:mb-3 prose-p:text-base prose-p:leading-7 prose-li:text-base prose-li:leading-7 prose-strong:text-foreground prose-strong:font-semibold"
              dangerouslySetInnerHTML={{ __html: post.content.split('\n').map(paragraph => {
                if (paragraph.startsWith('## ')) {
                  return `<h2>${paragraph.substring(3)}</h2>`;
                } else if (paragraph.startsWith('### ')) {
                  return `<h3>${paragraph.substring(4)}</h3>`;
                } else if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                  return `<p><strong>${paragraph.substring(2, paragraph.length - 2)}</strong></p>`;
                } else if (paragraph.startsWith('- ')) {
                  return `<li>${paragraph.substring(2)}</li>`;
                } else if (paragraph.match(/^\d+\./)) {
                  return `<li>${paragraph.substring(paragraph.indexOf('.') + 2)}</li>`;
                } else if (paragraph.trim() === '') {
                  return '';
                } else {
                  return `<p>${paragraph}</p>`;
                }
              }).join('')}}
              data-testid="text-post-content"
            />
          </div>
        </CardContent>
      </Card>

      <Link href="/blog">
        <Button variant="outline" className="w-full md:w-auto">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to All Articles
        </Button>
      </Link>
    </div>
  );
}
