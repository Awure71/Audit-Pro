import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Download, ArrowLeft, TrendingUp, TrendingDown } from "lucide-react";
import { Link } from "wouter";
import { EquityStatement } from "@shared/schema";

export default function EquityStatementPage() {
  const projectId = "default";

  const { data: equityStatement, isLoading } = useQuery<EquityStatement>({
    queryKey: ["/api/projects", projectId, "equity-statement"],
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading statement of equity...</div>
      </div>
    );
  }

  if (!equityStatement) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No equity data available. Please add trial balance entries first.</p>
            <Link href="/">
              <Button className="mt-4">Go to Trial Balance</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Statement of Equity
              </h2>
              <p className="text-sm text-muted-foreground">
                Changes in equity components over the reporting period
              </p>
            </div>
          </div>
          <Button data-testid="button-export-pdf">
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Equity Components Detail */}
          <Card data-testid="equity-components-detail">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="text-indigo-600 mr-2 h-5 w-5" />
                Equity Components Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 font-medium">Component</th>
                      <th className="text-right py-3 font-medium">Beginning Balance</th>
                      <th className="text-right py-3 font-medium">Additions</th>
                      <th className="text-right py-3 font-medium">Reductions</th>
                      <th className="text-right py-3 font-medium">Ending Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {equityStatement.equityComponents.map((component, index) => (
                      <tr key={index} className="border-b" data-testid={`row-equity-${index}`}>
                        <td className="py-3 font-medium">{component.name}</td>
                        <td className="py-3 text-right" data-testid={`text-beginning-${index}`}>
                          {formatCurrency(component.beginningBalance)}
                        </td>
                        <td className="py-3 text-right text-green-600" data-testid={`text-additions-${index}`}>
                          {component.additions > 0 ? `+${formatCurrency(component.additions)}` : '-'}
                        </td>
                        <td className="py-3 text-right text-red-600" data-testid={`text-reductions-${index}`}>
                          {component.reductions > 0 ? `-${formatCurrency(component.reductions)}` : '-'}
                        </td>
                        <td className="py-3 text-right font-semibold" data-testid={`text-ending-${index}`}>
                          {formatCurrency(component.endingBalance)}
                        </td>
                      </tr>
                    ))}
                    {/* Total Row */}
                    <tr className="border-b-2 border-foreground font-bold text-lg">
                      <td className="py-4">Total Equity</td>
                      <td className="py-4 text-right" data-testid="text-total-beginning">
                        {formatCurrency(equityStatement.totalBeginningEquity)}
                      </td>
                      <td className="py-4 text-right text-green-600">
                        {equityStatement.totalNetChanges > 0 ? `+${formatCurrency(equityStatement.totalNetChanges)}` : ''}
                      </td>
                      <td className="py-4 text-right text-red-600">
                        {equityStatement.totalNetChanges < 0 ? formatCurrency(Math.abs(equityStatement.totalNetChanges)) : ''}
                      </td>
                      <td className="py-4 text-right" data-testid="text-total-ending">
                        {formatCurrency(equityStatement.totalEndingEquity)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Key Equity Changes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card data-testid="net-income-impact">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="text-green-600 mr-2 h-5 w-5" />
                  Net Income Impact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Net Income for Period</span>
                    <span 
                      className={`font-semibold ${equityStatement.netIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}
                      data-testid="text-period-net-income"
                    >
                      {formatCurrency(equityStatement.netIncome)}
                    </span>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      Net income {equityStatement.netIncome >= 0 ? 'increases' : 'decreases'} retained earnings and total equity
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card data-testid="dividend-distribution">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingDown className="text-red-600 mr-2 h-5 w-5" />
                  Dividend Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Dividends Paid</span>
                    <span 
                      className="font-semibold text-red-600"
                      data-testid="text-dividends-paid"
                    >
                      {formatCurrency(equityStatement.dividendsPaid)}
                    </span>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      Dividend payments reduce retained earnings and total equity
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Equity Summary */}
          <Card data-testid="equity-summary">
            <CardHeader>
              <CardTitle>Equity Changes Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                  <span className="font-medium">Beginning Total Equity</span>
                  <span className="font-semibold" data-testid="text-summary-beginning">
                    {formatCurrency(equityStatement.totalBeginningEquity)}
                  </span>
                </div>
                
                <div className="space-y-2 pl-4">
                  <div className="flex justify-between">
                    <span className="text-green-600">+ Net Income</span>
                    <span className="text-green-600" data-testid="text-summary-income">
                      {formatCurrency(equityStatement.netIncome)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-600">- Dividends Paid</span>
                    <span className="text-red-600" data-testid="text-summary-dividends">
                      {formatCurrency(equityStatement.dividendsPaid)}
                    </span>
                  </div>
                  {equityStatement.otherComprehensiveIncome !== 0 && (
                    <div className="flex justify-between">
                      <span>+/- Other Comprehensive Income</span>
                      <span data-testid="text-summary-other">
                        {formatCurrency(equityStatement.otherComprehensiveIncome)}
                      </span>
                    </div>
                  )}
                </div>

                <div className="border-t pt-3 flex justify-between items-center font-bold text-xl">
                  <span>Ending Total Equity</span>
                  <span 
                    className={`${equityStatement.totalEndingEquity >= 0 ? 'text-green-600' : 'text-red-600'}`}
                    data-testid="text-summary-ending"
                  >
                    {formatCurrency(equityStatement.totalEndingEquity)}
                  </span>
                </div>

                <div className="flex justify-between items-center text-sm text-muted-foreground">
                  <span>Net Change in Equity</span>
                  <span 
                    className={`font-medium ${equityStatement.totalNetChanges >= 0 ? 'text-green-600' : 'text-red-600'}`}
                    data-testid="text-summary-net-change"
                  >
                    {equityStatement.totalNetChanges >= 0 ? '+' : ''}{formatCurrency(equityStatement.totalNetChanges)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}