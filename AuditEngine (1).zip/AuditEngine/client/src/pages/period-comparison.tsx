import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, BarChart3, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Link } from "wouter";
import { PeriodComparison } from "@/lib/financial-calculations";
import { TrialBalanceEntry } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const reportingPeriods = [
  "monthly",
  "quarterly", 
  "semi-annual",
  "nine-month",
  "annual"
];

interface PeriodData {
  name: string;
  startDate: string;
  endDate: string;
  entries: any[];
}

export default function PeriodComparisonPage() {
  // In a production application, this would come from route parameters (/projects/:id/comparison)
  // or user context. For now, we use "default" but make it configurable for future enhancement.
  const getProjectId = () => {
    // Could be enhanced to read from URL params, localStorage, or context
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('projectId') || 'default';
  };
  
  const projectId = getProjectId();
  
  const [currentPeriod, setCurrentPeriod] = useState<PeriodData>({
    name: "",
    startDate: "",
    endDate: "",
    entries: []
  });
  
  const [comparisonPeriod, setComparisonPeriod] = useState<PeriodData>({
    name: "",
    startDate: "",
    endDate: "",
    entries: []
  });

  const [comparisonData, setComparisonData] = useState<PeriodComparison | null>(null);
  const [backendWarning, setBackendWarning] = useState<string | null>(null);

  // Fetch all trial balance entries for the project
  const { data: allEntries, isLoading: entriesLoading } = useQuery<TrialBalanceEntry[]>({
    queryKey: ["/api/projects", projectId, "trial-balance"],
    staleTime: 0,
  });

  // Filter entries by date range
  const filterEntriesByDateRange = (entries: TrialBalanceEntry[], startDate: string, endDate: string): TrialBalanceEntry[] => {
    if (!startDate || !endDate || !entries) return [];
    
    // LIMITATION: Current schema doesn't include transaction dates in TrialBalanceEntry.
    // For now, we return all entries for both periods, which means comparisons
    // will show the same data. In a production system, entries would have 
    // transaction dates to enable proper period filtering.
    return entries;
  };

  const comparisonMutation = useMutation({
    mutationFn: async (data: {
      currentPeriodEntries: any[];
      comparisonPeriodEntries: any[];
      currentPeriodData: { name: string; startDate: string; endDate: string };
      comparisonPeriodData: { name: string; startDate: string; endDate: string };
    }) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/period-comparison`, data);
      return response.json();
    },
    onSuccess: (data: PeriodComparison & { warning?: string }) => {
      setComparisonData(data);
      setBackendWarning(data.warning || null);
    },
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatPercentage = (percentage: number | null) => {
    if (percentage === null) return "N/A";
    return `${percentage > 0 ? '+' : ''}${percentage.toFixed(1)}%`;
  };

  const getChangeIcon = (percentage: number | null, isFavorable: (pct: number) => boolean) => {
    if (percentage === null) return <Minus className="h-4 w-4 text-gray-400" />;
    if (percentage === 0) return <Minus className="h-4 w-4 text-gray-400" />;
    
    const favorable = isFavorable(percentage);
    if (percentage > 0) return <TrendingUp className={`h-4 w-4 ${favorable ? 'text-green-600' : 'text-red-600'}`} />;
    if (percentage < 0) return <TrendingDown className={`h-4 w-4 ${favorable ? 'text-green-600' : 'text-red-600'}`} />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  const getChangeColor = (percentage: number | null, isFavorable: (pct: number) => boolean) => {
    if (percentage === null || percentage === 0) return "text-gray-600";
    
    const favorable = isFavorable(percentage);
    return favorable ? "text-green-600" : "text-red-600";
  };

  // Define what constitutes favorable changes for different metrics
  const isRevenueFavorable = (pct: number) => pct > 0; // Revenue increase is favorable
  const isProfitFavorable = (pct: number) => pct > 0; // Profit increase is favorable
  const isExpenseFavorable = (pct: number) => pct < 0; // Expense decrease is favorable
  const isAssetsFavorable = (pct: number) => pct > 0; // Asset increase is usually favorable
  const isLiabilitiesFavorable = (pct: number) => pct < 0; // Liability decrease is favorable
  const isEquityFavorable = (pct: number) => pct > 0; // Equity increase is favorable
  const isRatioFavorable = (pct: number) => pct > 0; // For most ratios, increase is favorable

  const handleCompare = () => {
    if (!currentPeriod.name || !comparisonPeriod.name || !currentPeriod.startDate || !currentPeriod.endDate || !comparisonPeriod.startDate || !comparisonPeriod.endDate || !allEntries) {
      return;
    }

    // Clear previous warning and results
    setBackendWarning(null);
    setComparisonData(null);

    // Filter entries for each period based on date ranges
    const currentEntries = filterEntriesByDateRange(allEntries, currentPeriod.startDate, currentPeriod.endDate);
    const comparisonEntries = filterEntriesByDateRange(allEntries, comparisonPeriod.startDate, comparisonPeriod.endDate);

    comparisonMutation.mutate({
      currentPeriodEntries: currentEntries,
      comparisonPeriodEntries: comparisonEntries,
      currentPeriodData: {
        name: currentPeriod.name,
        startDate: currentPeriod.startDate,
        endDate: currentPeriod.endDate,
      },
      comparisonPeriodData: {
        name: comparisonPeriod.name,
        startDate: comparisonPeriod.startDate,
        endDate: comparisonPeriod.endDate,
      },
    });
  };

  return (
    <div>
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mr-4" data-testid="button-back">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h2 className="text-2xl font-bold text-foreground" data-testid="page-title">
                Period-over-Period Comparison
              </h2>
              <p className="text-sm text-muted-foreground">
                Compare financial performance across different reporting periods
              </p>
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 mt-2">
                <p className="text-sm text-yellow-800">
                  <strong>Note:</strong> Date filtering is currently limited because trial balance entries don't include transaction dates. 
                  Comparisons will use all available data until date fields are added to the system.
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Period Selection */}
          <Card data-testid="period-selection">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="text-blue-600 mr-2 h-5 w-5" />
                Select Periods for Comparison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Current Period */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Current Period</Label>
                  <div className="space-y-3">
                    <div>
                      <Label>Period Type</Label>
                      <Select onValueChange={(value) => setCurrentPeriod(prev => ({ ...prev, name: value }))}>
                        <SelectTrigger data-testid="select-current-period">
                          <SelectValue placeholder="Select reporting period" />
                        </SelectTrigger>
                        <SelectContent>
                          {reportingPeriods.map((period) => (
                            <SelectItem key={period} value={period}>
                              {period.charAt(0).toUpperCase() + period.slice(1).replace('-', ' ')}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Start Date</Label>
                      <Input
                        type="date"
                        value={currentPeriod.startDate}
                        onChange={(e) => setCurrentPeriod(prev => ({ ...prev, startDate: e.target.value }))}
                        data-testid="input-current-start-date"
                      />
                    </div>
                    <div>
                      <Label>End Date</Label>
                      <Input
                        type="date"
                        value={currentPeriod.endDate}
                        onChange={(e) => setCurrentPeriod(prev => ({ ...prev, endDate: e.target.value }))}
                        data-testid="input-current-end-date"
                      />
                    </div>
                  </div>
                </div>

                {/* Comparison Period */}
                <div className="space-y-4">
                  <Label className="text-base font-medium">Comparison Period</Label>
                  <div className="space-y-3">
                    <div>
                      <Label>Period Type</Label>
                      <Select onValueChange={(value) => setComparisonPeriod(prev => ({ ...prev, name: value }))}>
                        <SelectTrigger data-testid="select-comparison-period">
                          <SelectValue placeholder="Select reporting period" />
                        </SelectTrigger>
                        <SelectContent>
                          {reportingPeriods.map((period) => (
                            <SelectItem key={period} value={period}>
                              {period.charAt(0).toUpperCase() + period.slice(1).replace('-', ' ')}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Start Date</Label>
                      <Input
                        type="date"
                        value={comparisonPeriod.startDate}
                        onChange={(e) => setComparisonPeriod(prev => ({ ...prev, startDate: e.target.value }))}
                        data-testid="input-comparison-start-date"
                      />
                    </div>
                    <div>
                      <Label>End Date</Label>
                      <Input
                        type="date"
                        value={comparisonPeriod.endDate}
                        onChange={(e) => setComparisonPeriod(prev => ({ ...prev, endDate: e.target.value }))}
                        data-testid="input-comparison-end-date"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-center">
                <Button 
                  onClick={handleCompare}
                  disabled={!currentPeriod.name || !comparisonPeriod.name || !currentPeriod.startDate || !currentPeriod.endDate || !comparisonPeriod.startDate || !comparisonPeriod.endDate || comparisonMutation.isPending || entriesLoading || !allEntries}
                  data-testid="button-compare-periods"
                >
                  {entriesLoading ? "Loading data..." : comparisonMutation.isPending ? "Calculating..." : "Compare Periods"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Loading State */}
          {entriesLoading && (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground">Loading trial balance data...</p>
              </CardContent>
            </Card>
          )}

          {/* Error State */}
          {comparisonMutation.isError && (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-red-600">Error calculating comparison: {(comparisonMutation.error as Error)?.message || "Unknown error"}</p>
              </CardContent>
            </Card>
          )}

          {/* Backend Warning for Identical Data */}
          {backendWarning && (
            <Card data-testid="identical-data-warning">
              <CardContent className="p-6">
                <div className="bg-orange-50 border border-orange-200 rounded-md p-3">
                  <p className="text-sm text-orange-800">
                    <strong>Warning:</strong> {backendWarning}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Comparison Results */}
          {comparisonData && (
            <div className="space-y-6">
              {/* Income Statement Comparison */}
              {comparisonData.incomeStatement && (
                <Card data-testid="income-statement-comparison">
                  <CardHeader>
                    <CardTitle>Income Statement Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Item</th>
                            <th className="text-right py-2">{comparisonData.currentPeriod.name}</th>
                            <th className="text-right py-2">{comparisonData.comparisonPeriod.name}</th>
                            <th className="text-right py-2">Change</th>
                            <th className="text-right py-2">%</th>
                          </tr>
                        </thead>
                        <tbody className="space-y-2">
                          <tr className="border-b">
                            <td className="py-2 font-medium">Total Revenue</td>
                            <td className="text-right py-2" data-testid="text-current-revenue">
                              {formatCurrency(comparisonData.incomeStatement.current.totalRevenue)}
                            </td>
                            <td className="text-right py-2" data-testid="text-comparison-revenue">
                              {formatCurrency(comparisonData.incomeStatement.comparison.totalRevenue)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.changes.totalRevenue.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.incomeStatement.changes.totalRevenue.percentage, isRevenueFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.incomeStatement.changes.totalRevenue.percentage, isRevenueFavorable)}`}>
                                {formatPercentage(comparisonData.incomeStatement.changes.totalRevenue.percentage)}
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-2 font-medium">Gross Profit</td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.current.grossProfit)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.comparison.grossProfit)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.changes.grossProfit.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.incomeStatement.changes.grossProfit.percentage, isProfitFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.incomeStatement.changes.grossProfit.percentage, isProfitFavorable)}`}>
                                {formatPercentage(comparisonData.incomeStatement.changes.grossProfit.percentage)}
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-2 font-medium">Operating Income</td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.current.operatingIncome)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.comparison.operatingIncome)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.changes.operatingIncome.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.incomeStatement.changes.operatingIncome.percentage, isProfitFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.incomeStatement.changes.operatingIncome.percentage, isProfitFavorable)}`}>
                                {formatPercentage(comparisonData.incomeStatement.changes.operatingIncome.percentage)}
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b font-bold">
                            <td className="py-2">Net Income</td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.current.netIncome)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.comparison.netIncome)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.incomeStatement.changes.netIncome.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.incomeStatement.changes.netIncome.percentage, isProfitFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.incomeStatement.changes.netIncome.percentage, isProfitFavorable)}`}>
                                {formatPercentage(comparisonData.incomeStatement.changes.netIncome.percentage)}
                              </span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Balance Sheet Comparison */}
              {comparisonData.balanceSheet && (
                <Card data-testid="balance-sheet-comparison">
                  <CardHeader>
                    <CardTitle>Balance Sheet Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Item</th>
                            <th className="text-right py-2">{comparisonData.currentPeriod.name}</th>
                            <th className="text-right py-2">{comparisonData.comparisonPeriod.name}</th>
                            <th className="text-right py-2">Change</th>
                            <th className="text-right py-2">%</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b">
                            <td className="py-2 font-medium">Total Assets</td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.current.totalAssets)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.comparison.totalAssets)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.changes.totalAssets.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.balanceSheet.changes.totalAssets.percentage, isAssetsFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.balanceSheet.changes.totalAssets.percentage, isAssetsFavorable)}`}>
                                {formatPercentage(comparisonData.balanceSheet.changes.totalAssets.percentage)}
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-2 font-medium">Total Liabilities</td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.current.totalLiabilities)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.comparison.totalLiabilities)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.changes.totalLiabilities.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.balanceSheet.changes.totalLiabilities.percentage, isLiabilitiesFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.balanceSheet.changes.totalLiabilities.percentage, isLiabilitiesFavorable)}`}>
                                {formatPercentage(comparisonData.balanceSheet.changes.totalLiabilities.percentage)}
                              </span>
                            </td>
                          </tr>
                          <tr className="border-b font-bold">
                            <td className="py-2">Total Equity</td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.current.totalEquity)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.comparison.totalEquity)}
                            </td>
                            <td className="text-right py-2">
                              {formatCurrency(comparisonData.balanceSheet.changes.totalEquity.amount)}
                            </td>
                            <td className="text-right py-2 flex items-center justify-end">
                              {getChangeIcon(comparisonData.balanceSheet.changes.totalEquity.percentage, isEquityFavorable)}
                              <span className={`ml-1 ${getChangeColor(comparisonData.balanceSheet.changes.totalEquity.percentage, isEquityFavorable)}`}>
                                {formatPercentage(comparisonData.balanceSheet.changes.totalEquity.percentage)}
                              </span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Financial Ratios Comparison */}
              {comparisonData.ratios && (
                <Card data-testid="ratios-comparison">
                  <CardHeader>
                    <CardTitle>Key Financial Ratios Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium mb-3">Liquidity Ratios</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between items-center">
                            <span>Current Ratio:</span>
                            <div className="flex items-center space-x-2">
                              <span>{comparisonData.ratios.current.currentRatio.toFixed(2)}</span>
                              {getChangeIcon(comparisonData.ratios.changes.currentRatio.percentage, isRatioFavorable)}
                              <span className={getChangeColor(comparisonData.ratios.changes.currentRatio.percentage, isRatioFavorable)}>
                                {formatPercentage(comparisonData.ratios.changes.currentRatio.percentage)}
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Quick Ratio:</span>
                            <div className="flex items-center space-x-2">
                              <span>{comparisonData.ratios.current.quickRatio.toFixed(2)}</span>
                              {getChangeIcon(comparisonData.ratios.changes.quickRatio.percentage, isRatioFavorable)}
                              <span className={getChangeColor(comparisonData.ratios.changes.quickRatio.percentage, isRatioFavorable)}>
                                {formatPercentage(comparisonData.ratios.changes.quickRatio.percentage)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-3">Profitability Ratios</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between items-center">
                            <span>Gross Margin:</span>
                            <div className="flex items-center space-x-2">
                              <span>{comparisonData.ratios.current.grossMargin.toFixed(1)}%</span>
                              {getChangeIcon(comparisonData.ratios.changes.grossMargin.percentage, isRatioFavorable)}
                              <span className={getChangeColor(comparisonData.ratios.changes.grossMargin.percentage, isRatioFavorable)}>
                                {formatPercentage(comparisonData.ratios.changes.grossMargin.percentage)}
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Net Margin:</span>
                            <div className="flex items-center space-x-2">
                              <span>{comparisonData.ratios.current.netMargin.toFixed(1)}%</span>
                              {getChangeIcon(comparisonData.ratios.changes.netMargin.percentage, isRatioFavorable)}
                              <span className={getChangeColor(comparisonData.ratios.changes.netMargin.percentage, isRatioFavorable)}>
                                {formatPercentage(comparisonData.ratios.changes.netMargin.percentage)}
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>ROE:</span>
                            <div className="flex items-center space-x-2">
                              <span>{comparisonData.ratios.current.returnOnEquity.toFixed(1)}%</span>
                              {getChangeIcon(comparisonData.ratios.changes.returnOnEquity.percentage, isRatioFavorable)}
                              <span className={getChangeColor(comparisonData.ratios.changes.returnOnEquity.percentage, isRatioFavorable)}>
                                {formatPercentage(comparisonData.ratios.changes.returnOnEquity.percentage)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}