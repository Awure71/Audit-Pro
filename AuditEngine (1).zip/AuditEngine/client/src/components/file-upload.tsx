import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Upload, Download, FileSpreadsheet } from "lucide-react";

interface FileUploadProps {
  projectId: string;
}

export default function FileUpload({ projectId }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("csvFile", file);
      
      const response = await fetch(`/api/projects/${projectId}/trial-balance/upload`, {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Upload failed");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "trial-balance"] });
      toast({ 
        title: "Success", 
        description: data.message,
      });
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    onError: (error: Error) => {
      toast({ 
        title: "Upload Failed", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const csvFile = files.find(file => file.type === "text/csv" || file.name.endsWith(".csv"));
    
    if (csvFile) {
      setSelectedFile(csvFile);
    } else {
      toast({
        title: "Invalid File",
        description: "Please select a CSV file",
        variant: "destructive",
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = () => {
    if (selectedFile) {
      uploadMutation.mutate(selectedFile);
    }
  };

  const downloadSampleCSV = () => {
    const sampleData = [
      ["Account Name", "Account Code", "Debit", "Credit"],
      ["Cash at Bank", "1010", "125000.00", "0.00"],
      ["Accounts Receivable", "1200", "85000.00", "0.00"],
      ["Inventory", "1300", "65000.00", "0.00"],
      ["Accounts Payable", "2100", "0.00", "45000.00"],
      ["Sales Revenue", "4000", "0.00", "500000.00"],
      ["Cost of Goods Sold", "5000", "300000.00", "0.00"],
      ["Rent Expense", "6100", "24000.00", "0.00"],
      ["Salaries Expense", "6200", "120000.00", "0.00"],
    ];
    
    const csvContent = sampleData.map(row => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "trial_balance_template.csv";
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <Card data-testid="csv-upload-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileSpreadsheet className="text-primary mr-2 h-5 w-5" />
          CSV Upload
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging
              ? "border-primary bg-primary/5"
              : "border-border"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          data-testid="file-drop-zone"
        >
          <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          {selectedFile ? (
            <div className="space-y-2">
              <p className="text-sm text-foreground font-medium">{selectedFile.name}</p>
              <p className="text-xs text-muted-foreground">
                {(selectedFile.size / 1024).toFixed(1)} KB
              </p>
              <Button 
                onClick={handleUpload}
                disabled={uploadMutation.isPending}
                data-testid="button-upload-file"
              >
                {uploadMutation.isPending ? "Uploading..." : "Upload File"}
              </Button>
            </div>
          ) : (
            <>
              <p className="text-sm text-muted-foreground mb-4">
                Drag and drop your CSV file here, or click to browse
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileSelect}
                className="hidden"
                data-testid="file-input"
              />
              <Button 
                variant="secondary"
                onClick={() => fileInputRef.current?.click()}
                data-testid="button-choose-file"
              >
                Choose File
              </Button>
            </>
          )}
          <p className="text-xs text-muted-foreground mt-2">
            Supported format: CSV with Account Name, Account Code, Debit, Credit columns
          </p>
        </div>
        <div className="mt-4">
          <Button
            variant="link"
            onClick={downloadSampleCSV}
            className="text-primary p-0 h-auto"
            data-testid="button-download-template"
          >
            <Download className="mr-1 h-4 w-4" />
            Download Sample CSV Template
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
