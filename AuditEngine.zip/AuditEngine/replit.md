# FinanceAudit Pro

## Overview

FinanceAudit Pro is a comprehensive financial statement generation and analysis web application designed for accountants, auditors, and financial professionals. The application allows users to input trial balance data manually or via CSV upload, then automatically generates professional financial statements including income statements, balance sheets, cash flow statements, and financial ratio analyses. Built with a modern full-stack architecture, the application provides an intuitive interface for financial data management and reporting with subscription-based access controls.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built with React 18 using TypeScript and follows a component-based architecture. The application uses Vite as the build tool and development server, providing fast hot module replacement and optimized production builds. The UI is constructed with shadcn/ui components built on Radix UI primitives, styled with Tailwind CSS for consistent design and responsive layouts.

**Key Frontend Decisions:**
- **React Router Alternative**: Uses Wouter for lightweight client-side routing, chosen for its minimal bundle size compared to React Router
- **State Management**: Leverages TanStack Query (React Query) for server state management, eliminating the need for complex global state solutions like Redux
- **Form Handling**: Implements React Hook Form with Zod validation for type-safe form management and validation
- **UI Components**: Uses shadcn/ui component library for consistent, accessible, and customizable UI components
- **Progressive Web App**: Configured as a PWA for Android installation support with offline capabilities and mobile-first design

### Progressive Web App (PWA) Implementation
The application is configured as a Progressive Web App, enabling installation on Android devices and providing an app-like experience with offline support.

**PWA Features:**
- **Manifest Configuration**: Web app manifest (`manifest.json`) defines app metadata, icons, theme colors, and display modes for native-like installation
- **Service Worker**: Implements network-first caching strategy that caches resources as they're accessed for offline use on subsequent visits
- **Install Prompt**: Custom install prompt component that guides users through the installation process
- **Mobile Responsive Design**: Fully responsive layout with collapsible sidebar navigation optimized for mobile devices
- **Offline Support**: After initial online visit, app works fully offline with cached resources; requires internet connection for first launch
- **App Icons**: Provides 192x192 and 512x512 PNG icon sizes optimized for Android devices

**Important Note**: Like most PWAs, FinanceAudit Pro requires an initial online visit to cache application resources. After the first online session, the app works fully offline. This is standard PWA behavior.

**Mobile Optimization:**
- Touch-optimized interface with appropriate touch target sizes
- Responsive sidebar that collapses on mobile with hamburger menu
- Mobile-first responsive design using Tailwind CSS breakpoints
- Optimized viewport settings for mobile devices

### Backend Architecture
The server follows a REST API pattern built with Express.js and TypeScript. The application uses a modular architecture with clear separation between routing, business logic, and data access layers.

**Key Backend Decisions:**
- **Database Abstraction**: Implements a storage interface pattern (`IStorage`) with in-memory storage for development and easy transition to database implementations
- **Schema Validation**: Uses Zod schemas shared between client and server for consistent data validation
- **File Upload**: Integrates Multer for CSV file processing with memory storage for trial balance data imports
- **Error Handling**: Implements centralized error handling middleware for consistent API responses

### Data Storage Solutions
The application uses a flexible storage architecture designed for easy migration from development to production:

**Current Implementation:**
- **Production Database**: PostgreSQL database with Drizzle ORM for all data persistence
- **Database Schema**: Comprehensive schema including users, sessions, projects, trial balance entries, and subscription data
- **Migration Strategy**: Drizzle Kit configured for schema synchronization using `npm run db:push`
- **User Data Model**: Users table stores authentication data with proper relationships to projects
- **Session Storage**: PostgreSQL-backed sessions table for secure authentication session management

**Design Rationale:**
- PostgreSQL selected for robust support for financial data types (decimal precision) and reliable session storage
- Drizzle ORM provides type-safe database operations and excellent TypeScript integration
- User-project relationships ensure proper data isolation and security
- Database-backed sessions enable persistent authentication across server restarts

### Authentication and Authorization
The application implements a robust authentication system using Replit Auth (OpenID Connect) combined with a subscription-based access model:

**Authentication System:**
- **Replit Auth Integration**: Users can log in with Google, GitHub, X, Apple, or email/password through Replit's OIDC provider
- **Session Management**: PostgreSQL-backed session storage for secure, persistent user sessions (7-day expiration)
- **User Data**: Automatically syncs user profile information (email, name, profile image) from authentication provider
- **Protected Routes**: All API endpoints require authentication via isAuthenticated middleware
- **User-Specific Data**: Each project is linked to the authenticated user, ensuring data isolation

**Subscription Plans:**
- **Basic Plan**: Limited report generation and basic features ($29/month, up to 5 reports)
- **Professional Plan**: Enhanced features with increased report limits ($79/month, up to 25 reports)
- **Enterprise Plan**: Full feature access with unlimited reports ($199/month, unlimited reports)

**Implementation Approach:**
- User authentication required for all application features
- Project-based access control where each project belongs to a specific user
- Stripe integration for payment processing and subscription management
- Report generation limits enforced at the API level based on subscription tier
- Automatic user profile synchronization on login

## External Dependencies

### Payment Processing
- **Stripe**: Integrated for subscription billing and payment processing
- **Stripe React Components**: Uses official Stripe React components for secure payment forms
- **Webhook Handling**: Configured for subscription status updates and payment confirmations

### Database and ORM
- **Neon Database**: Serverless PostgreSQL database chosen for scalability and ease of deployment
- **Drizzle ORM**: Type-safe ORM providing excellent TypeScript support and migration tools
- **Connection Management**: Uses connection pooling for efficient database resource utilization

### Development and Build Tools
- **Vite**: Modern build tool selected for fast development experience and optimized production builds
- **TypeScript**: Provides type safety across the entire application stack
- **ESBuild**: Used for server-side bundling in production builds
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development

### File Processing
- **Multer**: Handles CSV file uploads for trial balance data import
- **CSV Parsing**: Custom CSV parsing logic with validation and error handling
- **jsPDF**: Client-side PDF generation for financial report exports

### UI and Styling
- **Radix UI**: Provides accessible, unstyled UI primitives for complex components
- **Lucide React**: Icon library providing consistent iconography throughout the application
- **Class Variance Authority**: Manages component variants and conditional styling
- **Tailwind Merge**: Optimizes Tailwind class combinations for better performance

### Development Experience
- **Replit Integration**: Configured with Replit-specific plugins for enhanced development experience
- **Hot Module Replacement**: Vite provides instant feedback during development
- **TypeScript Configuration**: Shared TypeScript configuration across client, server, and shared modules